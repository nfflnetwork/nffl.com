EXISTING WEBSITE CONTENT IMPORT

Admin URL:
  /admin/import-existing.html

Purpose:
- Copies existing non-Sleeper website content into Supabase.
- Prevents editors from starting with “No existing records.”

Imports:
- Existing article pages
- All NFFL and G-League team page content
- Week 1–17 weekly award placeholders
- Yearly award placeholders
- Hot Seat placeholders
- Homepage and editable page text
- Constitution section text
- Existing Season Vault entries

Does NOT import or modify:
- Sleeper standings
- Sleeper rosters
- Sleeper transactions
- Sleeper draft picks
- Sleeper draft history
- Any other Sleeper API data

Recommended:
1. Run SUPABASE-SETUP.sql.
2. Create/promote your admin account.
3. Deploy this ZIP.
4. Log into /admin/login.html.
5. Open Import Existing.
6. Leave “Replace matching records” unchecked on the first run.
7. Click Import All Existing Content.
