# NFFL Final Stabilization Report

## Result

The Teams CMS architecture is preserved. The public and admin appearance remains based on the original stylesheet and markup; no redesign was performed.

## Root causes fixed

### Dark mode

The attempted stabilization changed shared public and admin theme behavior too broadly. Those changes were fully reverted. `site.js`, `js/global-site-shell.js`, and `admin/js/admin-theme.js` now match the pre-stabilization CMS build byte-for-byte, preserving its original toggle behavior, storage keys, classes, and visual appearance.

### Team logos and images

- The authoritative CSV contains the legacy generic value `assets/nffl-logo.png`.
- The CMS loader replaced the newer `assets/nffl-logo-new.png` already present in public page markup with that legacy image.

The CMS loader now treats only that legacy generic database value as “preserve the existing branded page logo.” A genuinely custom team logo still overrides the static image.

### Navigation regression

Two immutable database keys intentionally differ from their historical public filenames:

- `crimsonchin1` → `team-knightmare005.html`
- `kursed` → `team-djsp.html`

The Teams Editor’s public-page link now preserves those existing URLs instead of generating 404 paths.

## Regression verification

- All JavaScript files pass syntax validation.
- All 106 HTML pages have valid local links to scripts, stylesheets, images, and pages.
- All public pages load the authoritative public theme controller.
- All admin pages with a theme toggle load the admin theme controller.
- Original theme wiring, localStorage persistence, and refresh restoration are programmatically verified.
- Every HTML page declares a mobile viewport.
- The existing stylesheet retains 113 responsive media rules.
- Every CSV/database team key maps to exactly one public team page.
- Legacy generic CSV logos preserve the existing site branding; custom CMS logos remain supported.
- All 39 Teams CMS columns remain contracted.
- Safe changed-column saving, blank clearing, validation, and centralized Teams Editor CRUD remain verified.

Automated result: 14 tests passed.

## Modified files

- `js/supabase-public.js`
- `admin/js/franchise-manager.js`
- `tests/stabilization-audit.test.js`
- `STABILIZATION-REPORT.md`

## Schema changes

None.

## Known issues

No code, asset, navigation, theme, logo-path, or CMS-contract regressions remain in the packaged build. Live Supabase availability and third-party Sleeper/CDN responses remain dependent on their external services and deployment credentials.
