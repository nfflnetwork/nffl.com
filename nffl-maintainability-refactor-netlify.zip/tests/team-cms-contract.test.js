const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

const root = path.resolve(__dirname, '..');
const csvColumns = [
  'id', 'league', 'team_key', 'team_name', 'coach_name', 'about_coach',
  'franchise_notes', 'team_news', 'created_at', 'updated_at', 'current_team',
  'division', 'status', 'coach_record', 'current_record', 'all_time_record',
  'championships', 'runner_up_finishes', 'best_finish', 'best_record',
  'established_year', 'staff_history', 'franchise_timeline', 'logo_url',
  'banner_url', 'primary_color', 'secondary_color', 'social_url',
  'sleeper_roster_id', 'sleeper_owner_id', 'sleeper_owner_name',
  'sleeper_owner_avatar', 'sleeper_owner_synced_at', 'last_game', 'next_game',
  'division_titles', 'hall_of_fame_members', 'season_vault_note', 'trophy_notes'
];
const protectedColumns = ['id', 'league', 'team_key', 'created_at', 'updated_at'];

function loadBrowserScript(relativePath, additions = {}) {
  const window = { ...additions };
  const context = vm.createContext({ window, console, Blob: class {}, URL: {}, document: {} });
  vm.runInContext(fs.readFileSync(path.join(root, relativePath), 'utf8'), context);
  return window;
}

test('every authoritative CSV column is contracted by the data service', () => {
  const window = loadBrowserScript('assets/js/admin/admin-data-service.js');
  assert.deepEqual([...window.NFFLAdminData.TEAM_COLUMNS].sort(), [...csvColumns].sort());
});

test('every editable CSV column has an editor control', () => {
  const html = fs.readFileSync(path.join(root, 'admin/teams-editor.html'), 'utf8');
  const controls = [...html.matchAll(/<(?:input|select|textarea)\b[^>]*\bname="([^"]+)"/g)].map((match) => match[1]);
  const expected = csvColumns.filter((column) => !protectedColumns.includes(column));
  assert.deepEqual(expected.filter((column) => !controls.includes(column)), []);
  assert.deepEqual(controls.filter((column) => !csvColumns.includes(column)), []);
});

test('unchanged and unavailable fields are never included in a save patch', () => {
  const window = loadBrowserScript('assets/js/admin/admin-data-service.js');
  const original = { id: 1, team_name: 'Birds', division: 'South', trophy_notes: 'Keep me' };
  const candidate = { id: 1, team_name: 'Birds Updated', division: 'South' };
  assert.deepEqual(
    { ...window.NFFLAdminData.teamChanges(original, candidate) },
    { team_name: 'Birds Updated' }
  );
});

test('empty edited fields clear explicitly while untouched fields remain absent', () => {
  const window = loadBrowserScript('assets/js/admin/admin-data-service.js');
  const changes = window.NFFLAdminData.teamChanges(
    { team_name: 'Birds', banner_url: 'https://example.com/banner.jpg', trophy_notes: 'Keep me' },
    { team_name: 'Birds', banner_url: '' }
  );
  assert.equal(changes.banner_url, null);
  assert.equal(Object.hasOwn(changes, 'trophy_notes'), false);
});

test('validation catches required, duplicate, URL, and color failures', () => {
  const window = loadBrowserScript('assets/js/admin/validation.js');
  const result = window.NFFLTeamValidation.validateTeam({
    id: 1,
    league: 'nffl',
    team_key: 'birds',
    team_name: '',
    division: 'TBD',
    sleeper_owner_id: 'duplicate',
    logo_url: 'not a url',
    primary_color: '#123'
  }, [{
    id: 2,
    league: 'nffl',
    team_key: 'other',
    sleeper_owner_id: 'duplicate'
  }]);
  assert.equal(result.valid, false);
  assert.ok(result.errors.length >= 5);
});

test('the franchise manager has no direct team_content CRUD path', () => {
  const source = fs.readFileSync(path.join(root, 'assets/js/admin/franchise-manager.js'), 'utf8');
  assert.equal(/from\(['"]team_content['"]\)/.test(source), false);
  assert.equal(/\.upsert\(/.test(source), false);
  assert.match(source, /dataService\.loadTeam/);
  assert.match(source, /dataService\.saveTeam/);
});
