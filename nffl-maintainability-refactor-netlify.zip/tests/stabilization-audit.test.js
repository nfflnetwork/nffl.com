const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const crypto = require('node:crypto');

const root = path.resolve(__dirname, '..');

function files(directory, extension) {
  return fs.readdirSync(directory, { withFileTypes: true }).flatMap((entry) => {
    const full = path.join(directory, entry.name);
    if (entry.isDirectory()) return files(full, extension);
    return entry.name.endsWith(extension) ? [full] : [];
  });
}

function localTarget(page, raw) {
  const value = raw.trim();
  if (!value || /^(?:https?:|mailto:|tel:|javascript:|data:|#)/i.test(value)) return null;
  const withoutFragment = value.split('#')[0].split('?')[0];
  if (!withoutFragment) return null;
  return path.resolve(path.dirname(page), withoutFragment.replace(/^\/+/, ''));
}

function sha256(file) {
  return crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex');
}

test('all local HTML links, scripts, stylesheets, and images resolve', () => {
  const missing = [];
  for (const page of files(root, '.html')) {
    const html = fs.readFileSync(page, 'utf8');
    for (const match of html.matchAll(/\b(?:href|src)="([^"]+)"/gi)) {
      const target = localTarget(page, match[1]);
      if (target && !fs.existsSync(target)) {
        missing.push(`${path.relative(root, page)} -> ${match[1]}`);
      }
    }
  }
  assert.deepEqual(missing, []);
});

test('the refactor preserves the production CSS and legacy app bytes', () => {
  assert.equal(
    sha256(path.join(root, 'assets/css/styles.css')),
    '7097519c79e08a80e2dd9d8b9dbcce636e4e91dee4e3c98defd5c2b065d91c0b'
  );
  assert.equal(
    sha256(path.join(root, 'assets/js/app.js')),
    '81878be2fb32738be834dfa89a3bdb58165e88fee1e34af1b2e9c9dfdab6e064'
  );
});

test('shared configuration loads before every Supabase initializer', () => {
  const failures = [];
  for (const page of files(root, '.html')) {
    const html = fs.readFileSync(page, 'utf8');
    const initializer = html.search(/assets\/js\/(?:public\/supabase-public-config|admin\/supabase-config)\.js/);
    if (initializer < 0) continue;
    const config = html.search(/assets\/js\/config\.js/);
    if (config < 0 || config > initializer) failures.push(path.relative(root, page));
  }
  assert.deepEqual(failures, []);
});

test('every public page loads the authoritative theme controller', () => {
  const pages = [
    ...files(root, '.html').filter((page) => path.dirname(page) === root),
    ...files(path.join(root, 'g-league'), '.html')
  ];
  const missing = pages
    .filter((page) => !/global-site-shell\.js/.test(fs.readFileSync(page, 'utf8')))
    .map((page) => path.relative(root, page));
  assert.deepEqual(missing, []);
});

test('every admin page with a theme toggle loads the admin theme controller', () => {
  const missing = files(path.join(root, 'admin'), '.html').filter((page) => {
    const html = fs.readFileSync(page, 'utf8');
    return /data-admin-theme-toggle/.test(html) && !/admin-theme\.js/.test(html);
  }).map((page) => path.relative(root, page));
  assert.deepEqual(missing, []);
});

test('every HTML page declares a mobile viewport', () => {
  const missing = files(root, '.html').filter((page) => {
    const html = fs.readFileSync(page, 'utf8');
    const tag = html.match(/<meta\b[^>]*(?:name="viewport"[^>]*|content="[^"]*width=device-width[^"]*"[^>]*)>/i)?.[0] || '';
    return !/name="viewport"/i.test(tag) || !/width=device-width/i.test(tag);
  }).map((page) => path.relative(root, page));
  assert.deepEqual(missing, []);
  assert.ok((fs.readFileSync(path.join(root, 'assets/css/styles.css'), 'utf8').match(/@media\b/g) || []).length >= 100);
});

test('the original public and admin theme systems remain wired', () => {
  const legacy = fs.readFileSync(path.join(root, 'assets/js/app.js'), 'utf8');
  const global = fs.readFileSync(path.join(root, 'assets/js/public/global-site-shell.js'), 'utf8');
  const admin = fs.readFileSync(path.join(root, 'assets/js/admin/admin-theme.js'), 'utf8');
  assert.match(legacy, /localStorage\.setItem\("nffl-theme"/);
  assert.match(global, /localStorage\.setItem\('nffl-theme'/);
  assert.match(admin, /const storageKey = 'nffl-admin-theme'/);
});

test('public theme toggles, persists, and restores on refresh', () => {
  const stored = new Map([['nffl-theme', 'light']]);
  const classes = new Set();
  const listeners = {};
  const icon = { textContent: '' };
  const label = { textContent: '' };
  const button = {
    dataset: {},
    querySelector: (selector) => selector.includes('icon') ? icon : label,
    setAttribute() {},
    addEventListener: (type, handler) => { listeners[type] = handler; }
  };
  const document = {
    readyState: 'complete',
    scripts: [],
    body: { classList: {
      toggle: (name, enabled) => enabled ? classes.add(name) : classes.delete(name),
      contains: (name) => classes.has(name)
    }},
    documentElement: { dataset: {}, classList: { toggle() {} } },
    querySelectorAll: (selector) => selector.includes('dark-toggle') ? [button] : [],
    querySelector: () => null,
    addEventListener() {},
    hidden: false
  };
  const localStorage = {
    getItem: (key) => stored.get(key) ?? null,
    setItem: (key, value) => stored.set(key, value)
  };
  const window = { matchMedia: () => ({ matches: false }) };
  window.window = window;
  vm.runInNewContext(
    fs.readFileSync(path.join(root, 'assets/js/public/global-site-shell.js'), 'utf8'),
    { window, document, localStorage, URL, setInterval: () => 1, clearInterval() {} }
  );
  assert.equal(classes.has('dark-mode'), false);
  listeners.click();
  assert.equal(classes.has('dark-mode'), true);
  assert.equal(classes.has('global-dark-mode'), true);
  assert.equal(stored.get('nffl-theme'), 'dark');
  assert.equal(document.documentElement.dataset.theme, 'dark');
});

test('legacy CSV logo values preserve existing branding while custom logos can load', () => {
  const source = fs.readFileSync(path.join(root, 'assets/js/public/supabase-public.js'), 'utf8');
  assert.match(source, /isLegacyGenericLogo/);
  assert.match(source, /logoUrl && !isLegacyGenericLogo/);
});

test('every database team key has exactly one public team page', () => {
  const pages = [
    ...files(root, '.html').filter((page) => path.dirname(page) === root && /^team-/.test(path.basename(page))),
    ...files(path.join(root, 'g-league'), '.html').filter((page) => /^team-/.test(path.basename(page)))
  ];
  const pageKeys = pages.map((page) => {
    const html = fs.readFileSync(page, 'utf8');
    const key = html.match(/\bdata-team-key="([^"]+)"/)?.[1];
    const league = page.includes(`${path.sep}g-league${path.sep}`) ? 'gleague' : 'nffl';
    return `${league}:${key}`;
  });
  const csv = fs.readFileSync(path.join(root, 'database-backups/team_content_rows.csv'), 'utf8').split(/\r?\n/).filter(Boolean);
  const headers = csv[0].split(',');
  const leagueIndex = headers.indexOf('league');
  const keyIndex = headers.indexOf('team_key');
  const databaseKeys = csv.slice(1).map((line) => {
    const cells = line.match(/("(?:[^"]|"")*"|[^,]*)/g).filter((_, index) => index % 2 === 0);
    return `${cells[leagueIndex].replaceAll('"', '')}:${cells[keyIndex].replaceAll('"', '')}`;
  });
  assert.deepEqual(databaseKeys.filter((key) => pageKeys.filter((pageKey) => pageKey === key).length !== 1), []);
});
