
(function setupUnifiedArticlePresentations() {
  const client = window.nfflPublicSupabase;
  if (!client) return;

  const esc = (value) => String(value ?? '')
    .replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;')
    .replaceAll('"','&quot;').replaceAll("'","&#039;");

  const articleHref = (article, prefix='') =>
    `${prefix}article.html?slug=${encodeURIComponent(article.slug)}`;

  function prefixForPage() {
    const path = location.pathname.replace(/^\/+/, '');
    const depth = Math.max(0, path.split('/').length - 1);
    return '../'.repeat(depth);
  }

  async function publishedArticles(league='nffl') {
    const { data, error } = await client
      .from('articles')
      .select('*')
      .eq('league', league)
      .eq('status', 'published')
      .order('pinned', { ascending:false })
      .order('published_at', { ascending:false, nullsFirst:false })
      .order('created_at', { ascending:false });
    if (error) throw new Error(error.message);
    return data || [];
  }

  async function placementMap(league='nffl') {
    const { data, error } = await client
      .from('article_placements')
      .select('placement_key,position,article_id')
      .eq('league',league)
      .order('position');
    if (error) throw new Error(error.message);
    return data || [];
  }

  function chosenArticles(all, placements, key, limit) {
    const ids = placements
      .filter((row) => row.placement_key === key)
      .sort((a,b) => Number(a.position)-Number(b.position))
      .map((row) => Number(row.article_id))
      .filter(Boolean);

    const selected = ids.map((id) => all.find((article) => Number(article.id) === id)).filter(Boolean);
    const used = new Set(selected.map((article) => Number(article.id)));
    const fallback = all.filter((article) => !used.has(Number(article.id)));
    return [...selected, ...fallback].slice(0,limit);
  }

  function renderHomepageHero(root, articles, prefix) {
    if (!articles.length) return;
    root.innerHTML = articles.map((article,index) => `
      <article class="home-story-slide ${index===0?'active':''}" data-story-slide>
        <div class="home-story-copy">
          <span class="eyebrow">${esc(article.category || 'Top Story')}</span>
          <h2>${esc(article.title)}</h2>
          <p>${esc(article.subtitle || article.summary || '')}</p>
          <a class="button gold" href="${articleHref(article,prefix)}">Read Story</a>
        </div>
        <div class="home-story-art"><img src="${esc(article.image_url || `${prefix}assets/images/nffl-logo-new.png`)}" alt="${esc(article.title)}"></div>
      </article>
    `).join('') + `
      <div class="home-story-controls">
        <button type="button" data-story-prev aria-label="Previous story">‹</button>
        <div class="home-story-dots">
          ${articles.map((_,index) => `<button class="${index===0?'active':''}" type="button" data-story-dot="${index}" aria-label="Story ${index+1}"></button>`).join('')}
        </div>
        <button type="button" data-story-next aria-label="Next story">›</button>
      </div>`;
  }

  function renderHomepageHeadlines(root, articles, prefix) {
    root.innerHTML = articles.map((article) => `
      <a href="${articleHref(article,prefix)}">
        <span>${esc(article.category || 'League News')}</span>
        <strong>${esc(article.title)}</strong>
        <small>${article.pinned ? 'Pinned' : 'Latest'}</small>
      </a>`).join('');
  }

  function formatArticleDate(article) {
    const value = article.published_at || article.created_at;
    if (!value) return '';
    return new Date(value).toLocaleDateString(undefined, {
      month:'short',
      day:'numeric',
      year:'numeric'
    });
  }

  function card(article,prefix='') {
    const published = formatArticleDate(article);
    return `
      <article class="article-card news-article-card" data-news-category-value="${esc(article.category || 'League News')}">
        <a class="article-media" href="${articleHref(article,prefix)}" aria-label="Read ${esc(article.title)}">
          <img loading="lazy" src="${esc(article.image_url || `${prefix}assets/images/nffl-logo-new.png`)}" alt="${esc(article.title)}">
        </a>
        <div class="article-body">
          <span class="meta">${esc(article.category || 'League News')}</span>
          <h3><a href="${articleHref(article,prefix)}">${esc(article.title)}</a></h3>
          <p>${esc(article.summary || article.subtitle || '')}</p>
          <div class="news-card-footer">
            <span>${esc(published)}</span>
            <span>${esc(article.reading_time || '2 min read')}</span>
          </div>
          <a class="button" href="${articleHref(article,prefix)}">Read Story</a>
        </div>
      </article>`;
  }

  function renderCards(root, articles, prefix) {
    root.innerHTML = articles.map((article) => card(article,prefix)).join('');
  }

  function renderNewsHero(root, articles, prefix) {
    const article = articles[0];
    if (!article) return;
    root.innerHTML = `
      <article class="news-primary-story">
        <div class="news-primary-media"><img src="${esc(article.image_url || `${prefix}assets/images/nffl-logo-new.png`)}" alt="${esc(article.title)}"></div>
        <div class="news-primary-copy">
          <span class="eyebrow">${esc(article.category || 'Top Story')}</span>
          <h2>${esc(article.title)}</h2>
          <p>${esc(article.subtitle || article.summary || '')}</p>
          <div class="news-primary-meta"><span>${esc(article.author_name || 'NFFL Network Staff')}</span><span>${esc(article.reading_time || '2 min read')}</span></div>
          <a class="button gold" href="${articleHref(article,prefix)}">Read Story</a>
        </div>
      </article>`;
  }

  function renderBreakingTicker(articles,prefix) {
    if (!articles.length) return;
    document.querySelectorAll('.global-breaking-window').forEach((windowNode) => {
      windowNode.innerHTML = articles.map((article,index) =>
        `<a class="global-breaking-item ${index===0?'active':''}" href="${articleHref(article,prefix)}">${esc(article.title)}</a>`
      ).join('');
    });
  }

  async function setupLatestNews(all,prefix) {
    const list = document.querySelector('[data-news-latest-list]');
    if (!list) return;

    let category = 'all';
    let visible = 9;

    const render = () => {
      const filtered = category === 'all'
        ? all
        : all.filter((article) => (article.category || 'League News') === category);
      list.innerHTML = filtered.slice(0,visible).map((article) => card(article,prefix)).join('') ||
        '<div class="news-empty-state"><span>📰</span><h3>No published stories yet</h3><p>Choose another category or publish a story from Article Studio.</p></div>';
      const more = document.querySelector('[data-news-load-more]');
      if (more) more.hidden = visible >= filtered.length;
    };

    document.querySelectorAll('[data-news-category]').forEach((button) => {
      const key = button.dataset.newsCategory;
      const count = key === 'all'
        ? all.length
        : all.filter((article) => (article.category || 'League News') === key).length;
      button.innerHTML = `<span>${button.textContent.trim()}</span><b>${count}</b>`;
      button.hidden = key !== 'all' && count === 0;

      button.addEventListener('click', () => {
        category = button.dataset.newsCategory;
        visible = 9;
        document.querySelectorAll('[data-news-category]').forEach((item) => item.classList.toggle('active',item===button));
        render();
      });
    });

    document.querySelector('[data-news-load-more]')?.addEventListener('click', () => {
      visible += 9;
      render();
    });

    const years = [...new Set(all.map((article) => {
      const date = article.published_at || article.created_at;
      return date ? new Date(date).getFullYear() : null;
    }).filter(Boolean))].sort((a,b) => b-a);

    const archive = document.querySelector('[data-news-archive-years]');
    if (archive) {
      archive.innerHTML = years.map((year) => {
        const count = all.filter((article) => {
          const date = article.published_at || article.created_at;
          return date && new Date(date).getFullYear() === year;
        }).length;
        return `<button type="button" data-archive-year="${year}"><strong>${year}</strong><span>${count} stor${count===1?'y':'ies'}</span></button>`;
      }).join('') || '<p class="meta">No archived years yet.</p>';

      archive.querySelectorAll('[data-archive-year]').forEach((button) => {
        button.addEventListener('click', () => {
          const year = Number(button.dataset.archiveYear);
          const filtered = all.filter((article) => {
            const date = article.published_at || article.created_at;
            return date && new Date(date).getFullYear() === year;
          });
          list.innerHTML = filtered.map((article) => card(article,prefix)).join('');
          document.querySelector('#latest-articles')?.scrollIntoView({ behavior:'smooth' });
        });
      });
    }

    render();
  }

  async function boot() {
    const prefix = prefixForPage();
    let all, placements;
    try {
      [all,placements] = await Promise.all([publishedArticles('nffl'),placementMap('nffl')]);
    } catch (error) {
      console.warn('Unified article presentation failed:',error.message);
      return;
    }

    document.querySelectorAll('[data-article-placement-group]').forEach((root) => {
      const key = root.dataset.articlePlacementGroup;
      const limit = Number(root.dataset.placementLimit || 3);
      const articles = chosenArticles(all,placements,key,limit);

      if (key === 'homepage_hero') renderHomepageHero(root,articles,prefix);
      else if (key === 'homepage_headline') renderHomepageHeadlines(root,articles,prefix);
      else if (key === 'news_hero') renderNewsHero(root,articles,prefix);
      else renderCards(root,articles,prefix);
    });

    renderBreakingTicker(chosenArticles(all,placements,'breaking_ticker',4),prefix);
    await setupLatestNews(all,prefix);

    // Reinitialize rotators after article-driven markup is inserted.
    document.dispatchEvent(new CustomEvent('nffl-article-presentations-ready'));
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded',boot);
  else boot();
})();
