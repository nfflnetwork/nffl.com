
(function setupInlineEditorBridge() {
  if (!new URLSearchParams(location.search).has('admin_edit')) return;

  const parentOrigin = location.origin;
  let enabled = false;
  let selected = null;
  let toolbar = null;
  const originals = new Map();

  const selector = [
    '[data-site-element-key]',
    '[data-content-title]',
    '[data-content-body]',
    '[data-content-link]',
    '[data-supabase-content-key][data-supabase-field]',
    '[data-managed-item-id][data-managed-field]',
    '[data-article-id][data-article-field]'
  ].join(',');

  function protectedElement(el) {
    return window.NFFLStaticEditor?.isProtected?.(el) || false;
  }

  function identity(el) {
    if (!el || protectedElement(el)) return null;

    if (el.dataset.managedItemId && el.dataset.managedField) {
      return { storage:'managed_items', id:Number(el.dataset.managedItemId), field:el.dataset.managedField, element_type:typeOf(el) };
    }
    if (el.dataset.articleId && el.dataset.articleField) {
      return { storage:'articles', id:Number(el.dataset.articleId), field:el.dataset.articleField, element_type:typeOf(el) };
    }

    const contentRoot = el.closest('[data-supabase-content-key]');
    if (contentRoot) {
      let field = el.dataset.supabaseField;
      if (!field) {
        if (el.matches('[data-content-title]')) field = 'title';
        else if (el.matches('[data-content-body]')) field = 'body';
        else if (el.matches('[data-content-link]')) field = 'link_url';
      }
      if (field) {
        return { storage:'site_content', content_key:contentRoot.dataset.supabaseContentKey, field, element_type:typeOf(el) };
      }
    }

    if (el.dataset.siteElementKey) {
      return {
        storage:'site_elements',
        page_path:window.NFFLStaticEditor?.pagePath?.() || document.body.dataset.sitePagePath || location.pathname.replace(/^\/+/, ''),
        element_key:el.dataset.siteElementKey,
        element_type:typeOf(el)
      };
    }
    return null;
  }

  function typeOf(el) {
    if (el.tagName === 'IMG') return 'image';
    if (el.tagName === 'A') return 'link';
    return 'text';
  }

  function valueOf(el, id) {
    if (id.element_type === 'image') return { src:el.getAttribute('src') || '', alt_text:el.getAttribute('alt') || '' };
    if (id.element_type === 'link') return {
      text_value:el.textContent.trim(),
      href:el.getAttribute('href') || '',
      open_new_tab:el.getAttribute('target') === '_blank'
    };
    return { text_value:el.textContent };
  }

  function labelOf(el) {
    const section = el.closest('section,article,aside,header,footer,nav,main');
    const heading = section?.querySelector('h1,h2,h3,h4');
    return {
      sectionLabel: heading?.textContent.trim() ||
        (section?.tagName === 'HEADER' ? 'Header' :
         section?.tagName === 'FOOTER' ? 'Footer' :
         section?.tagName === 'NAV' ? 'Navigation' : 'Page Content'),
      preview: el.tagName === 'IMG'
        ? (el.getAttribute('alt') || el.getAttribute('src') || 'Image')
        : el.textContent.trim().slice(0,100)
    };
  }

  function post(type, payload={}) {
    parent.postMessage({ source:'nffl-inline-editor', type, ...payload }, parentOrigin);
  }

  function removeToolbar() {
    toolbar?.remove();
    toolbar = null;
  }

  function drawToolbar(el, id) {
    removeToolbar();
    toolbar = document.createElement('div');
    toolbar.className = 'nffl-inline-toolbar';
    toolbar.innerHTML = `
      <span>${id.element_type === 'image' ? 'Image' : id.element_type === 'link' ? 'Link' : 'Text'}</span>
      ${id.element_type === 'image' ? '<button data-action="inspect">Replace</button>' : ''}
      ${id.element_type === 'link' ? '<button data-action="inspect">Link</button>' : ''}
      ${id.element_type !== 'image' ? '<button data-action="focus">Edit</button>' : ''}
      <button data-action="undo">Undo</button>
      <button data-action="done">Done</button>
    `;
    document.body.appendChild(toolbar);

    const rect = el.getBoundingClientRect();
    toolbar.style.top = `${Math.max(8, scrollY + rect.top - toolbar.offsetHeight - 10)}px`;
    toolbar.style.left = `${Math.max(8, Math.min(scrollX + rect.left, document.documentElement.scrollWidth - toolbar.offsetWidth - 8))}px`;

    toolbar.addEventListener('click', (event) => {
      const action = event.target.closest('[data-action]')?.dataset.action;
      if (!action) return;
      event.preventDefault();
      event.stopPropagation();
      if (action === 'focus') el.focus();
      if (action === 'inspect') post('open-inspector', { identity:id, value:valueOf(el,id), label:labelOf(el), tag:el.tagName.toLowerCase() });
      if (action === 'undo') post('undo-request');
      if (action === 'done') { el.blur(); removeToolbar(); }
    });
  }

  function select(el) {
    if (!enabled) return;
    const id = identity(el);
    if (!id) return;

    selected?.classList.remove('nffl-inline-selected');
    selected = el;
    selected.classList.add('nffl-inline-selected');

    const key = JSON.stringify(id);
    if (!originals.has(key)) originals.set(key, valueOf(el,id));
    drawToolbar(el,id);
    post('selected', { identity:id, value:valueOf(el,id), label:labelOf(el), tag:el.tagName.toLowerCase() });
  }

  function bind(el) {
    if (el.dataset.inlineEditorBound === 'true' || protectedElement(el)) return;
    const id = identity(el);
    if (!id) return;

    el.dataset.inlineEditorBound = 'true';
    el.classList.add('nffl-inline-editable');

    if (id.element_type !== 'image') {
      el.contentEditable = enabled ? 'true' : 'false';
      el.spellcheck = true;
    }

    el.addEventListener('click', (event) => {
      if (!enabled) return;
      event.preventDefault();
      event.stopPropagation();
      select(el);
    });

    el.addEventListener('dblclick', (event) => {
      if (!enabled) return;
      event.preventDefault();
      event.stopPropagation();
      select(el);
      if (id.element_type !== 'image') el.focus();
    });

    el.addEventListener('input', () => {
      if (!enabled) return;
      const current = identity(el);
      if (current) post('draft', { identity:current, value:valueOf(el,current) });
    });
  }

  function scan(root=document) {
    window.NFFLStaticEditor?.scan?.(root);
    const nodes = [];
    if (root instanceof Element && root.matches(selector)) nodes.push(root);
    root.querySelectorAll?.(selector).forEach((el) => nodes.push(el));
    nodes.forEach(bind);
  }

  function enable() {
    enabled = true;
    document.documentElement.classList.add('nffl-inline-editor-active');
    scan(document);
    document.querySelectorAll('.nffl-inline-editable').forEach((el) => {
      const id = identity(el);
      if (id?.element_type !== 'image') el.contentEditable = 'true';
    });
    post('ready', {
      page_path:window.NFFLStaticEditor?.pagePath?.() || '',
      count:document.querySelectorAll('.nffl-inline-editable').length,
      sections: window.NFFLPageSections?.list?.() || []
    });
  }

  function disable() {
    enabled = false;
    document.documentElement.classList.remove('nffl-inline-editor-active');
    document.querySelectorAll('.nffl-inline-editable').forEach((el) => {
      el.classList.remove('nffl-inline-selected');
      el.removeAttribute('contenteditable');
    });
    selected = null;
    removeToolbar();
  }

  function findByIdentity(id) {
    if (selected && JSON.stringify(identity(selected)) === JSON.stringify(id)) return selected;
    if (id.storage === 'site_elements') return document.querySelector(`[data-site-element-key="${CSS.escape(id.element_key)}"]`);
    if (id.storage === 'managed_items') return document.querySelector(`[data-managed-item-id="${id.id}"][data-managed-field="${CSS.escape(id.field)}"]`);
    if (id.storage === 'articles') return document.querySelector(`[data-article-id="${id.id}"][data-article-field="${CSS.escape(id.field)}"]`);
    if (id.storage === 'site_content') {
      const root = document.querySelector(`[data-supabase-content-key="${CSS.escape(id.content_key)}"]`);
      if (!root) return null;
      if (id.field === 'title') return root.querySelector('[data-content-title]') || root;
      if (id.field === 'body') return root.querySelector('[data-content-body]') || root;
      if (id.field === 'link_url') return root.querySelector('[data-content-link]') || root;
    }
    return null;
  }

  function apply(id, value) {
    const el = findByIdentity(id);
    if (!el) return;
    if (id.element_type === 'image') {
      if (value.src !== undefined) el.src = value.src;
      if (value.alt_text !== undefined) el.alt = value.alt_text;
    } else {
      if (value.text_value !== undefined) el.textContent = value.text_value;
      if (id.element_type === 'link') {
        if (value.href !== undefined) el.href = value.href;
        if (value.open_new_tab) { el.target='_blank'; el.rel='noopener'; }
        else { el.removeAttribute('target'); el.removeAttribute('rel'); }
      }
    }
    if (el === selected) drawToolbar(el,id);
  }

  const observer = new MutationObserver((mutations) => {
    if (!enabled) return;
    mutations.forEach((mutation) => mutation.addedNodes.forEach((node) => {
      if (node instanceof Element) scan(node);
    }));
  });
  observer.observe(document.documentElement, { childList:true, subtree:true });

  window.addEventListener('message', (event) => {
    if (event.origin !== parentOrigin || event.source !== parent) return;
    const msg = event.data || {};
    if (msg.source !== 'nffl-admin-visual-editor') return;
    if (msg.type === 'enable') enable();
    if (msg.type === 'disable') disable();
    if (msg.type === 'apply-value') apply(msg.identity,msg.value || {});
    if (msg.type === 'move-section') {
      const moved = window.NFFLPageSections?.move?.(msg.section_key, msg.direction);
      post('sections-updated', {
        moved: Boolean(moved),
        sections: window.NFFLPageSections?.list?.() || []
      });
    }
    if (msg.type === 'request-sections') {
      post('sections-updated', {
        moved: false,
        sections: window.NFFLPageSections?.list?.() || []
      });
    }
    if (msg.type === 'restore-original' && selected) {
      const id = identity(selected);
      const original = originals.get(JSON.stringify(id));
      if (original) apply(id,original);
    }
  });

  window.addEventListener('keydown', (event) => {
    if (!enabled) return;
    if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 's') { event.preventDefault(); post('save-request'); }
    if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 'z') { event.preventDefault(); post(event.shiftKey ? 'redo-request' : 'undo-request'); }
    if (event.key === 'Escape') { selected?.blur(); selected?.classList.remove('nffl-inline-selected'); selected=null; removeToolbar(); }
  });

  post('bridge-loaded');
})();
