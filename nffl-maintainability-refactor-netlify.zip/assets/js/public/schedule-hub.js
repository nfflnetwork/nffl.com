
(function setupStaticScheduleHub() {
  const root = document.querySelector('main[data-managed-content-type="schedule_game"]');
  if (!root) return;

  const search = root.querySelector('[data-schedule-search]');
  const weekSelect = root.querySelector('[data-schedule-week-select]');
  const visibleCount = root.querySelector('[data-schedule-visible-count]');
  const tabs = [...root.querySelectorAll('.schedule-tab')];
  const panels = [...root.querySelectorAll('[data-schedule-week-panel]')];
  const client = window.nfflPublicSupabase;

  let currentWeek = 1;

  function activePanel() {
    return root.querySelector(`[data-schedule-week-panel="${currentWeek}"]`);
  }

  function filterVisible() {
    const panel = activePanel();
    if (!panel) return;
    const query = (search?.value || '').trim().toLowerCase();
    let count = 0;

    panel.querySelectorAll('.matchup').forEach((item) => {
      const show = !query || item.textContent.toLowerCase().includes(query);
      item.hidden = !show;
      if (show) count += 1;
    });

    if (visibleCount) visibleCount.textContent = String(count);
    const games = root.querySelector('[data-schedule-stat="games"]');
    if (games) games.textContent = String(panel.querySelectorAll('.matchup').length);
  }

  function updateStaticCounters() {
    const completed = root.querySelector('[data-schedule-stat="completed"]');
    const remaining = root.querySelector('[data-schedule-stat="remaining"]');
    if (completed) completed.textContent = '0';
    if (remaining) remaining.textContent = '84';
  }

  async function loadGotw(week) {
    if (!client) return;
    try {
      const { data, error } = await client
        .from('site_content')
        .select('title,body,image_url,metadata')
        .eq('content_key',`nffl.schedule.gotw.week${week}`)
        .maybeSingle();

      if (error || !data) return;

      const meta = data.metadata || {};
      const set = (selector,value) => {
        const node = root.querySelector(selector);
        if (node && value) node.textContent = String(value);
      };

      set('[data-gotw-away]',meta.away_name);
      set('[data-gotw-home]',meta.home_name);
      set('[data-gotw-away-score]','—');
      set('[data-gotw-home-score]','—');
      set('[data-gotw-status]',`Week ${week} • ${data.title || 'Game of the Week'}`);

      const preview = root.querySelector('.schedule-gotw .section-header .meta');
      if (preview && data.body) preview.textContent = data.body;

      const card = root.querySelector('.schedule-gotw-card');
      if (card && data.image_url) {
        card.style.backgroundImage =
          `linear-gradient(rgba(8,15,25,.78),rgba(8,15,25,.78)),url("${data.image_url.replaceAll('"','%22')}")`;
        card.style.backgroundSize = 'cover';
        card.style.backgroundPosition = 'center';
      }
    } catch (error) {
      console.warn('Could not load saved Game of the Week:', error.message);
    }
  }

  function showWeek(week) {
    currentWeek = Math.max(1, Math.min(14, Number(week) || 1));

    panels.forEach((panel) => {
      panel.classList.toggle('active', Number(panel.dataset.scheduleWeekPanel) === currentWeek);
    });

    tabs.forEach((tab) => {
      const tabWeek = Number(tab.dataset.scheduleWeek || tab.textContent.match(/\d+/)?.[0] || 1);
      tab.classList.toggle('active', tabWeek === currentWeek);
    });

    if (weekSelect) weekSelect.value = String(currentWeek);

    const weekStat = root.querySelector('[data-schedule-stat="week"]');
    if (weekStat) weekStat.textContent = `Week ${currentWeek}`;

    filterVisible();
    updateStaticCounters();
    loadGotw(currentWeek);
  }

  tabs.forEach((tab) => {
    const week = Number(tab.textContent.match(/\d+/)?.[0] || 1);
    tab.dataset.scheduleWeek = String(week);
    tab.removeAttribute('onclick');
    tab.addEventListener('click', () => showWeek(week));
  });

  weekSelect?.addEventListener('change', () => showWeek(weekSelect.value));
  search?.addEventListener('input', filterVisible);

  showWeek(1);
})();
