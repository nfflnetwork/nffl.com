
(function setupIndividualTeamHub() {
  const main = document.querySelector('main[data-live-owner-league="nffl"][data-team-key]');
  if (!main) return;

  const storageKey = `nffl-team-sections:${main.dataset.teamKey || 'team'}`;

  function savedState() {
    try {
      return JSON.parse(localStorage.getItem(storageKey) || '{}');
    } catch (_) {
      return {};
    }
  }

  function saveState(state) {
    try {
      localStorage.setItem(storageKey, JSON.stringify(state));
    } catch (_) {}
  }

  function applySectionState(section, collapsed) {
    section.dataset.teamSectionCollapsed = collapsed ? 'true' : 'false';
    const button = section.querySelector(':scope > [data-team-section-toggle]');
    if (button) {
      button.setAttribute('aria-expanded', String(!collapsed));
      button.textContent = collapsed ? 'Expand' : 'Collapse';
    }
  }

  const state = savedState();
  document.querySelectorAll('.team-hub-section').forEach((section) => {
    const initial = Object.prototype.hasOwnProperty.call(state, section.id)
      ? Boolean(state[section.id])
      : section.dataset.teamSectionCollapsed === 'true';
    applySectionState(section, initial);

    section.querySelector(':scope > [data-team-section-toggle]')?.addEventListener('click', () => {
      const collapsed = section.dataset.teamSectionCollapsed !== 'true';
      applySectionState(section, collapsed);
      state[section.id] = collapsed;
      saveState(state);
    });
  });

  document.querySelectorAll('.team-hub-jumpnav a').forEach((link) => {
    link.addEventListener('click', (event) => {
      const section = document.querySelector(link.getAttribute('href'));
      if (!section) return;
      event.preventDefault();
      applySectionState(section, false);
      state[section.id] = false;
      saveState(state);
      section.scrollIntoView({
        behavior: window.matchMedia?.('(prefers-reduced-motion: reduce)').matches ? 'auto' : 'smooth',
        block:'start'
      });
      history.replaceState(null,'',`#${section.id}`);
    });
  });


  function isLoadingText(value) {
    return /loading|finding|fetching/i.test(String(value || ''));
  }

  function applyLoadingStates() {
    document.querySelectorAll('.team-live-section').forEach((section) => {
      const status = section.querySelector('.meta');
      section.classList.toggle('is-loading', isLoadingText(status?.textContent));
    });
  }

  function replaceGenericEmptyStates() {
    const rosterRows = document.querySelectorAll('#roster [data-roster-list] tr');
    rosterRows.forEach((row) => {
      const text = row.textContent.trim().toLowerCase();
      if (/no roster match|no sleeper roster|loading/.test(text)) return;
      if (/no .*found|no players|empty/.test(text)) {
        row.innerHTML = '<td colspan="4"><div class="team-empty-state"><span>🏈</span><strong>No roster entries available</strong><p>Player information will appear here when it becomes available.</p></div></td>';
      }
    });

    const pickRows = document.querySelectorAll('#picks [data-draft-picks-list] tr');
    pickRows.forEach((row) => {
      const text = row.textContent.trim().toLowerCase();
      if (/no future picks|no .*found/.test(text)) {
        row.innerHTML = '<td colspan="3"><div class="team-empty-state"><span>🗓️</span><strong>No future picks listed</strong><p>Draft capital will appear here when available.</p></div></td>';
      }
    });

    document.querySelectorAll('#transactions [data-team-transactions-list] .transaction-item').forEach((item) => {
      const text = item.textContent.trim().toLowerCase();
      if (/no recent moves|no transactions/.test(text)) {
        item.classList.add('team-empty-state-card');
        item.innerHTML = '<span>🔄</span><h3>No recent transactions</h3><p>The franchise has no recent moves to display.</p>';
      }
    });

    const timelineList = document.querySelector('#timeline [data-team-franchise-timeline]');
    if (timelineList && !timelineList.children.length) {
      timelineList.innerHTML = '<div class="team-empty-state"><span>📌</span><strong>No timeline events recorded</strong><p>Major franchise milestones will appear here.</p></div>';
    }

    const staffList = document.querySelector('#staff [data-team-staff-history]');
    if (staffList && !staffList.children.length) {
      staffList.innerHTML = '<div class="team-empty-state"><span>📝</span><strong>No staff history recorded</strong><p>Coaching history will appear here.</p></div>';
    }
  }

  function animateSnapshotValues() {
    if (window.matchMedia?.('(prefers-reduced-motion: reduce)').matches) return;
    document.querySelectorAll('#overview .history-stat strong').forEach((node) => {
      if (node.dataset.animatedCounter) return;
      const raw = node.textContent.trim();
      if (!/^\d+$/.test(raw)) return;
      const target = Number(raw);
      node.dataset.animatedCounter = 'true';
      let start = 0;
      const duration = 500;
      const started = performance.now();

      function frame(now) {
        const progress = Math.min(1, (now - started) / duration);
        const eased = 1 - Math.pow(1 - progress, 3);
        node.textContent = String(Math.round(start + (target - start) * eased));
        if (progress < 1) requestAnimationFrame(frame);
      }
      requestAnimationFrame(frame);
    });
  }

  const rosterSection = document.querySelector('#roster');
  const rosterSearch = rosterSection?.querySelector('[data-roster-search]');
  const rosterPosition = rosterSection?.querySelector('[data-roster-position]');
  const rosterBody = rosterSection?.querySelector('[data-roster-list]');

  function filterRoster() {
    if (!rosterBody) return;
    const query = (rosterSearch?.value || '').trim().toLowerCase();
    const position = rosterPosition?.value || 'all';

    rosterBody.querySelectorAll('tr').forEach((row) => {
      const cells = [...row.querySelectorAll('td')];
      if (cells.length < 3) return;
      const player = cells[1]?.textContent.trim().toLowerCase() || '';
      const pos = cells[2]?.textContent.trim().toUpperCase() || '';
      const matchesSearch = !query || player.includes(query);
      const matchesPosition = position === 'all' || pos === position;
      row.hidden = !(matchesSearch && matchesPosition);
    });
  }

  rosterSearch?.addEventListener('input', filterRoster);
  rosterPosition?.addEventListener('change', filterRoster);

  if (rosterBody) {
    new MutationObserver(filterRoster).observe(rosterBody, { childList:true, subtree:true });
  }

  function mirrorSnapshotToTrophies() {
    const snapshotChampionships = document.querySelector('#overview [data-franchise-championships]');
    const snapshotRunnerUps = document.querySelector('#overview [data-franchise-runner-ups]');
    const trophyChampionships = document.querySelector('#trophies [data-franchise-championships]');
    const trophyRunnerUps = document.querySelector('#trophies [data-franchise-runner-ups]');

    if (snapshotChampionships && trophyChampionships) {
      trophyChampionships.textContent = snapshotChampionships.textContent;
    }
    if (snapshotRunnerUps && trophyRunnerUps) {
      trophyRunnerUps.textContent = snapshotRunnerUps.textContent;
    }
  }

  const snapshot = document.querySelector('#overview');
  if (snapshot) {
    new MutationObserver(mirrorSnapshotToTrophies).observe(snapshot, {
      childList:true,
      subtree:true,
      characterData:true
    });
  }
  mirrorSnapshotToTrophies();

  // Add semantic transaction-type classes after Sleeper injects the live cards.
  const transactionList = document.querySelector('[data-team-transactions-list]');
  function classifyTransactions() {
    transactionList?.querySelectorAll('.transaction-item').forEach((item) => {
      const text = item.textContent.toLowerCase();
      item.classList.toggle('team-move-trade', text.includes('trade'));
      item.classList.toggle('team-move-signing', text.includes('free agent') || text.includes('waiver') || text.includes('added'));
      item.classList.toggle('team-move-release', text.includes('dropped') || text.includes('release'));
      item.classList.toggle('team-move-draft', text.includes('draft'));
    });
  }
  if (transactionList) {
    new MutationObserver(() => {
      classifyTransactions();
      replaceGenericEmptyStates();
      applyLoadingStates();
    }).observe(transactionList, { childList:true, subtree:true });
    classifyTransactions();
  }

  document.querySelectorAll('.team-live-section').forEach((section) => {
    new MutationObserver(() => {
      applyLoadingStates();
      replaceGenericEmptyStates();
      animateSnapshotValues();
    }).observe(section, { childList:true, subtree:true, characterData:true });
  });

  applyLoadingStates();
  replaceGenericEmptyStates();
  animateSnapshotValues();
})();
