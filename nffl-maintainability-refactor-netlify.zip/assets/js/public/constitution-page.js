(function initPremiumConstitution() {
  const page = document.querySelector('[data-constitution-page]');
  if (!page) return;

  const articles = Array.from(page.querySelectorAll('.constitution-article'));
  const toc = page.querySelector('[data-constitution-toc]');
  const tocLinks = toc ? Array.from(toc.querySelectorAll('a[href^="#"]')) : [];
  const progress = document.querySelector('[data-constitution-progress]');
  const search = page.querySelector('[data-constitution-search]');
  const clear = page.querySelector('[data-constitution-clear]');
  const mobileToc = page.querySelector('[data-constitution-mobile-toc]');
  const pdf = page.querySelector('[data-constitution-pdf]');
  const count = page.querySelector('[data-constitution-count]');
  const content = page.querySelector('.constitution-content');
  const noResults = document.createElement('div');
  noResults.className = 'constitution-no-results';
  noResults.hidden = true;
  noResults.textContent = 'No constitution articles match that search.';
  content?.appendChild(noResults);

  if (count) count.textContent = `${articles.length} Articles`;

  const topButton = document.createElement('button');
  topButton.className = 'constitution-back-top';
  topButton.type = 'button';
  topButton.setAttribute('aria-label', 'Back to top');
  topButton.textContent = '↑';
  document.body.appendChild(topButton);

  function updateProgress() {
    if (!progress) return;
    const doc = document.documentElement;
    const max = doc.scrollHeight - doc.clientHeight;
    const pct = max > 0 ? (doc.scrollTop / max) * 100 : 0;
    progress.style.width = `${pct}%`;
    topButton.classList.toggle('visible', window.scrollY > 500);
  }

  function setActiveArticle() {
    let active = articles[0]?.id;
    const offset = 170;
    articles.forEach((article) => {
      if (!article.hidden && article.offsetTop - offset <= window.scrollY) active = article.id;
    });
    tocLinks.forEach((link) => link.classList.toggle('active', link.getAttribute('href') === `#${active}`));
  }

  function escapeRegExp(value) {
    return value.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  }

  function clearHighlights(root) {
    root.querySelectorAll('mark').forEach((mark) => mark.replaceWith(document.createTextNode(mark.textContent || '')));
    root.normalize();
  }

  function highlightText(root, query) {
    if (!query) return;
    const pattern = new RegExp(escapeRegExp(query), 'ig');
    const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, {
      acceptNode(node) {
        if (!node.nodeValue.trim() || node.parentElement?.tagName === 'MARK') return NodeFilter.FILTER_REJECT;
        pattern.lastIndex = 0;
        return pattern.test(node.nodeValue) ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_REJECT;
      }
    });
    const nodes = [];
    while (walker.nextNode()) nodes.push(walker.currentNode);
    nodes.forEach((node) => {
      const frag = document.createDocumentFragment();
      const text = node.nodeValue;
      pattern.lastIndex = 0;
      let last = 0;
      text.replace(pattern, (match, index) => {
        frag.append(document.createTextNode(text.slice(last, index)));
        const mark = document.createElement('mark');
        mark.textContent = match;
        frag.append(mark);
        last = index + match.length;
      });
      frag.append(document.createTextNode(text.slice(last)));
      node.replaceWith(frag);
    });
  }

  function runSearch() {
    const query = (search?.value || '').trim().toLowerCase();
    let visible = 0;
    articles.forEach((article) => {
      clearHighlights(article);
      const match = !query || article.textContent.toLowerCase().includes(query);
      article.hidden = !match;
      if (match) {
        visible += 1;
        highlightText(article, query);
      }
    });
    tocLinks.forEach((link) => {
      const id = link.getAttribute('href')?.slice(1);
      const article = id ? document.getElementById(id) : null;
      link.hidden = Boolean(article?.hidden);
    });
    noResults.hidden = visible !== 0;
    if (count) count.textContent = query ? `${visible} Matches` : `${articles.length} Articles`;
    setActiveArticle();
  }

  tocLinks.forEach((link) => {
    link.addEventListener('click', () => toc?.classList.remove('mobile-open'));
  });

  search?.addEventListener('input', runSearch);
  clear?.addEventListener('click', () => {
    if (search) search.value = '';
    runSearch();
    search?.focus();
  });
  mobileToc?.addEventListener('click', () => toc?.classList.toggle('mobile-open'));
  topButton.addEventListener('click', () => window.scrollTo({ top: 0, behavior: 'smooth' }));
  pdf?.addEventListener('click', () => window.print());

  window.addEventListener('scroll', () => {
    updateProgress();
    setActiveArticle();
  }, { passive: true });

  updateProgress();
  setActiveArticle();
})();
