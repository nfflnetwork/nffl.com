
(function setupStandingsPolish() {
  const root = document.querySelector('[data-sleeper-standings="nffl"]');
  if (!root) return;

  const tableBody = root.querySelector('#league-standings tbody');
  const search = root.querySelector('[data-standings-search]');
  const sort = root.querySelector('[data-standings-sort]');
  const visibleCount = root.querySelector('[data-standings-visible-count]');

  const pageMap = {
    'team allyotarola':'team-allyotarola.html',
    'team damianhartfield':'team-damianhartfield.html',
    '"tank" dell lover':'team-tank-dell-lover.html',
    'ricks and mortys':'team-ricks-and-mortys.html',
    'team elliottmintz':'team-elliottmintz.html',
    'cleveland browns':'team-cleveland-browns.html',
    'team djsp':'team-djsp.html',
    'the revengers':'team-djsp.html',
    'team nastybob':'team-nastybob.html',
    "brian's team":'team-brians-team.html',
    'team knightmare005':'team-knightmare005.html',
    'team carter867':'team-carter867.html',
    'birds':'team-birds.html'
  };

  function rows() {
    return [...tableBody.querySelectorAll('tr')].filter((row) => row.children.length >= 9);
  }

  function dataFromRow(row) {
    const c = [...row.children];
    return {
      row,
      rank:Number(c[0].textContent.trim()) || 99,
      team:c[1].textContent.trim(),
      coach:c[2].textContent.trim(),
      wins:Number(c[3].textContent.trim()) || 0,
      losses:Number(String(c[4].textContent).split('-')[0]) || 0,
      pf:Number(c[5].textContent.trim()) || 0,
      pa:Number(c[6].textContent.trim()) || 0,
      streak:c[7].textContent.trim(),
      division:c[8].textContent.trim()
    };
  }

  function standingsData() {
    return rows().map(dataFromRow);
  }

  function enhanceRows() {
    rows().forEach((row) => {
      if (row.dataset.enhanced) return;
      row.dataset.enhanced = 'true';
      const data = dataFromRow(row);
      const teamCell = row.children[1];
      const href = pageMap[data.team.toLowerCase()];
      if (href && !teamCell.querySelector('a')) {
        teamCell.innerHTML = `<a class="standings-team-link" href="${href}">${teamCell.textContent.trim()}</a>`;
      }
      row.tabIndex = 0;
      row.setAttribute('aria-expanded','false');
      row.addEventListener('click', (event) => {
        if (event.target.closest('a')) return;
        toggleDetails(row);
      });
      row.addEventListener('keydown', (event) => {
        if (event.key === 'Enter' || event.key === ' ') {
          event.preventDefault();
          toggleDetails(row);
        }
      });
    });
  }

  function toggleDetails(row) {
    const next = row.nextElementSibling;
    if (next?.classList.contains('standings-detail-row')) {
      next.remove();
      row.setAttribute('aria-expanded','false');
      return;
    }
    document.querySelectorAll('.standings-detail-row').forEach((item) => item.remove());
    rows().forEach((item) => item.setAttribute('aria-expanded','false'));
    const d = dataFromRow(row);
    const pct = (d.wins + d.losses) ? (d.wins / (d.wins + d.losses)).toFixed(3).replace(/^0/,'') : '.000';
    const diff = d.pf - d.pa;
    const detail = document.createElement('tr');
    detail.className = 'standings-detail-row';
    detail.innerHTML = `<td colspan="9">
      <div class="standings-detail-grid">
        <article><span>Win %</span><strong>${pct}</strong></article>
        <article><span>Point Differential</span><strong>${diff >= 0 ? '+' : ''}${diff.toFixed(2)}</strong></article>
        <article><span>Division</span><strong>${d.division}</strong></article>
        <article><span>Current Streak</span><strong>${d.streak || '-'}</strong></article>
      </div>
    </td>`;
    row.insertAdjacentElement('afterend',detail);
    row.setAttribute('aria-expanded','true');
  }

  function updateSnapshot(data) {
    const totalGames = Math.round(data.reduce((sum,t) => sum + t.wins + t.losses,0) / 2);
    const maxPlayed = Math.max(0,...data.map((t) => t.wins + t.losses));
    const pfLeader = [...data].sort((a,b)=>b.pf-a.pf)[0];
    const paLeader = [...data].filter(t => t.wins+t.losses>0).sort((a,b)=>a.pa-b.pa)[0];
    const set = (key,value) => {
      const node = root.querySelector(`[data-standings-stat="${key}"]`);
      if (node) node.textContent = value;
    };
    set('week', maxPlayed ? `Week ${maxPlayed}` : 'Preseason');
    set('teams', data.length);
    set('games', totalGames);
    set('pf-leader', maxPlayed && pfLeader ? pfLeader.team : 'Season not started');
    set('pa-leader', maxPlayed && paLeader ? paLeader.team : 'Season not started');
    set('cutline','Top 8');
  }

  function divisionLeaders(data) {
    const divisions = ['East','North','West','South'];
    return divisions.map((division) => {
      const teams = data.filter((t)=>t.division===division).sort((a,b)=>b.wins-a.wins || a.losses-b.losses || b.pf-a.pf);
      return teams[0] || null;
    }).filter(Boolean);
  }

  function updatePlayoffs(data) {
    const leaders = divisionLeaders(data);
    const leaderTeams = new Set(leaders.map(t=>t.team));
    const wildcards = data.filter(t=>!leaderTeams.has(t.team))
      .sort((a,b)=>b.wins-a.wins || a.losses-b.losses || b.pf-a.pf).slice(0,4);
    const seeds = [...leaders,...wildcards]
      .sort((a,b)=>b.wins-a.wins || a.losses-b.losses || b.pf-a.pf)
      .slice(0,8);
    const firstOut = data.filter(t=>!seeds.some(s=>s.team===t.team))
      .sort((a,b)=>b.wins-a.wins || a.losses-b.losses || b.pf-a.pf)[0];

    const list = root.querySelector('[data-playoff-picture-list]');
    if (list) {
      list.innerHTML = seeds.map((t,i)=>`
        <div class="playoff-seed ${i<4?'division-seed':'wildcard-seed'}">
          <span>${i+1}</span><strong>${t.team}</strong><small>${t.wins}-${t.losses}</small>
        </div>`).join('') +
        (firstOut ? `<div class="playoff-seed first-out"><span>9</span><strong>${firstOut.team}</strong><small>First team out</small></div>` : '');
    }
  }

  function updateDivisionRace(data) {
    const list = root.querySelector('[data-division-race-list]');
    if (!list) return;
    list.innerHTML = ['East','North','West','South'].map((division)=>{
      const teams = data.filter(t=>t.division===division).sort((a,b)=>b.wins-a.wins || a.losses-b.losses || b.pf-a.pf);
      if (!teams.length) return '';
      const leader = teams[0];
      const second = teams[1];
      const gb = second ? Math.max(0, ((leader.wins-second.wins)+(second.losses-leader.losses))/2) : 0;
      return `<div class="division-race-item"><span>${division}</span><strong>${leader.team}</strong><small>${leader.wins}-${leader.losses}${second ? ` • ${gb.toFixed(1)} GB` : ''}</small></div>`;
    }).join('');
  }

  function filterSort() {
    enhanceRows();
    let data = standingsData();
    const query = (search?.value || '').trim().toLowerCase();
    const mode = sort?.value || 'rank';

    data.forEach((item) => {
      item.row.hidden = !!query && !`${item.team} ${item.coach}`.toLowerCase().includes(query);
    });

    const visible = data.filter((item)=>!item.row.hidden);
    if (visibleCount) visibleCount.textContent = visible.length;

    const sorter = {
      rank:(a,b)=>a.rank-b.rank,
      wins:(a,b)=>b.wins-a.wins || a.losses-b.losses || b.pf-a.pf,
      pf:(a,b)=>b.pf-a.pf,
      pa:(a,b)=>a.pa-b.pa,
      name:(a,b)=>a.team.localeCompare(b.team)
    }[mode];

    [...data].sort(sorter).forEach((item)=>tableBody.appendChild(item.row));
    updateSnapshot(data);
    updatePlayoffs(data);
    updateDivisionRace(data);
  }

  search?.addEventListener('input',filterSort);
  sort?.addEventListener('change',filterSort);

  new MutationObserver(() => {
    if (window.__standingsPolishBusy) return;
    window.__standingsPolishBusy = true;
    requestAnimationFrame(() => {
      enhanceRows();
      filterSort();
      window.__standingsPolishBusy = false;
    });
  }).observe(tableBody,{childList:true});

  enhanceRows();
  filterSort();
})();
