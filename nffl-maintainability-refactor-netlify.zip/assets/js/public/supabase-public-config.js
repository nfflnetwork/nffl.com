// Public Supabase browser configuration.
// Shared connection values are defined once in assets/js/config.js.

if (window.supabase?.createClient) {
  window.nfflPublicSupabase = window.supabase.createClient(
    window.NFFL_SUPABASE_URL,
    window.NFFL_SUPABASE_PUBLISHABLE_KEY,
    {
      auth: {
        persistSession: false,
        autoRefreshToken: false,
        detectSessionInUrl: false
      }
    }
  );
}
