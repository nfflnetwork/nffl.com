
(function setupHistoryHub() {
  const root = document.querySelector('.history-page');
  if (!root) return;

  const client = window.nfflPublicSupabase;
  const search = root.querySelector('[data-history-search]');
  const jump = root.querySelector('[data-history-jump]');
  const count = root.querySelector('[data-history-result-count]');


  async function loadEditablePageContent() {
    if (!client) return;
    const keys = [
      'history.hero_title','history.hero_body','history.founded','history.teams',
      'history.current_season','history.archive_status','history.featured_title',
      'history.featured_body','history.featured_link'
    ];

    const {data,error} = await client.from('site_content')
      .select('content_key,title,body')
      .in('content_key',keys);

    if (error) return;
    const map = Object.fromEntries((data || []).map((row)=>[row.content_key,row.body || row.title]));

    const set = (selector,key) => {
      const value = map[`history.${key}`];
      if (!value) return;
      root.querySelectorAll(selector).forEach((node)=>node.textContent=value);
    };

    set('.history-hero h1','hero_title');
    set('.history-hero p','hero_body');
    const stats = root.querySelectorAll('.history-stat-card strong');
    if (stats[0] && map['history.founded']) stats[0].textContent = map['history.founded'];
    if (stats[1] && map['history.teams']) stats[1].textContent = map['history.teams'];
    if (stats[2] && map['history.current_season']) stats[2].textContent = map['history.current_season'];
    if (stats[3] && map['history.archive_status']) stats[3].textContent = map['history.archive_status'];

    const feature = root.querySelector('.history-feature-panel');
    if (feature) {
      if (map['history.featured_title']) feature.querySelector('h2').textContent = map['history.featured_title'];
      if (map['history.featured_body']) feature.querySelector('p').textContent = map['history.featured_body'];
      if (map['history.featured_link']) feature.querySelector('a').href = map['history.featured_link'];
    }
  }

  async function enhanceManagedHistory() {
    if (!client) return;
    const {data,error} = await client.from('managed_items')
      .select('*')
      .eq('league','nffl')
      .eq('content_type','history_item')
      .eq('is_active',true)
      .order('rank',{ascending:true});

    if (error || !data?.length) return;

    const championships = data.filter((row)=>row.metadata?.kind==='championship');
    const timeline = data.filter((row)=>row.metadata?.kind==='timeline');

    const championshipRoot = root.querySelector('.championship-track');
    if (championshipRoot && championships.length) {
      championshipRoot.innerHTML = championships.map((row)=>`
        <article class="championship-card">
          <span>${escapeHtml(row.subtitle || row.season || '')}</span>
          <h3>${escapeHtml(row.title || '')}</h3>
          <p>Runner-up: ${escapeHtml(row.metadata?.runner_up || row.body?.replace(/^Runner-up:\s*/i,'') || 'TBD')}</p>
          <small>${escapeHtml(row.metadata?.best_record ? `Best record: ${row.metadata.best_record}` : 'Official championship record')}</small>
          ${row.metadata?.final_score ? `<b class="history-final-score">Final: ${escapeHtml(row.metadata.final_score)}</b>` : ''}
        </article>`).join('');
    }

    const timelineRoot = root.querySelector('.modern-timeline');
    if (timelineRoot && timeline.length) {
      timelineRoot.innerHTML = timeline.map((row)=>`
        <div class="timeline-event">
          <span>${escapeHtml(row.subtitle || row.season || '')}</span>
          <div><h3>${escapeHtml(row.title || '')}</h3><p>${escapeHtml(row.body || '')}</p></div>
        </div>`).join('');
    }
  }

  function escapeHtml(value) {
    return String(value ?? '')
      .replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;')
      .replaceAll('"','&quot;').replaceAll("'","&#039;");
  }

  function searchableItems() {
    return [
      ...root.querySelectorAll('.championship-card'),
      ...root.querySelectorAll('.timeline-event'),
      ...root.querySelectorAll('.season-card'),
      ...root.querySelectorAll('.history-hub-card')
    ];
  }

  function filterHistory() {
    const query = (search?.value || '').trim().toLowerCase();
    let visible = 0;

    searchableItems().forEach((item) => {
      const show = !query || item.textContent.toLowerCase().includes(query);
      item.hidden = !show;
      if (show) visible += 1;
    });

    if (count) count.textContent = query ? String(visible) : 'All';
  }

  search?.addEventListener('input', filterHistory);
  jump?.addEventListener('change', () => {
    if (!jump.value) return;
    document.getElementById(jump.value)?.scrollIntoView({
      behavior: window.matchMedia?.('(prefers-reduced-motion: reduce)').matches ? 'auto' : 'smooth',
      block: 'start'
    });
    jump.value = '';
  });

  const milestoneCount = root.querySelector('[data-history-milestone-count]');
  if (milestoneCount) milestoneCount.textContent = String(root.querySelectorAll('.timeline-event').length);

  const articleCount = root.querySelector('[data-history-article-count]');
  if (articleCount) {
    const links = new Set([...root.querySelectorAll('a[href*="articles"], a[href*="article-"]')].map((a) => a.href));
    articleCount.textContent = String(links.size);
  }

  Promise.allSettled([loadEditablePageContent(),enhanceManagedHistory()]).then(filterHistory);
})();
