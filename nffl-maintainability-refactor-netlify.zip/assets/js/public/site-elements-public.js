
(function setupUniversalEditableContent() {
  const SLEEPER_SELECTOR = [
    '[data-sleeper-roster]',
    '[data-sleeper-standings]',
    '[data-sleeper-transactions]',
    '[data-sleeper-team-transactions]',
    '[data-sleeper-draft-picks]',
    '[data-sleeper-draft-history]',
    '[data-sleeper-team-history]',
    '[data-sleeper-season-standings]',
    '[data-sleeper-season-playoffs]',
    '[data-home-transactions]',
    '[data-roster-list]',
    '[data-team-transactions-list]',
    '[data-draft-picks-list]',
    '[data-standings-list]'
  ].join(',');

  const STATIC_TAGS = 'h1,h2,h3,h4,h5,h6,p,span,strong,small,li,th,td,button,a,img,figcaption,label';
  const savedRows = new Map();

  function pagePath() {
    return document.body?.dataset.sitePagePath ||
      location.pathname.replace(/^\/+/, '') ||
      'index.html';
  }

  function isProtected(el) {
    return Boolean(
      el.closest(SLEEPER_SELECTOR) ||
      el.closest('script,style,template,noscript') ||
      el.matches('[data-no-visual-edit]') ||
      el.closest('[data-no-visual-edit]')
    );
  }

  function isUseful(el) {
    if (isProtected(el)) return false;
    if (el.matches('img')) return Boolean(el.getAttribute('src'));
    if (el.matches('a')) return Boolean(el.getAttribute('href') || el.textContent.trim());
    if (el.matches('button')) return Boolean(el.textContent.trim());
    const childTags = [...el.children].filter((child) => !child.matches('br'));
    return childTags.length === 0 && Boolean(el.textContent.trim());
  }

  function elementPath(el) {
    const parts = [];
    let node = el;
    while (node && node !== document.body) {
      const parent = node.parentElement;
      if (!parent) break;
      const same = [...parent.children].filter((child) => child.tagName === node.tagName);
      const index = same.indexOf(node) + 1;
      parts.unshift(`${node.tagName.toLowerCase()}:${index}`);
      node = parent;
    }
    return parts.join('/');
  }

  function keyFor(el) {
    if (el.dataset.siteElementKey) return el.dataset.siteElementKey;
    const raw = elementPath(el);
    let hash = 2166136261;
    for (let i = 0; i < raw.length; i += 1) {
      hash ^= raw.charCodeAt(i);
      hash = Math.imul(hash, 16777619);
    }
    return `auto-${(hash >>> 0).toString(36)}`;
  }

  function scan(root = document) {
    const nodes = [];
    if (root instanceof Element && root.matches(STATIC_TAGS)) nodes.push(root);
    root.querySelectorAll?.(STATIC_TAGS).forEach((el) => nodes.push(el));

    nodes.forEach((el) => {
      if (!isUseful(el)) return;
      if (
        el.dataset.managedItemId ||
        el.dataset.articleId ||
        el.dataset.supabaseContentKey ||
        el.closest('[data-supabase-content-key]') ||
        el.matches('[data-content-title],[data-content-body],[data-content-link]')
      ) return;

      el.dataset.siteElementKey = keyFor(el);
      el.dataset.siteElementSimple = el.matches('img') ? 'false' : 'true';
      el.dataset.autoEditable = 'true';
    });
    return nodes;
  }

  function applyRow(row) {
    const el = document.querySelector(`[data-site-element-key="${CSS.escape(row.element_key)}"]`);
    if (!el || isProtected(el)) return;

    if (row.element_type === 'image') {
      const currentSrc = el.getAttribute('src') || '';
      const nextSrc = typeof row.src === 'string' ? row.src.trim() : row.src;
      const isLogo = currentSrc.includes('nffl-logo') || /nffl logo/i.test(el.getAttribute('alt') || '');
      if (isLogo && (!nextSrc || nextSrc === '#')) return;
      if (nextSrc !== null && nextSrc !== undefined) el.setAttribute('src', nextSrc);
      if (row.alt_text !== null && row.alt_text !== undefined) el.setAttribute('alt', row.alt_text);
      return;
    }

    if (row.element_type === 'link') {
      if (row.href !== null && row.href !== undefined) el.setAttribute('href', row.href);
      if (row.open_new_tab) {
        el.target = '_blank';
        el.rel = 'noopener';
      } else {
        el.removeAttribute('target');
        el.removeAttribute('rel');
      }
    }

    if (row.text_value !== null && row.text_value !== undefined) {
      el.textContent = row.text_value;
    }
  }


  function sectionKey(section, index) {
    if (section.dataset.layoutSectionKey) return section.dataset.layoutSectionKey;
    const explicit = section.id || section.dataset.sectionKey || '';
    const heading = section.querySelector('h1,h2,h3');
    const label = explicit || heading?.textContent.trim() || `section-${index + 1}`;
    const normalized = String(label).toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '') || `section-${index + 1}`;
    section.dataset.layoutSectionKey = normalized;
    return normalized;
  }

  function editableSections() {
    const main = document.querySelector('main');
    if (!main) return [];
    return [...main.children].filter((section) => {
      if (!(section instanceof Element)) return false;
      if (isProtected(section)) return false;
      if (section.matches('script,style,template,noscript')) return false;
      return section.matches('section,article,div');
    }).map((section, index) => {
      const key = sectionKey(section, index);
      const heading = section.querySelector('h1,h2,h3');
      return {
        element: section,
        key,
        label: heading?.textContent.trim() || section.getAttribute('aria-label') || `Section ${index + 1}`
      };
    });
  }

  async function applySectionOrder() {
    const client = window.nfflPublicSupabase;
    const sections = editableSections();
    if (!client || !sections.length) return;

    const { data, error } = await client
      .from('page_section_order')
      .select('section_key,position')
      .eq('page_path', pagePath())
      .order('position', { ascending: true });

    if (error || !data?.length) {
      if (error) console.warn('Page section order could not load:', error.message);
      return;
    }

    const positions = new Map(data.map((row) => [row.section_key, Number(row.position)]));
    const ordered = [...sections].sort((a,b) => {
      const pa = positions.has(a.key) ? positions.get(a.key) : Number.MAX_SAFE_INTEGER;
      const pb = positions.has(b.key) ? positions.get(b.key) : Number.MAX_SAFE_INTEGER;
      return pa - pb;
    });

    const main = document.querySelector('main');
    ordered.forEach(({ element }) => main.appendChild(element));
  }

  window.NFFLPageSections = {
    list: () => editableSections().map(({ key, label }) => ({ key, label })),
    move: (sectionKeyValue, direction) => {
      const sections = editableSections();
      const index = sections.findIndex((item) => item.key === sectionKeyValue);
      const targetIndex = direction === 'up' ? index - 1 : index + 1;
      if (index < 0 || targetIndex < 0 || targetIndex >= sections.length) return false;
      const main = document.querySelector('main');
      const current = sections[index].element;
      const target = sections[targetIndex].element;
      if (direction === 'up') main.insertBefore(current, target);
      else main.insertBefore(target, current);
      return true;
    }
  };

  async function applySaved() {
    scan(document);
    const client = window.nfflPublicSupabase;
    if (!client) return;

    const rows = [];
    let start = 0;
    while (true) {
      const { data, error } = await client
        .from('site_elements')
        .select('*')
        .eq('page_path', pagePath())
        .eq('is_active', true)
        .range(start, start + 999);
      if (error) {
        console.warn('Editable site content could not load:', error.message);
        return;
      }
      rows.push(...(data || []));
      if (!data || data.length < 1000) break;
      start += 1000;
    }
    rows.forEach((row) => { savedRows.set(row.element_key, row); applyRow(row); });
    await applySectionOrder();
  }

  window.NFFLStaticEditor = { scan, isProtected, keyFor, pagePath, applyRow };

  const observer = new MutationObserver((mutations) => {
    mutations.forEach((mutation) => mutation.addedNodes.forEach((node) => {
      if (!(node instanceof Element)) return;
      scan(node);
      const candidates = [];
      if (node.dataset?.siteElementKey) candidates.push(node);
      node.querySelectorAll?.('[data-site-element-key]').forEach((el) => candidates.push(el));
      candidates.forEach((el) => {
        const row = savedRows.get(el.dataset.siteElementKey);
        if (row) applyRow(row);
      });
    }));
  });

  function boot() {
    scan(document);
    observer.observe(document.documentElement, { childList: true, subtree: true });
    applySaved();
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
  else boot();
})();
