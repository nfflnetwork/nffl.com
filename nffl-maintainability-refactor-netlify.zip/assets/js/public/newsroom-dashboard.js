
(function setupNewsroomDashboard() {
  const client = window.nfflPublicSupabase;
  const root = document.querySelector('[data-newsroom-dashboard]');
  if (!client || !root) return;

  function startOfToday() {
    const date = new Date();
    date.setHours(0,0,0,0);
    return date;
  }

  function startOfWeek() {
    const date = startOfToday();
    const day = date.getDay();
    const diff = day === 0 ? 6 : day - 1;
    date.setDate(date.getDate() - diff);
    return date;
  }

  function formatDate(value) {
    if (!value) return 'No published stories yet';
    return new Date(value).toLocaleString(undefined, {
      month:'short',
      day:'numeric',
      hour:'numeric',
      minute:'2-digit'
    });
  }

  function setText(selector, value) {
    const node = root.querySelector(selector);
    if (node && value !== null && value !== undefined && value !== '') {
      node.textContent = String(value);
    }
  }

  async function loadStats() {
    const { data, error } = await client
      .from('articles')
      .select('id,published_at,created_at,breaking,featured,status')
      .eq('league','nffl')
      .eq('status','published');

    if (error) {
      console.warn('Newsroom stats failed:', error.message);
      return;
    }

    const rows = data || [];
    const today = startOfToday();
    const week = startOfWeek();

    const publishedDate = (row) => new Date(row.published_at || row.created_at || 0);
    const todayCount = rows.filter((row) => publishedDate(row) >= today).length;
    const weekCount = rows.filter((row) => publishedDate(row) >= week).length;
    const breakingCount = rows.filter((row) => row.breaking).length;
    const featuredCount = rows.filter((row) => row.featured).length;
    const latest = [...rows].sort((a,b) => publishedDate(b) - publishedDate(a))[0];

    setText('[data-newsroom-stat="today"]', todayCount);
    setText('[data-newsroom-stat="week"]', weekCount);
    setText('[data-newsroom-stat="breaking"]', breakingCount);
    setText('[data-newsroom-stat="featured"]', featuredCount);
    setText('[data-newsroom-last-updated]', formatDate(latest?.published_at || latest?.created_at));
  }

  async function loadEditableContent() {
    const keys = [
      'newsroom.note',
      'newsroom.note.author',
      'newsroom.status.season',
      'newsroom.status.week',
      'newsroom.status.trade',
      'newsroom.status.waivers',
      'newsroom.status.next',
      'newsroom.status.health'
    ];

    const { data, error } = await client
      .from('site_content')
      .select('content_key,title,body')
      .in('content_key', keys);

    if (error) {
      console.warn('Newsroom content failed:', error.message);
      return;
    }

    const map = Object.fromEntries((data || []).map((row) => [row.content_key,row]));
    const note = map['newsroom.note'];
    if (note) {
      setText('[data-newsroom-note-title]', note.title);
      setText('[data-newsroom-note-body]', note.body);
    }
    const author = map['newsroom.note.author'];
    if (author?.body) setText('[data-newsroom-note-author]', author.body);

    const statusMap = {
      season:'newsroom.status.season',
      week:'newsroom.status.week',
      trade:'newsroom.status.trade',
      waivers:'newsroom.status.waivers',
      next:'newsroom.status.next',
      health:'newsroom.status.health'
    };

    Object.entries(statusMap).forEach(([field,key]) => {
      const row = map[key];
      if (row?.body) setText(`[data-newsroom-status="${field}"]`, row.body);
    });
  }

  async function boot() {
    await Promise.allSettled([loadStats(), loadEditableContent()]);
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
  else boot();
})();
