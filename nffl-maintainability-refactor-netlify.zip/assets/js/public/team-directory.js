
(function setupTeamDirectory() {
  const root = document.querySelector('[data-team-directory-controls]');
  const sections = [...document.querySelectorAll('[data-team-division-section]')];
  if (!root || !sections.length) return;

  const search = root.querySelector('#team-directory-search');
  const sort = root.querySelector('[data-team-sort]');
  const count = root.querySelector('[data-team-visible-count]');
  const filters = [...root.querySelectorAll('[data-team-division-filter]')];
  let activeDivision = 'all';

  function recordValue(value) {
    const match = String(value || '').match(/(\d+)\s*-\s*(\d+)/);
    if (!match) return 0;
    const wins = Number(match[1]);
    const losses = Number(match[2]);
    return wins * 1000 - losses;
  }

  function sortGrid(grid, mode) {
    const cards = [...grid.querySelectorAll('.team-card')];
    cards.sort((a,b) => {
      if (mode === 'name') {
        return a.dataset.teamName.localeCompare(b.dataset.teamName, undefined, { sensitivity:'base' });
      }
      if (mode === 'record') {
        const difference = recordValue(b.dataset.teamRecord) - recordValue(a.dataset.teamRecord);
        return difference || a.dataset.teamName.localeCompare(b.dataset.teamName, undefined, { sensitivity:'base' });
      }
      return Number(a.dataset.teamOriginalOrder) - Number(b.dataset.teamOriginalOrder);
    });
    cards.forEach((card) => grid.appendChild(card));
  }

  sections.forEach((section) => {
    [...section.querySelectorAll('.team-card')].forEach((card,index) => {
      card.dataset.teamOriginalOrder = index;
    });
  });

  function update() {
    const query = search.value.trim().toLowerCase();
    const mode = sort.value;
    let visible = 0;

    sections.forEach((section) => {
      const division = section.dataset.teamDivisionSection;
      const grid = section.querySelector('.teams-grid');
      sortGrid(grid, mode);

      let sectionVisible = 0;
      section.querySelectorAll('.team-card').forEach((card) => {
        const divisionMatch = activeDivision === 'all' || card.dataset.teamDivision === activeDivision;
        const searchMatch = !query || card.dataset.teamSearch.includes(query);
        const show = divisionMatch && searchMatch;
        card.hidden = !show;
        if (show) {
          visible += 1;
          sectionVisible += 1;
        }
      });

      section.hidden = sectionVisible === 0;
    });

    count.textContent = visible;
    document.querySelector('[data-team-directory-empty]')?.remove();

    if (visible === 0) {
      const empty = document.createElement('section');
      empty.className = 'team-directory-empty';
      empty.dataset.teamDirectoryEmpty = '';
      empty.innerHTML = '<span>🏈</span><h2>No teams found</h2><p>Try another team name, coach, or division.</p>';
      root.insertAdjacentElement('afterend', empty);
    }
  }

  filters.forEach((button) => {
    button.addEventListener('click', () => {
      activeDivision = button.dataset.teamDivisionFilter;
      filters.forEach((item) => item.classList.toggle('active', item === button));
      update();
    });
  });

  search.addEventListener('input', update);
  sort.addEventListener('change', update);
  update();
})();
