
(function setupLatestArticles() {
  const client = window.nfflPublicSupabase;
  const sections = [...document.querySelectorAll('[data-latest-articles]')];
  if (!client || !sections.length) return;

  const esc = (value) => String(value ?? '')
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#039;');

  function hrefFor(article, prefix = '') {
    return `${prefix}article.html?slug=${encodeURIComponent(article.slug)}`;
  }

  async function loadSection(section) {
    const league = section.dataset.latestArticles || 'nffl';
    const prefix = section.dataset.pathPrefix || '';

    const { data, error } = await client
      .from('articles')
      .select('id,title,slug,category,summary,image_url,published_at,created_at,status')
      .eq('league', league)
      .eq('status', 'published')
      .order('published_at', { ascending: false, nullsFirst: false })
      .order('created_at', { ascending: false })
      .limit(6);

    if (error || !data?.length) {
      if (error) console.warn('Latest articles failed to load:', error.message);
      return;
    }

    const [latest, ...rest] = data;
    const feature = section.querySelector('[data-latest-feature]');
    const list = section.querySelector('[data-latest-list]');

    if (feature) {
      feature.innerHTML = `
        <div class="latest-feature-media">
          <img
            data-article-id="${latest.id}"
            data-article-field="image_url"
            src="${esc(latest.image_url || `${prefix}assets/images/nffl-logo.png`)}"
            alt="${esc(latest.title)}">
        </div>
        <div class="latest-feature-copy">
          <span class="meta" data-article-id="${latest.id}" data-article-field="category">${esc(latest.category || 'League News')}</span>
          <h3 data-article-id="${latest.id}" data-article-field="title">${esc(latest.title)}</h3>
          <p data-article-id="${latest.id}" data-article-field="summary">${esc(latest.summary || '')}</p>
          <a class="button gold" data-article-id="${latest.id}" data-article-field="slug" href="${hrefFor(latest, prefix)}">Read Story</a>
        </div>
      `;
    }

    if (list) {
      list.innerHTML = rest.map((article) => `
        <a class="latest-article-row" data-article-id="${article.id}" data-article-field="slug" href="${hrefFor(article, prefix)}">
          <span class="latest-row-category" data-article-id="${article.id}" data-article-field="category">${esc(article.category || 'League News')}</span>
          <strong data-article-id="${article.id}" data-article-field="title">${esc(article.title)}</strong>
          <small>Read story →</small>
        </a>
      `).join('');
    }
  }

  async function boot() {
    await Promise.allSettled(sections.map(loadSection));
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
  else boot();
})();
