
(function () {
  const client = window.nfflPublicSupabase;
  if (!client) return;

  const esc = (value) => String(value ?? '')
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#039;');

  async function loadSiteContent() {
    const nodes = [...document.querySelectorAll('[data-supabase-content-key]')];
    if (!nodes.length) return;

    const keys = [...new Set(nodes.map((node) => node.dataset.supabaseContentKey).filter(Boolean))];
    const { data, error } = await client
      .from('site_content')
      .select('content_key,title,body,image_url')
      .in('content_key', keys);

    if (error || !data) {
      if (error) console.warn('Site content load failed:', error.message);
      return;
    }

    const map = Object.fromEntries(data.map((row) => [row.content_key, row]));
    nodes.forEach((node) => {
      const row = map[node.dataset.supabaseContentKey];
      if (!row) return;

      const titleTarget = node.querySelector('[data-content-title]');
      const bodyTarget = node.querySelector('[data-content-body]');
      const imageTarget = node.querySelector('[data-content-image]');

      if (titleTarget && row.title) titleTarget.textContent = row.title;
      if (bodyTarget && row.body) bodyTarget.textContent = row.body;
      if (imageTarget && row.image_url) imageTarget.src = row.image_url;

      if (!titleTarget && !bodyTarget && !imageTarget) {
        const field = node.dataset.supabaseField || 'body';
        const value = row[field];
        if (value) {
          if (node.matches('img')) node.src = value;
          else node.textContent = value;
        }
      }
    });
  }

  function articleCard(article, prefix = '') {
    const image = article.image_url || `${prefix}assets/images/nffl-logo-new.png`;
    const href = `${prefix}article.html?slug=${encodeURIComponent(article.slug)}`;
    return `
      <article class="article-card">
        <div class="article-media"><img src="${esc(image)}" alt=""></div>
        <div class="article-body">
          <span class="meta">${esc(article.category || article.league || 'NFFL')}</span>
          <h3>${esc(article.title)}</h3>
          <p>${esc(article.summary || '')}</p>
          <a class="button" href="${href}">Read More</a>
        </div>
      </article>
    `;
  }

  async function loadArticles() {
    const sections = [...document.querySelectorAll('[data-supabase-articles]')];
    if (!sections.length) return;

    for (const section of sections) {
      const league = section.dataset.supabaseArticles || 'nffl';
      const limit = Number(section.dataset.articleLimit || 12);
      let query = client
        .from('articles')
        .select('title,slug,category,summary,image_url,league,published_at,created_at,featured,status')
        .eq('status', 'published')
        .order('featured', { ascending: false })
        .order('published_at', { ascending: false, nullsFirst: false })
        .limit(limit);

      if (league !== 'all') query = query.eq('league', league);
      const { data, error } = await query;

      if (error || !data?.length) {
        if (error) console.warn('Article load failed:', error.message);
        continue; // Keep the static fallback cards.
      }

      const target = section.querySelector('[data-supabase-article-list]') || section;
      const prefix = section.dataset.pathPrefix || '';
      target.innerHTML = data.map((article) => articleCard(article, prefix)).join('');
      section.classList.add('supabase-loaded');
    }
  }

  async function loadSingleArticle() {
    const root = document.querySelector('[data-supabase-single-article]');
    if (!root) return;

    const slug = new URLSearchParams(location.search).get('slug');
    if (!slug) return;

    const { data, error } = await client
      .from('articles')
      .select('*')
      .eq('slug', slug)
      .eq('status', 'published')
      .maybeSingle();

    if (error || !data) {
      root.innerHTML = '<section class="page-title"><h1>Article unavailable</h1><p>This story could not be found.</p></section>';
      return;
    }

    document.title = `${data.title} | NFFL Network`;
    root.innerHTML = `
      <section class="page-title">
        <span class="eyebrow">${esc(data.category || data.league)}</span>
        <h1>${esc(data.title)}</h1>
        <p>${esc(data.summary || '')}</p>
      </section>
      ${data.image_url ? `<section class="section article-lead-image"><img src="${esc(data.image_url)}" alt=""></section>` : ''}
      <section class="section article-body supabase-article-body">${esc(data.body || '').replace(/\n/g, '<br>')}</section>
    `;
  }

  async function loadAwards() {
    const roots = [...document.querySelectorAll('[data-supabase-awards]')];
    for (const root of roots) {
      const league = root.dataset.supabaseAwards;
      const season = Number(root.dataset.awardsSeason || new Date().getFullYear());
      const { data, error } = await client
        .from('awards')
        .select('*')
        .eq('league', league)
        .eq('season', season);

      if (error || !data?.length) {
        if (error) console.warn('Awards load failed:', error.message);
        continue;
      }

      data.forEach((award) => {
        const week = award.week ?? 0;
        const panel = root.querySelector(`[data-awards-panel="${week || 17}"]`);
        if (!panel) return;

        const cards = [...panel.querySelectorAll('.award-placeholder, .yearly-race-card, .yearly-winner-card')];
        const card = cards.find((item) => item.querySelector('h3')?.textContent.trim() === award.award_name);
        if (!card) return;

        if (award.week) {
          const strong = card.querySelector('strong');
          if (strong) strong.textContent = award.winner || award.first_place || 'TBD';
        } else if (week === 0 || award.is_final) {
          const strong = card.querySelector('strong');
          if (strong) strong.textContent = award.winner || award.first_place || 'TBD';
        }

        const listItems = card.querySelectorAll('li');
        if (listItems.length) {
          if (listItems[0]) listItems[0].textContent = `1. ${award.first_place || 'TBD'}`;
          if (listItems[1]) listItems[1].textContent = `2. ${award.second_place || 'TBD'}`;
          if (listItems[2]) listItems[2].textContent = `3. ${award.third_place || 'TBD'}`;
        }
      });
    }
  }

  async function loadHotSeat() {
    const root = document.querySelector('[data-supabase-hot-seat]');
    if (!root) return;

    const season = Number(root.dataset.hotSeatSeason || new Date().getFullYear());
    const { data, error } = await client
      .from('hot_seat')
      .select('*')
      .eq('season', season)
      .eq('is_active', true)
      .order('rank', { ascending: true });

    if (error || !data?.length) {
      if (error) console.warn('Hot Seat load failed:', error.message);
      return;
    }

    root.innerHTML = data.map((row, index) => {
      const cls = index === 0 ? 'hot-seat-danger' : index < 3 ? 'hot-seat-warm' : 'hot-seat-safe';
      return `<div class="rank-item ${cls}"><h3>${esc(row.rank || index + 1)}. ${esc(row.coach_name)}</h3><p><strong>${esc(row.status || 'Monitoring')}</strong>${row.team_name ? ` • ${esc(row.team_name)}` : ''}</p><p>${esc(row.description || '')}</p></div>`;
    }).join('');
  }

  async function loadTeamContent() {
    const roots = [...document.querySelectorAll('[data-supabase-team-content]')];
    for (const root of roots) {
      const league = root.dataset.supabaseTeamContent;
      const teamKey = root.dataset.teamKey;
      if (!league || !teamKey) continue;

      const { data, error } = await client
        .from('team_content')
        .select('*')
        .eq('league', league)
        .eq('team_key', teamKey)
        .maybeSingle();

      if (error || !data) {
        console.error('[Teams CMS] Public Team load failed:', error?.message || 'No Supabase record found.', { league, teamKey });
        continue;
      }
      root.__nfflTeamContent = data;

      const textMap = {
        '[data-team-about]': data.about_coach,
        '[data-team-franchise-notes]': data.franchise_notes,
        '[data-team-news-copy]': data.team_news,
        '[data-team-coach-name]': data.coach_name,
        '[data-team-name-copy]': data.team_name,
        '[data-team-current-team]': data.current_team || data.team_name,
        '[data-team-division]': data.division,
        '[data-team-status]': data.status,
        '[data-team-coach-record]': data.coach_record,
        '[data-team-current-record]': data.current_record,
        '[data-team-last-game]': data.last_game,
        '[data-team-next-game]': data.next_game,
        '[data-team-established]': data.established_year,
        '[data-franchise-current-record]': data.current_record,
        '[data-franchise-all-time-record]': data.all_time_record,
        '[data-franchise-championships]': data.championships,
        '[data-franchise-runner-ups]': data.runner_up_finishes,
        '[data-franchise-division-titles]': data.division_titles,
        '[data-franchise-hall-of-fame]': data.hall_of_fame_members,
        '[data-team-season-vault-note]': data.season_vault_note,
        '[data-team-trophy-notes]': data.trophy_notes,
        '[data-franchise-best-finish]': data.best_finish,
        '[data-franchise-best-record]': data.best_record
      };

      Object.entries(textMap).forEach(([selector, value]) => {
        root.querySelectorAll(selector).forEach((node) => {
          node.textContent = String(value ?? '');
        });
      });

      root.querySelectorAll('[data-team-logo]').forEach((node) => {
        const logoUrl = String(data.logo_url || '').trim();
        const isLegacyGenericLogo = /(?:^|\/)nffl-logo\.png(?:\?|$)/i.test(logoUrl);
        // The CSV's legacy generic logo must not replace the newer branded
        // logo already present in the page markup. Custom team logos still do.
        if (logoUrl && !isLegacyGenericLogo) node.src = logoUrl;
      });

      const hero = root.querySelector('.team-hero');
      if (hero) {
        if (data.banner_url) {
          hero.style.backgroundImage = `linear-gradient(rgba(0,0,0,.55), rgba(0,0,0,.55)), url("${data.banner_url.replaceAll('"', '%22')}")`;
          hero.style.backgroundSize = 'cover';
          hero.style.backgroundPosition = 'center';
        }
        if (data.primary_color) hero.style.borderColor = data.primary_color;
      }
    }
  }


  async function loadFranchiseRepeatingItems() {
    const roots = [...document.querySelectorAll('[data-supabase-team-content]')];
    for (const root of roots) {
      const league = root.dataset.supabaseTeamContent;
      const teamKey = root.dataset.teamKey;
      if (!league || !teamKey) continue;

      const { data, error } = await client
        .from('managed_items')
        .select('*')
        .eq('league', league)
        .in('content_type', ['franchise_staff', 'franchise_timeline'])
        .contains('metadata', { team_key: teamKey })
        .eq('is_active', true)
        .order('rank', { ascending: true });

      if (error || !data) {
        if (error) console.warn('Franchise history load failed:', error.message);
        continue;
      }

      const staff = data.filter((item) => item.content_type === 'franchise_staff');
      const timeline = data.filter((item) => item.content_type === 'franchise_timeline');
      const team = root.__nfflTeamContent || {};

      const staffRoot = root.querySelector('[data-team-staff-history]');
      if (staffRoot && staff.length) {
        staffRoot.innerHTML = staff.map((item) => `
          <div class="staff-history-item">
            <span>${esc(item.subtitle || '')}</span>
            <strong>${esc(item.title || '')}</strong>
            <p>${esc(item.body || '')}</p>
          </div>
        `).join('');
      } else if (staffRoot) {
        staffRoot.innerHTML = team.staff_history
          ? `<div class="staff-history-item"><p>${esc(team.staff_history)}</p></div>`
          : '';
      }

      const timelineRoot = root.querySelector('[data-team-franchise-timeline]');
      if (timelineRoot && timeline.length) {
        timelineRoot.innerHTML = timeline.map((item) => `
          <div class="timeline-mini-item">
            <span>${esc(item.subtitle || '')}</span>
            <strong>${esc(item.title || '')}</strong>
            <p>${esc(item.body || '')}</p>
          </div>
        `).join('');
      } else if (timelineRoot) {
        timelineRoot.innerHTML = team.franchise_timeline
          ? `<div class="timeline-mini-item"><p>${esc(team.franchise_timeline)}</p></div>`
          : '';
      }
    }
  }

  async function loadSeasonVaults() {
    const root = document.querySelector('[data-supabase-season-vaults]');
    if (!root) return;

    const league = root.dataset.supabaseSeasonVaults || 'nffl';
    const { data, error } = await client
      .from('season_vaults')
      .select('*')
      .eq('league', league)
      .eq('published', true)
      .order('season', { ascending: false });

    if (error || !data?.length) {
      if (error) console.warn('Season vault load failed:', error.message);
      return;
    }

    root.innerHTML = data.map((row) => `
      <article class="season-card">
        <div class="season-card-top"><span>${esc(row.season)}</span><strong>Season Vault</strong></div>
        <h3>${esc(row.season)} ${league === 'gleague' ? 'G-League' : 'NFFL'} Season</h3>
        <ul>
          <li>Champion: ${esc(row.champion || 'TBD')}</li>
          <li>Runner-Up: ${esc(row.runner_up || 'TBD')}</li>
          <li>Best Record: ${esc(row.best_record_team || 'TBD')} ${row.best_record ? `(${esc(row.best_record)})` : ''}</li>
        </ul>
        <p>${esc(row.season_summary || '')}</p>
      </article>
    `).join('');
  }



  function normalizeScheduleNames(value) {
    return String(value || '')
      .replaceAll('royaltyharris','allyotarola')
      .replaceAll('jkawski87','damianhartfield')
      .replaceAll('KURSED','DJSP')
      .replaceAll('CrimsonChin1','Knightmare005');
  }

  function renderManagedScheduleMatchup(card, value) {
    const normalized = normalizeScheduleNames(value || 'TBD');
    const parts = normalized.split(/\s+vs\.?\s+/i);
    if (parts.length >= 2) {
      card.innerHTML = `
        <span class="schedule-team schedule-away">${esc(parts[0].trim())}</span>
        <span class="schedule-versus">VS</span>
        <span class="schedule-team schedule-home">${esc(parts.slice(1).join(' vs ').trim())}</span>
        <small class="schedule-matchup-status">Upcoming</small>`;
    } else {
      card.textContent = normalized;
    }
  }

  async function loadManagedContent() {
    const root = document.querySelector('[data-managed-content-type]');
    if (!root) return;

    const type = root.dataset.managedContentType;
    const league = root.dataset.managedLeague || 'nffl';

    const { data, error } = await client
      .from('managed_items')
      .select('*')
      .eq('content_type', type)
      .eq('league', league)
      .eq('is_active', true)
      .order('week', { ascending: true, nullsFirst: true })
      .order('rank', { ascending: true, nullsFirst: true });

    if (error || !data?.length) {
      if (error) console.warn('Managed content load failed:', error.message);
      return;
    }

    if (type === 'power_ranking') {
      const panels = [...root.querySelectorAll('.rankings-panel, .standings-panel')];
      panels.forEach((panel, index) => {
        const week = index + 1;
        const rows = data.filter((item) => item.week === week);
        const tbody = panel.querySelector('tbody');
        if (!tbody || !rows.length) return;
        tbody.innerHTML = rows.map((row) => {
          const cells = Array.isArray(row.metadata?.cells) ? row.metadata.cells : [];
          const extras = cells.slice(2);
          return `<tr>
            <td>${esc(row.rank ?? '')}</td>
            <td data-managed-item-id="${row.id}" data-managed-field="title">${esc(row.title || '')}</td>
            ${extras.map((cell) => `<td>${esc(cell)}</td>`).join('')}
          </tr>`;
        }).join('');
      });
    }

    if (type === 'schedule_game') {
      const panels = [...root.querySelectorAll('.schedule-panel, .standings-panel')];
      panels.forEach((panel, index) => {
        const week = index + 1;
        const games = data.filter((item) => item.week === week);
        const cards = panel.querySelectorAll('.matchup');
        games.forEach((game, gameIndex) => {
          if (cards[gameIndex]) {
            renderManagedScheduleMatchup(cards[gameIndex], game.title || game.body || 'TBD');
            cards[gameIndex].dataset.managedItemId = game.id;
            cards[gameIndex].dataset.managedField = game.title ? 'title' : 'body';
          }
        });
      });
    }

    if (type === 'history_item') {
      const timelines = data.filter((item) => item.metadata?.kind === 'timeline');
      const timelineRoot = root.querySelector('.modern-timeline');
      if (timelineRoot && timelines.length) {
        timelineRoot.innerHTML = timelines.map((item) => `
          <div class="timeline-event">
            <span data-managed-item-id="${item.id}" data-managed-field="subtitle">${esc(item.subtitle || '')}</span>
            <div>
              <h3 data-managed-item-id="${item.id}" data-managed-field="title">${esc(item.title || '')}</h3>
              <p data-managed-item-id="${item.id}" data-managed-field="body">${esc(item.body || '')}</p>
            </div>
          </div>
        `).join('');
      }

      const championships = data.filter((item) => item.metadata?.kind === 'championship');
      const championshipRoot = root.querySelector('.championship-track');
      if (championshipRoot && championships.length) {
        championshipRoot.innerHTML = championships.map((item) => `
          <article class="championship-card">
            <span data-managed-item-id="${item.id}" data-managed-field="subtitle">${esc(item.subtitle || item.season || '')}</span>
            <h3 data-managed-item-id="${item.id}" data-managed-field="title">${esc(item.title || '')}</h3>
            <p data-managed-item-id="${item.id}" data-managed-field="body">${esc(item.body || '')}</p>
          </article>
        `).join('');
      }
    }

    if (type === 'promotion_item') {
      const candidates = data.filter((item) => item.metadata?.kind !== 'archive');
      const archive = data.filter((item) => item.metadata?.kind === 'archive');

      const heading = [...root.querySelectorAll('h2')].find((node) => node.textContent.includes('Promotion Watch'));
      const list = heading?.parentElement?.querySelector('.ranking-list') || root.querySelector('.ranking-list');
      if (list && candidates.length) {
        list.innerHTML = candidates.map((item) => `
          <div class="rank-item">
            <h3><span>${esc(item.rank || '')}.</span> <span data-managed-item-id="${item.id}" data-managed-field="title">${esc(item.title || '')}</span></h3>
            <p data-managed-item-id="${item.id}" data-managed-field="body">${esc(item.body || '')}</p>
          </div>
        `).join('');
      }

      const archiveRoot = root.querySelector('[data-promotion-archive]');
      if (archiveRoot) {
        archiveRoot.innerHTML = archive.length ? archive.map((item) => {
          const meta = item.metadata || {};
          const date = meta.promotion_date
            ? new Date(`${meta.promotion_date}T12:00:00`).toLocaleDateString(undefined, { year: 'numeric', month: 'long', day: 'numeric' })
            : String(item.season || item.subtitle || 'Season TBD');

          return `
            <article class="promotion-archive-card">
              <div class="promotion-archive-topline">
                <span data-managed-item-id="${item.id}" data-managed-field="subtitle">${esc(date)}</span>
                <strong>${esc(meta.role || 'Head Coach')}</strong>
              </div>
              <h3 data-managed-item-id="${item.id}" data-managed-field="title">${esc(item.title || '')}</h3>
              <div class="promotion-route">
                <div><span>From</span><strong>${esc(meta.previous_team || 'G-League team TBD')}</strong></div>
                <b>→</b>
                <div><span>To</span><strong>${esc(meta.nffl_team || 'NFFL team TBD')}</strong></div>
              </div>
              ${meta.vacancy_reason ? `<p class="promotion-vacancy"><strong>Opening:</strong> ${esc(meta.vacancy_reason)}</p>` : ''}
              ${item.body ? `<p data-managed-item-id="${item.id}" data-managed-field="body">${esc(item.body)}</p>` : ''}
            </article>
          `;
        }).join('') : `
          <div class="rule-block promotion-empty-state">
            <h3>No Promotions Yet</h3>
            <p>No G-League coach has been promoted to the NFFL yet. The first promotion will appear here after it is added through the Promotion Manager.</p>
          </div>
        `;
      }
    }

    if (type === 'constitution_section') {
      const content = root.querySelector('.constitution-content');
      if (content) {
        content.innerHTML = data.map((item) => `
          <article id="${esc(item.item_key || '')}" class="constitution-article">
            <h2 data-managed-item-id="${item.id}" data-managed-field="title">${esc(item.title || '')}</h2>
            <div data-managed-item-id="${item.id}" data-managed-field="body">
              ${(item.body || '').split('\n').filter(Boolean).map((line) => `<p>${esc(line)}</p>`).join('')}
            </div>
          </article>
        `).join('');
      }
    }
  }

  async function boot() {
    await Promise.allSettled([
      loadSiteContent(),
      loadArticles(),
      loadSingleArticle(),
      loadAwards(),
      loadHotSeat(),
      loadSeasonVaults(),
      loadManagedContent()
    ]);
    // Team content is loaded first so legacy CSV history can be used only when
    // no structured managed_items exist. Supabase remains authoritative.
    await loadTeamContent();
    await loadFranchiseRepeatingItems();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot);
  } else {
    boot();
  }
})();
