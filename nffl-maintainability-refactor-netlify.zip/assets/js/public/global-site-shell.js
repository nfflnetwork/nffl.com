
(function setupNFFLGlobalShell() {
  const searchIndex = [
    ['Home','index.html','homepage featured stories game of the week headlines'],
    ['News','news.html','news articles breaking stories headlines coverage'],
    ['Teams','teams.html','teams franchises coaches rosters'],
    ['Standings','standings.html','standings records wins losses points'],
    ['Schedule','schedule.html','schedule weekly matchups games'],
    ['Transactions','transactions.html','transactions trades waivers adds drops'],
    ['Power Rankings','power-rankings.html','power rankings top teams tiers'],
    ['Awards','awards.html','awards weekly yearly players coaches'],
    ['History','history.html','history champions timeline seasons'],
    ['Season Vault','history.html#season-vault','season vault archives playoffs standings'],
    ['G-League','g-league/index.html','g league development promotion standings teams']
  ];

  function rootPrefix() {
    const script = [...document.scripts].find((node) => /assets\/js\/public\/global-site-shell\.js$/.test(node.src));
    if (!script) return '';
    const url = new URL(script.src);
    return url.pathname.replace(/assets\/js\/public\/global-site-shell\.js$/, '').replace(/^\//,'');
  }

  function relativeHref(target) {
    const script = [...document.scripts].find((node) => /assets\/js\/public\/global-site-shell\.js$/.test(node.src));
    if (!script) return target;
    const src = script.getAttribute('src') || '';
    return src.replace(/assets\/js\/public\/global-site-shell\.js$/, '') + target;
  }


  function setupNavigationMenus() {
    document.querySelectorAll('.global-nav-dropdown').forEach((dropdown) => {
      const button = dropdown.querySelector('[data-global-nav-menu]');
      const panel = dropdown.querySelector('[data-global-nav-menu-panel]');
      if (!button || !panel) return;

      const close = () => {
        dropdown.classList.remove('open');
        button.setAttribute('aria-expanded', 'false');
      };

      button.addEventListener('click', (event) => {
        event.stopPropagation();
        const opening = !dropdown.classList.contains('open');
        document.querySelectorAll('.global-nav-dropdown.open').forEach((other) => {
          other.classList.remove('open');
          other.querySelector('[aria-expanded]')?.setAttribute('aria-expanded', 'false');
        });
        dropdown.classList.toggle('open', opening);
        button.setAttribute('aria-expanded', String(opening));
      });

      button.addEventListener('keydown', (event) => {
        if (event.key === 'Escape') {
          close();
          button.focus();
        }
        if (event.key === 'ArrowDown') {
          event.preventDefault();
          dropdown.classList.add('open');
          button.setAttribute('aria-expanded', 'true');
          panel.querySelector('a')?.focus();
        }
      });

      panel.addEventListener('keydown', (event) => {
        const links = [...panel.querySelectorAll('a')];
        const index = links.indexOf(document.activeElement);
        if (event.key === 'Escape') {
          close();
          button.focus();
        } else if (event.key === 'ArrowDown') {
          event.preventDefault();
          links[(index + 1 + links.length) % links.length]?.focus();
        } else if (event.key === 'ArrowUp') {
          event.preventDefault();
          links[(index - 1 + links.length) % links.length]?.focus();
        }
      });

      document.addEventListener('click', (event) => {
        if (!dropdown.contains(event.target)) close();
      });
    });
  }

  function setupBreakingTicker() {
    document.querySelectorAll('[data-global-breaking]').forEach((ticker) => {
      ticker._nfflTickerCleanup?.();

      const items = [...ticker.querySelectorAll('.global-breaking-item')];
      if (items.length < 2) return;
      let index = Math.max(0, items.findIndex((item) => item.classList.contains('active')));
      let timer;

      const show = (next) => {
        items[index]?.classList.remove('active');
        index = (next + items.length) % items.length;
        items[index]?.classList.add('active');
      };
      const start = () => {
        clearInterval(timer);
        if (window.matchMedia?.('(prefers-reduced-motion: reduce)').matches || document.hidden) return;
        timer = setInterval(() => show(index + 1), 6500);
      };
      const previous = () => { show(index - 1); start(); };
      const next = () => { show(index + 1); start(); };
      const pause = () => clearInterval(timer);

      const prevButton = ticker.querySelector('[data-breaking-prev]');
      const nextButton = ticker.querySelector('[data-breaking-next]');
      prevButton?.addEventListener('click', previous);
      nextButton?.addEventListener('click', next);
      ticker.addEventListener('mouseenter', pause);
      ticker.addEventListener('mouseleave', start);

      ticker._nfflTickerCleanup = () => {
        clearInterval(timer);
        prevButton?.removeEventListener('click', previous);
        nextButton?.removeEventListener('click', next);
        ticker.removeEventListener('mouseenter', pause);
        ticker.removeEventListener('mouseleave', start);
      };
      start();
    });
  }

  function setupTheme() {
    const buttons = [...document.querySelectorAll('[data-global-dark-toggle]')];

    const apply = (dark) => {
      document.body.classList.toggle('dark-mode', dark);
      document.body.classList.toggle('global-dark-mode', dark);
      document.documentElement.dataset.theme = dark ? 'dark' : 'light';
      buttons.forEach((button) => {
        const icon = button.querySelector('[data-theme-icon]');
        const label = button.querySelector('[data-theme-label]');
        if (icon) icon.textContent = dark ? '☀' : '☾';
        if (label) label.textContent = dark ? 'Light' : 'Dark';
        button.setAttribute('aria-pressed', String(dark));
        button.setAttribute('title', dark ? 'Switch to light mode' : 'Switch to dark mode');
      });
    };

    const saved = localStorage.getItem('nffl-theme');
    const initialDark = saved ? saved === 'dark' : window.matchMedia?.('(prefers-color-scheme: dark)').matches;
    apply(initialDark);

    buttons.forEach((button) => button.addEventListener('click', () => {
      const dark = !document.body.classList.contains('dark-mode');
      localStorage.setItem('nffl-theme', dark ? 'dark' : 'light');
      apply(dark);
    }));
  }

  function setupLogoFallbacks() {
    const script = [...document.scripts].find((node) => /assets\/js\/public\/global-site-shell\.js$/.test(node.src));
    const prefix = (script?.getAttribute('src') || '').replace(/assets\/js\/public\/global-site-shell\.js$/, '');
    const fallback = `${prefix}assets/images/nffl-logo-new.png`;
    const logoSelector = [
      '.global-brand img',
      '.brand-lockup img',
      '.footer img',
      'img[src*="nffl-logo"]',
      'img[data-team-logo]'
    ].join(',');

    document.querySelectorAll(logoSelector).forEach((img) => {
      if (!(img instanceof HTMLImageElement)) return;
      const src = img.getAttribute('src') || '';
      if (!src.trim() || src === '#') img.setAttribute('src', fallback);
      img.addEventListener('error', () => {
        if (img.getAttribute('src') !== fallback) img.setAttribute('src', fallback);
      }, { once: true });
    });
  }
  function setupSearch() {
    document.querySelectorAll('[data-global-search]').forEach((form) => {
      const input = form.querySelector('input');
      const results = form.querySelector('[data-global-search-results]');
      if (!input || !results) return;
      let requestId = 0;

      const render = async () => {
        const query = input.value.trim();
        const localRequest = ++requestId;
        if (!query) {
          results.hidden = true;
          results.innerHTML = '';
          return;
        }

        const q = query.toLowerCase();
        const pageMatches = searchIndex.filter(([title,,keywords]) =>
          title.toLowerCase().includes(q) || keywords.includes(q)
        ).slice(0,5);

        let articleMatches = [];
        const client = window.nfflPublicSupabase;
        if (client && query.length >= 2) {
          const { data } = await client
            .from('articles')
            .select('title,slug,category,summary')
            .eq('status','published')
            .or(`title.ilike.%${query}%,summary.ilike.%${query}%,category.ilike.%${query}%`)
            .limit(5);
          articleMatches = data || [];
        }

        if (localRequest !== requestId) return;

        const pageHtml = pageMatches.map(([title,target,keywords]) => `
          <a href="${relativeHref(target)}">
            <small>Page</small>
            <strong>${title}</strong>
            <span>${keywords.split(' ').slice(0,5).join(' ')}</span>
          </a>`).join('');

        const articleHtml = articleMatches.map((article) => `
          <a href="${relativeHref(`article.html?slug=${encodeURIComponent(article.slug)}`)}">
            <small>Article • ${article.category || 'League News'}</small>
            <strong>${article.title}</strong>
            <span>${article.summary || 'Read story'}</span>
          </a>`).join('');

        results.innerHTML = pageHtml + articleHtml ||
          '<div class="global-search-empty">No matching pages or articles found.</div>';
        results.hidden = false;
      };

      input.addEventListener('input', render);
      input.addEventListener('focus', render);
      form.addEventListener('submit', (event) => {
        event.preventDefault();
        const first = results.querySelector('a');
        if (first) location.href = first.href;
      });

      document.addEventListener('click', (event) => {
        if (!form.contains(event.target)) results.hidden = true;
      });
    });
  }

  function setupStoryRotator() {
    const rotator = document.querySelector('[data-home-story-rotator]');
    if (!rotator) return;
    rotator._nfflStoryCleanup?.();

    const slides = [...rotator.querySelectorAll('[data-story-slide]')];
    const dots = [...rotator.querySelectorAll('[data-story-dot]')];
    if (slides.length < 2) return;
    let index = Math.max(0, slides.findIndex((slide) => slide.classList.contains('active')));
    let timer;

    const show = (next) => {
      slides[index]?.classList.remove('active');
      dots[index]?.classList.remove('active');
      index = (next + slides.length) % slides.length;
      slides[index]?.classList.add('active');
      dots[index]?.classList.add('active');
    };
    const start = () => {
      clearInterval(timer);
      if (window.matchMedia?.('(prefers-reduced-motion: reduce)').matches || document.hidden) return;
      timer = setInterval(() => show(index + 1), 7000);
    };
    const previous = () => { show(index - 1); start(); };
    const next = () => { show(index + 1); start(); };
    const pause = () => clearInterval(timer);

    const prevButton = rotator.querySelector('[data-story-prev]');
    const nextButton = rotator.querySelector('[data-story-next]');
    prevButton?.addEventListener('click',previous);
    nextButton?.addEventListener('click',next);
    dots.forEach((dot,dotIndex) => dot.addEventListener('click', () => { show(dotIndex); start(); }));
    rotator.addEventListener('mouseenter',pause);
    rotator.addEventListener('mouseleave',start);

    rotator._nfflStoryCleanup = () => {
      clearInterval(timer);
      prevButton?.removeEventListener('click',previous);
      nextButton?.removeEventListener('click',next);
      rotator.removeEventListener('mouseenter',pause);
      rotator.removeEventListener('mouseleave',start);
    };
    start();
  }

  function boot() {
    setupNavigationMenus();
    setupBreakingTicker();
    setupTheme();
    setupLogoFallbacks();
    setupSearch();
    setupStoryRotator();

    document.addEventListener('visibilitychange', () => {
      document.documentElement.classList.toggle('page-hidden', document.hidden);
    });
    document.addEventListener('nffl-article-presentations-ready', () => {
      setupBreakingTicker();
      setupStoryRotator();
    });
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
  else boot();
})();
