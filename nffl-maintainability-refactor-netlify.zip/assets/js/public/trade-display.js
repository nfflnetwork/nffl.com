
(function formatSleeperTrades() {
  function formatItem(item) {
    if (!(item instanceof Element) || item.dataset.tradeDisplayFormatted === 'true') return;

    const headline = item.querySelector('h3');
    const body = item.querySelector('p');
    if (!headline || !body || !/^Trade:/i.test(headline.textContent.trim())) return;

    const parts = body.textContent
      .split('•')
      .map((part) => part.trim())
      .filter(Boolean)
      .map((part) => part
        .replace(/\s+added\s+/i, ' received ')
        .replace(/\s+dropped\s+/i, ' sent '));

    if (!parts.length) return;

    body.innerHTML = parts.map((part) => {
      const match = part.match(/^(.*?)\s+(received|sent)\s+(.*)$/i);
      if (!match) return `<span class="trade-detail-line">${escapeHtml(part)}</span>`;
      return `
        <span class="trade-detail-line">
          <strong>${escapeHtml(match[1])}</strong>
          <em>${escapeHtml(match[2].toLowerCase())}</em>
          <span>${escapeHtml(match[3])}</span>
        </span>
      `;
    }).join('');

    item.classList.add('formatted-trade-item');
    item.dataset.tradeDisplayFormatted = 'true';
  }

  function escapeHtml(value) {
    return String(value ?? '')
      .replaceAll('&', '&amp;')
      .replaceAll('<', '&lt;')
      .replaceAll('>', '&gt;')
      .replaceAll('"', '&quot;')
      .replaceAll("'", '&#039;');
  }

  function scan(root = document) {
    root.querySelectorAll?.('.transaction-item').forEach(formatItem);
    if (root.matches?.('.transaction-item')) formatItem(root);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => scan());
  } else {
    scan();
  }

  const observer = new MutationObserver((mutations) => {
    for (const mutation of mutations) {
      mutation.addedNodes.forEach((node) => {
        if (node.nodeType === Node.ELEMENT_NODE) scan(node);
      });
    }
  });

  observer.observe(document.documentElement, { childList: true, subtree: true });
})();
