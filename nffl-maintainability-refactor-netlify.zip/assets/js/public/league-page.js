
(function setupLeaguePage() {
  const root = document.querySelector('[data-league-hub]');
  const client = window.nfflPublicSupabase;
  if (!root || !client) return;

  const keys = [
    'league.hero_title','league.hero_body','league.league_status','league.season_label',
    'league.teams','league.divisions','league.regular_season','league.playoff_teams',
    'league.established','league.current_season','league.commissioner_heading',
    'league.commissioner_message','league.commissioner_name','league.overview',
    'league.format','league.scoring','league.platform','league.mission_heading','league.mission_body','league.rule_integrity',
    'league.rule_accountability','league.rule_history','league.gleague_summary'
  ];

  const esc = (value) => String(value ?? '')
    .replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;')
    .replaceAll('"','&quot;').replaceAll("'","&#039;");

  async function loadFields() {
    const { data, error } = await client
      .from('site_content')
      .select('content_key,title,body')
      .in('content_key',keys);

    if (error) {
      console.warn('League page content failed:',error.message);
      return;
    }

    (data || []).forEach((row) => {
      const field = row.content_key.replace(/^league\./,'');
      let value = row.body || row.title;
      if (!value) return;
      if (field === 'commissioner_name' && value === 'NFFL Commissioner') {
        value = 'NFFL Commissioners';
      }
      root.querySelectorAll(`[data-league-field="${field}"]`).forEach((node) => {
        node.textContent = value;
      });
    });
  }

  async function loadLists() {
    const { data, error } = await client
      .from('managed_items')
      .select('*')
      .eq('league','nffl')
      .in('content_type',['league_champion','league_timeline','league_leadership'])
      .eq('is_active',true)
      .order('rank',{ascending:true});

    if (error) {
      console.warn('League page lists failed:',error.message);
      return;
    }

    let champions = (data || []).filter((row)=>row.content_type==='league_champion');
    const timeline = (data || []).filter((row)=>row.content_type==='league_timeline');
    let leadership = (data || []).filter((row)=>row.content_type==='league_leadership');

    champions = champions.map((row) => {
      const season = String(row.subtitle || row.season || '');
      const legacyWrong = /2025.?26/i.test(season) &&
        /knightmare005/i.test(String(row.title || ''));
      return legacyWrong ? {...row,title:'CrimsonChin1'} : row;
    });

    const onlyPlaceholderLeader = leadership.length === 1 &&
      /nffl commissioner/i.test(String(leadership[0].title || ''));

    if (!leadership.length || onlyPlaceholderLeader) {
      leadership = [
        {subtitle:'Commissioner',title:'conorfigueroa',body:'League operations and governance'},
        {subtitle:'Commissioner',title:'elliottmintz',body:'League operations and governance'},
        {subtitle:'Commissioner',title:'mjd413',body:'League operations and governance'}
      ];
    }

    const championRoot = root.querySelector('[data-league-champions]');
    if (championRoot && champions.length) {
      championRoot.innerHTML = champions.map((row)=>`
        <article>
          <span>${esc(row.subtitle || row.season || '')}</span>
          <strong>${esc(row.title || '')}</strong>
          <p>${esc(row.body || '')}</p>
          <div class="league-champion-details">
            <div><span>Runner-Up</span><strong>${esc(row.metadata?.runner_up || 'Not yet entered')}</strong></div>
            <div><span>Champion Record</span><strong>${esc(row.metadata?.champion_record || 'Not yet entered')}</strong></div>
            <div><span>Final Score</span><strong>${esc(row.metadata?.final_score || 'Not yet entered')}</strong></div>
          </div>
        </article>`).join('');
    }

    const timelineRoot = root.querySelector('[data-league-timeline]');
    if (timelineRoot && timeline.length) {
      timelineRoot.innerHTML = timeline.map((row)=>{
        const title = String(row.title || '');
        const icon = /founded/i.test(title) ? '⭐' : /network/i.test(title) ? '📰' : /champ/i.test(title) ? '🏆' : '📌';
        return `<article>
          <i class="league-timeline-icon">${icon}</i>
          <span>${esc(row.subtitle || row.season || '')}</span>
          <div><strong>${esc(title)}</strong><p>${esc(row.body || '')}</p></div>
        </article>`;
      }).join('');
    }

    const leadershipRoot = root.querySelector('[data-league-leadership]');
    if (leadershipRoot) {
      leadershipRoot.innerHTML = leadership.map((row)=>{
        const title = String(row.title || '');
        const initials = (title.match(/[A-Za-z0-9]/g) || ['N']).slice(0,2).join('').toUpperCase();
        return `<article>
          <i class="league-leader-initials">${esc(initials)}</i>
          <span>${esc(row.subtitle || 'League Staff')}</span>
          <strong>${esc(title)}</strong>
          <p>${esc(row.body || '')}</p>
        </article>`;
      }).join('');
    }
  }

  Promise.allSettled([loadFields(),loadLists()]);
})();
