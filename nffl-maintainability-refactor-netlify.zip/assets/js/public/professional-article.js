
(function setupProfessionalArticles() {
  const client = window.nfflPublicSupabase;
  const root = document.querySelector('[data-professional-article]');
  if (!root || !client) return;

  const esc = (value) => String(value ?? '')
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#039;');

  function setText(selector, value) {
    const node = root.querySelector(selector);
    if (node && value !== null && value !== undefined && value !== '') node.textContent = String(value);
  }

  function setLink(node, value) {
    if (!node || !value?.url) return;
    node.href = value.url;
    node.hidden = false;
    const strong = node.querySelector('strong');
    if (strong) strong.textContent = value.title || value.url;
  }

  function paragraphs(body) {
    return String(body || '')
      .split(/\n\s*\n/)
      .map((part) => part.trim())
      .filter(Boolean)
      .map((part) => `<p>${esc(part)}</p>`)
      .join('');
  }

  function relatedCards(items) {
    return (Array.isArray(items) ? items : []).map((item) => `
      <a class="pro-related-card" href="${esc(item.url || 'news.html')}">
        <span>${esc(item.category || 'Related')}</span>
        <strong>${esc(item.title || 'NFFL Network')}</strong>
        <small>Read story →</small>
      </a>
    `).join('');
  }


  function setupReadingTools() {
    const progress = document.querySelector('[data-reading-progress]');
    const copyButton = document.querySelector('[data-copy-article-link]');
    const copyStatus = document.querySelector('[data-copy-status]');

    const updateProgress = () => {
      if (!progress) return;
      const articleBody = document.querySelector('[data-pro-body]');
      if (!articleBody) return;
      const rect = articleBody.getBoundingClientRect();
      const start = scrollY + rect.top - innerHeight * .2;
      const end = start + articleBody.offsetHeight - innerHeight * .6;
      const percent = Math.max(0, Math.min(100, ((scrollY - start) / Math.max(1, end - start)) * 100));
      progress.style.width = `${percent}%`;
    };

    addEventListener('scroll', updateProgress, { passive:true });
    addEventListener('resize', updateProgress);
    updateProgress();

    copyButton?.addEventListener('click', async () => {
      try {
        await navigator.clipboard.writeText(location.href);
        copyStatus.textContent = 'Link copied';
      } catch (_) {
        copyStatus.textContent = 'Copy failed';
      }
      setTimeout(() => { copyStatus.textContent = ''; }, 2200);
    });
  }

  async function load() {
    const slug = root.dataset.articleSlug || new URLSearchParams(location.search).get('slug');
    if (!slug) return;

    const { data, error } = await client
      .from('articles')
      .select('*')
      .eq('slug', slug)
      .eq('status', 'published')
      .maybeSingle();

    if (error || !data) {
      if (error) console.warn('Professional article load failed:', error.message);
      return; // Keep the professional static fallback.
    }

    document.title = `${data.title} | NFFL Network`;
    const metaDescription = document.querySelector('meta[name="description"]');
    if (metaDescription) metaDescription.content = data.seo_description || data.summary || '';
    else if (data.seo_description || data.summary) {
      const meta = document.createElement('meta');
      meta.name = 'description';
      meta.content = data.seo_description || data.summary;
      document.head.appendChild(meta);
    }

    setText('[data-pro-category]', data.category || 'League News');
    setText('[data-pro-title]', data.title);
    setText('[data-pro-subtitle]', data.subtitle || data.summary);
    setText('[data-pro-author]', data.author_name || 'NFFL Network Staff');
    setText('[data-pro-author-box]', data.author_name || 'NFFL Network Staff');
    const wordCount = String(data.body || '').trim().split(/\s+/).filter(Boolean).length;
    const computedReadTime = `${Math.max(1, Math.ceil(wordCount / 220))} min read`;
    setText('[data-pro-read-time]', data.reading_time || computedReadTime);

    const dateNode = root.querySelector('[data-pro-date]');
    if (dateNode && data.published_at) {
      dateNode.textContent = new Date(data.published_at).toLocaleDateString(undefined, {
        year: 'numeric', month: 'long', day: 'numeric'
      });
    }

    const image = root.querySelector('[data-pro-image]');
    if (image && data.image_url) {
      image.src = data.image_url;
      image.alt = data.title || 'NFFL article image';
    }

    const body = root.querySelector('[data-pro-body]');
    if (body && data.body) body.innerHTML = paragraphs(data.body);

    const quote = root.querySelector('[data-pro-quote]');
    if (quote && data.pull_quote) {
      quote.hidden = false;
      quote.querySelector('p').textContent = data.pull_quote;
      quote.querySelector('cite').textContent = data.pull_quote_attribution || '';
    }

    const team = root.querySelector('[data-pro-team]');
    if (team && data.team_name) {
      team.hidden = false;
      setText('[data-pro-team-name]', data.team_name);
      setText('[data-pro-team-coach]', data.team_coach || 'TBD');
      setText('[data-pro-team-division]', data.team_division || 'TBD');
      setText('[data-pro-team-status]', data.team_status || 'Active');
      const teamLink = root.querySelector('[data-pro-team-link]');
      if (teamLink && data.team_key) teamLink.href = `team-${data.team_key}.html`;
    }

    let relatedItems = Array.isArray(data.related_links) ? data.related_links : [];
    if (!relatedItems.length) {
      const { data: relatedRows } = await client
        .from('articles')
        .select('title,slug,category')
        .eq('league', data.league || 'nffl')
        .eq('status','published')
        .eq('category', data.category || 'League News')
        .neq('id', data.id)
        .order('published_at', { ascending:false, nullsFirst:false })
        .limit(3);

      relatedItems = (relatedRows || []).map((article) => ({
        category: article.category,
        title: article.title,
        url: `article.html?slug=${encodeURIComponent(article.slug)}`
      }));
    }

    const related = relatedCards(relatedItems);
    if (related) {
      root.querySelectorAll('[data-pro-related], [data-pro-related-grid]').forEach((node) => {
        node.innerHTML = related;
      });
    }

    setLink(root.querySelector('[data-pro-previous]'), data.previous_link);
    setLink(root.querySelector('[data-pro-next]'), data.next_link);
  }

  async function boot() {
    setupReadingTools();
    await load();
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
  else boot();
})();
