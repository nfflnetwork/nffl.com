(function configureNFFL() {
  'use strict';

  const existing = window.NFFL_CONFIG || {};
  const supabase = Object.freeze({
    url: 'https://dspatsoiapekhwpcvdvo.supabase.co',
    publishableKey: 'sb_publishable_KvzgK_BRLkzr5fsYzIpHzQ_P7Lu8Tp0'
  });

  window.NFFL_CONFIG = Object.freeze({
    ...existing,
    siteName: existing.siteName || 'NFFL',
    supabase
  });

  // Preserve the established globals used by the public site and admin CMS.
  window.NFFL_SUPABASE_URL = supabase.url;
  window.NFFL_SUPABASE_PUBLISHABLE_KEY = supabase.publishableKey;
})();
