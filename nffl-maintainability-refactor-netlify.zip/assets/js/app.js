const current = location.pathname.split("/").pop() || "index.html";

document.querySelectorAll(".nav a").forEach((link) => {
  const href = link.getAttribute("href");
  if (href === current || (current === "" && href === "index.html")) {
    link.classList.add("active");
  }
});

const breakingItems = [
  "NFFL Network is live",
  "Way Too Early Power Rankings released",
  "Week 1 schedule is officially set",
  "Transaction Center monitoring latest blockbuster rumors",
  "G-League pipeline opens a new era for the NFFL"
];

const searchIndex = [
  { title: "Home", category: "Main", url: "index.html", description: "Front page for NFFL news, standings, rankings, and league updates." },
  { title: "NFFL News", category: "News", url: "news.html", description: "Breaking news, league statements, team updates, and rumor reports." },
  { title: "NFFL Teams", category: "Teams", url: "teams.html", description: "Official team directory with coaches, records, and divisions." },
  { title: "NFFL Standings", category: "Standings", url: "standings.html", description: "League and division standings." },
  { title: "NFFL Schedule", category: "Schedule", url: "schedule.html", description: "Week 1 through Week 14 matchup hub." },
  { title: "Power Rankings", category: "Rankings", url: "power-rankings.html", description: "Way Too Early rankings and weekly ranking archive." },
  { title: "NFFL Draft History", category: "Draft", url: "draft-history.html", description: "Startup draft and rookie draft archives pulled from Sleeper." },
  { title: "Transaction Center", category: "Transactions", url: "transactions.html", description: "Latest transactions, trades, rumors, grades, and featured trade coverage." },
  { title: "G-League Transactions", category: "G-League", url: "g-league/transactions.html", description: "Live G-League transaction wire and featured trade coverage." },
  { title: "G-League", category: "League", url: "g-league/index.html", description: "NFFL developmental league hub and promotion system." },
  { title: "G-League Teams", category: "G-League", url: "g-league/teams.html", description: "Developmental league team directory." },
  { title: "G-League Standings", category: "G-League", url: "g-league/standings.html", description: "Developmental league standings." },
  { title: "G-League Promotion Race", category: "G-League", url: "g-league/promotion-race.html", description: "Coach promotion watch and development tracker." },
  { title: "G-League Draft History", category: "G-League", url: "g-league/draft-history.html", description: "Startup and rookie draft archives for the developmental league." },
  { title: "NFFL Hot Seat", category: "Coach Watch", url: "hot-seat.html", description: "Coach hot seat watchlist and potential G-League vacancy tracker." },
  { title: "NFFL Awards", category: "Awards", url: "awards.html", description: "Weekly and season awards archive for the NFFL." },
  { title: "NFFL Record Book", category: "Records", url: "record-book.html", description: "Coming soon record book for NFFL league, team, and coach records." },
  { title: "NFFL Hall of Fame", category: "Hall of Fame", url: "hall-of-fame.html", description: "Coming soon Hall of Fame for NFFL legends." },
  { title: "G-League Awards", category: "G-League", url: "g-league/awards.html", description: "Weekly and season awards archive for the G-League." },
  { title: "G-League Record Book", category: "G-League", url: "g-league/record-book.html", description: "Coming soon record book for the G-League." },
  { title: "G-League Hall of Fame", category: "G-League", url: "g-league/hall-of-fame.html", description: "Coming soon G-League Hall of Fame." },
  { title: "History", category: "Archive", url: "history.html", description: "Champions, records, awards, and league history." },
  { title: "Rules", category: "Constitution", url: "rules.html", description: "Official NFFL rulebook and league constitution." },
  { title: "NFFL Network Is Live", category: "Top Story", url: "article-nffl-network-live.html", description: "The official launch article for NFFL Network." },
  { title: "Coach Matt Takes Over Tank Dell Lover", category: "Team News", url: "article-coach-matt.html", description: "Coach Matt begins a new era for Tank Dell Lover." },
  { title: "CMC Trade Fallout Sends Shockwaves Through NFFL", category: "Transaction News", url: "article-cmc-trade.html", description: "Coverage of the league's biggest trade storyline." },
  { title: "Team allyotarola", category: "Team", url: "team-allyotarola.html", description: "Coach allyotarola, East Division." },
  { title: "Team damianhartfield", category: "Team", url: "team-damianhartfield.html", description: "Coach damianhartfield, East Division." },
  { title: "Tank Dell Lover", category: "Team", url: "team-tank-dell-lover.html", description: "Coach mjd413, East Division." },
  { title: "Ricks and Mortys", category: "Team", url: "team-ricks-and-mortys.html", description: "Coach C137er, North Division." },
  { title: "Team Elliottmintz", category: "Team", url: "team-elliottmintz.html", description: "Coach Elliottmintz, North Division." },
  { title: "Cleveland Browns", category: "Team", url: "team-cleveland-browns.html", description: "Coach conorfigueroa, North Division." },
  { title: "Team KURSED", category: "Team", url: "team-kursed.html", description: "Coach KURSED, West Division." },
  { title: "Team nastybob", category: "Team", url: "team-nastybob.html", description: "Coach nastybob, West Division." },
  { title: "Brian's Team", category: "Team", url: "team-brians-team.html", description: "Coach mrbshoff, West Division." },
  { title: "Team CrimsonChin1", category: "Team", url: "team-crimsonchin1.html", description: "Coach CrimsonChin1, South Division." },
  { title: "Team carter867", category: "Team", url: "team-carter867.html", description: "Coach carter867, South Division." },
  { title: "Birds", category: "Team", url: "team-birds.html", description: "Coach gabe161, South Division." }
];

function addBreakingTicker() {
  if (document.querySelector(".breaking-ticker")) return;

  const ticker = document.createElement("div");
  ticker.className = "breaking-ticker";
  ticker.innerHTML = `
    <div class="breaking-label">Breaking</div>
    <div class="ticker-window">
      <div class="ticker-track">
        ${[...breakingItems, ...breakingItems].map(item => `<span>${item}</span>`).join("")}
      </div>
    </div>
  `;

  document.body.prepend(ticker);
}

function addSiteControls() {
  const navInner = document.querySelector(".nav-inner");
  if (!navInner || document.querySelector(".site-actions")) return;

  const controls = document.createElement("div");
  controls.className = "site-actions";
  controls.innerHTML = `
    <form class="site-search" role="search">
      <input type="search" id="siteSearchInput" placeholder="Search NFFL" aria-label="Search NFFL">
      <button type="submit">Search</button>
    </form>
    <button class="dark-toggle" type="button" aria-label="Toggle dark mode">🌙</button>
  `;
  navInner.appendChild(controls);

  const resultBox = document.createElement("div");
  resultBox.className = "search-results";
  resultBox.setAttribute("aria-live", "polite");
  resultBox.innerHTML = `<div class="search-results-inner"></div>`;
  document.body.appendChild(resultBox);

  const savedTheme = localStorage.getItem("nffl-theme");
  if (savedTheme === "dark") {
    document.body.classList.add("dark-mode");
    controls.querySelector(".dark-toggle").textContent = "☀️";
  }

  controls.querySelector(".dark-toggle").addEventListener("click", () => {
    document.body.classList.toggle("dark-mode");
    const isDark = document.body.classList.contains("dark-mode");
    localStorage.setItem("nffl-theme", isDark ? "dark" : "light");
    controls.querySelector(".dark-toggle").textContent = isDark ? "☀️" : "🌙";
  });

  const form = controls.querySelector(".site-search");
  const input = controls.querySelector("#siteSearchInput");
  form.addEventListener("submit", (event) => {
    event.preventDefault();
    showSearchResults(input.value.trim());
  });

  input.addEventListener("input", () => {
    if (input.value.trim().length >= 2) {
      showSearchResults(input.value.trim());
    } else {
      resultBox.classList.remove("open");
    }
  });

  document.addEventListener("click", (event) => {
    if (!event.target.closest(".site-search") && !event.target.closest(".search-results")) {
      resultBox.classList.remove("open");
    }
  });
}

function showSearchResults(query) {
  const resultBox = document.querySelector(".search-results");
  const inner = document.querySelector(".search-results-inner");
  if (!resultBox || !inner) return;

  const q = query.toLowerCase();
  const results = searchIndex.filter((item) => {
    return `${item.title} ${item.category} ${item.description}`.toLowerCase().includes(q);
  }).slice(0, 8);

  if (!query) {
    resultBox.classList.remove("open");
    return;
  }

  inner.innerHTML = `
    <div class="search-heading">Search results for “${escapeHtml(query)}”</div>
    ${results.length ? results.map(item => `
      <a class="search-result-item" href="${item.url}">
        <span>${item.category}</span>
        <strong>${item.title}</strong>
        <p>${item.description}</p>
      </a>
    `).join("") : `<p class="no-results">No results found.</p>`}
  `;
  resultBox.classList.add("open");
}

function escapeHtml(value) {
  value = applySleeperIdentityOverride(String(value || ""));
  return value.replace(/[&<>'"]/g, (char) => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    "'": "&#039;",
    '"': "&quot;"
  }[char]));
}

addBreakingTicker();
addSiteControls();
applySleeperTextOverrides();
startSleeperIdentityObserver();


function initHeroCarousel() {
  const carousel = document.querySelector("[data-hero-carousel]");
  if (!carousel) return;

  const slides = Array.from(carousel.querySelectorAll(".hero-slide"));
  const dots = Array.from(carousel.querySelectorAll(".hero-dot"));
  let currentSlide = 0;
  let timer;

  function showSlide(index) {
    currentSlide = (index + slides.length) % slides.length;
    slides.forEach((slide, i) => slide.classList.toggle("active", i === currentSlide));
    dots.forEach((dot, i) => dot.classList.toggle("active", i === currentSlide));
  }

  function start() {
    timer = setInterval(() => showSlide(currentSlide + 1), 6500);
  }

  function restart() {
    clearInterval(timer);
    start();
  }

  dots.forEach((dot, index) => {
    dot.addEventListener("click", () => {
      showSlide(index);
      restart();
    });
  });

  carousel.addEventListener("mouseenter", () => clearInterval(timer));
  carousel.addEventListener("mouseleave", start);

  start();
}

initHeroCarousel();

/* ===========================
   SLEEPER INTEGRATION
   Live standings + transaction wire
=========================== */

const SLEEPER_LEAGUES = {
  nffl: "1314378987576774656",
  gleague: "1314378817090916352"
};

const NFFL_TEAM_MAPS = {
  nffl: [
    { team: "Team allyotarola", coach: "allyotarola", division: "East" },
    { team: "Team damianhartfield", coach: "damianhartfield", division: "East" },
    { team: '"Tank" Dell lover', coach: "mjd413", division: "East" },
    { team: "Ricks and Mortys", coach: "C137er", division: "North" },
    { team: "Team Elliottmintz", coach: "Elliottmintz", division: "North" },
    { team: "Cleveland Browns", coach: "conorfigueroa", division: "North" },
    { team: "Team KURSED", coach: "KURSED", division: "West" },
    { team: "Team nastybob", coach: "nastybob", division: "West" },
    { team: "Brian's Team", coach: "mrbshoff", division: "West" },
    { team: "Team CrimsonChin1", coach: "CrimsonChin1", division: "South" },
    { team: "Team carter867", coach: "carter867", division: "South" },
    { team: "Birds", coach: "gabe161", division: "South" },
    { team: "Team Knightmare005", coach: "Knightmare005", division: "South" },
    { team: "Team DJSP", coach: "DJSP", division: "West" },
    { team: "The Revengers", coach: "DJSP", division: "West" }
  ],
  gleague: [
    { team: "Jet 2 Holliday", coach: "BigFudge2502", division: "East" },
    { team: "Team oredwin1014", coach: "oredwin1014", division: "East" },
    { team: "Darth Burden", coach: "PnutXprs63", division: "East" },
    { team: "Team OskyStrangler", coach: "OskyStrangler", division: "West" },
    { team: "The Hunter Games", coach: "Oddytyes", division: "West" },
    { team: "Mugshot", coach: "ThomGoat", division: "West" },
    { team: "CMcDonalds", coach: "alicat242", division: "North" },
    { team: "Cleveland Browns", coach: "conorfigueroa", division: "North" },
    { team: "Team CloudedNickTV", coach: "CloudedNickTV", division: "North" },
    { team: "Team Knightmare005", coach: "Knightmare005", division: "South" },
    { team: "Team Edoggydawg720", coach: "Edoggydawg720", division: "South" },
    { team: "The Revengers", coach: "DJSP", division: "West" }
  ]
};

const sleeperCache = new Map();

async function sleeperFetch(path) {
  const url = `https://api.sleeper.app/v1${path}`;
  if (sleeperCache.has(url)) return sleeperCache.get(url);
  const response = await fetch(url);
  if (!response.ok) throw new Error(`Sleeper API error: ${response.status}`);
  const data = await response.json();
  sleeperCache.set(url, data);
  return data;
}

function normalizeName(value) {
  return String(value || "").toLowerCase().replace(/[^a-z0-9]/g, "");
}

/* ===========================
   SLEEPER IDENTITY OVERRIDES
   Keeps website branding independent from Sleeper usernames.
=========================== */

const SLEEPER_IDENTITY_OVERRIDES = {
  mjd413: "mjd413"
};

function applySleeperIdentityOverride(value) {
  const raw = String(value || "");
  const override = SLEEPER_IDENTITY_OVERRIDES[normalizeName(raw)];
  return override || raw;
}

function applySleeperTextOverrides(root = document.body) {
  if (!root) return;
  const replacements = [
    [/mjd413/g, "mjd413"],
    [/MJD413/g, "MJD413"],
    [/mjd413/g, "mjd413"]
  ];

  const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
  const nodes = [];
  while (walker.nextNode()) nodes.push(walker.currentNode);

  nodes.forEach((node) => {
    let text = node.nodeValue;
    replacements.forEach(([pattern, replacement]) => {
      text = text.replace(pattern, replacement);
    });
    if (text !== node.nodeValue) node.nodeValue = text;
  });
}

function startSleeperIdentityObserver() {
  if (!document.body || window.__nfflIdentityObserverStarted) return;
  window.__nfflIdentityObserverStarted = true;

  applySleeperTextOverrides(document.body);

  const observer = new MutationObserver((mutations) => {
    for (const mutation of mutations) {
      if (mutation.type === "characterData" && mutation.target?.nodeType === Node.TEXT_NODE) {
        let text = mutation.target.nodeValue;
        text = text.replace(/mjd413/g, "mjd413").replace(/MJD413/g, "MJD413").replace(/mjd413/g, "mjd413");
        if (text !== mutation.target.nodeValue) mutation.target.nodeValue = text;
      }
      mutation.addedNodes.forEach((node) => {
        if (node.nodeType === Node.TEXT_NODE) {
          let text = node.nodeValue;
          text = text.replace(/mjd413/g, "mjd413").replace(/MJD413/g, "MJD413").replace(/mjd413/g, "mjd413");
          if (text !== node.nodeValue) node.nodeValue = text;
        } else if (node.nodeType === Node.ELEMENT_NODE) {
          applySleeperTextOverrides(node);
        }
      });
    }
  });

  observer.observe(document.body, {
    childList: true,
    subtree: true,
    characterData: true
  });
}



function getSleeperTeamInfo(leagueKey, roster, user) {
  const map = NFFL_TEAM_MAPS[leagueKey] || [];
  const sleeperTeam = applySleeperIdentityOverride(applySleeperIdentityOverride(roster?.metadata?.team_name || user?.metadata?.team_name || user?.display_name || user?.username || `Roster ${roster?.roster_id || ""}`));
  const sleeperCoach = applySleeperIdentityOverride(applySleeperIdentityOverride(user?.display_name || user?.username || roster?.owner_id || "TBD"));
  const normalizedSleeperTeam = normalizeName(sleeperTeam);
  const normalizedCoach = normalizeName(sleeperCoach);

  const match = map.find((entry) => {
    const team = normalizeName(entry.team);
    const coach = normalizeName(entry.coach);
    return coach === normalizedCoach || team === normalizedSleeperTeam || normalizedSleeperTeam.includes(team) || team.includes(normalizedSleeperTeam);
  });

  return {
    team: match?.team || sleeperTeam,
    coach: sleeperCoach,
    ownerId: roster?.owner_id || null,
    username: user?.username || null,
    division: match?.division || "Sleeper",
    avatar: user?.avatar || null
  };
}

function sleeperPoints(primary, decimal) {
  return Number(primary || 0) + Number(decimal || 0) / 100;
}

async function loadSleeperStandings(leagueKey) {
  const leagueId = SLEEPER_LEAGUES[leagueKey];
  const root = document.querySelector(`[data-sleeper-standings="${leagueKey}"]`);
  if (!leagueId || !root) return;

  const status = root.querySelector("[data-sleeper-status]");
  if (status) status.textContent = "Loading live standings from Sleeper...";

  try {
    const [rosters, users] = await Promise.all([
      sleeperFetch(`/league/${leagueId}/rosters`),
      sleeperFetch(`/league/${leagueId}/users`)
    ]);

    const usersById = Object.fromEntries(users.map((user) => [user.user_id, user]));

    let divisionOverrides = [];
    try {
      const client = window.nfflPublicSupabase;
      if (client) {
        const { data } = await client
          .from('team_content')
          .select('team_name,coach_name,division')
          .eq('league', leagueKey);
        divisionOverrides = data || [];
      }
    } catch (error) {
      console.warn('Could not load standings division overrides:', error.message);
    }

    const standings = rosters.map((roster) => {
      const user = usersById[roster.owner_id];
      const info = getSleeperTeamInfo(leagueKey, roster, user);
      const override = divisionOverrides.find((row) => {
        const team = normalizeName(row.team_name);
        const coach = normalizeName(row.coach_name);
        return team === normalizeName(info.team) || coach === normalizeName(info.coach);
      });
      if (override?.division) info.division = override.division;
      const wins = Number(roster.settings?.wins || 0);
      const losses = Number(roster.settings?.losses || 0);
      const ties = Number(roster.settings?.ties || 0);
      const pf = sleeperPoints(roster.settings?.fpts, roster.settings?.fpts_decimal);
      const pa = sleeperPoints(roster.settings?.fpts_against, roster.settings?.fpts_against_decimal);
      return { ...info, wins, losses, ties, pf, pa, streak: roster.settings?.streak || "-", rosterId: roster.roster_id };
    }).sort((a, b) => {
      if (b.wins !== a.wins) return b.wins - a.wins;
      if (a.losses !== b.losses) return a.losses - b.losses;
      return b.pf - a.pf;
    });

    renderLeagueStandings(root, standings);
    renderDivisionStandings(root, standings);

    if (status) {
      status.innerHTML = `<span class="live-badge">Live from Sleeper</span> Updated automatically from league ID ${leagueId}`;
    }
  } catch (error) {
    console.error(error);
    if (status) status.textContent = "Could not load Sleeper standings. Showing static fallback table.";
  }
}

function renderLeagueStandings(root, standings) {
  const tbody = root.querySelector("#league-standings tbody, [data-league-standings-body], #league-standings-body");
  if (!tbody) return;

  const isCompact = tbody.id === "league-standings-body" || tbody.dataset.compactStandings === "true";

  tbody.innerHTML = standings.map((team, index) => {
    if (isCompact) {
      return `
        <tr>
          <td>${index + 1}</td>
          <td>${escapeHtml(team.team)}</td>
          <td>${team.wins}-${team.losses}${team.ties ? `-${team.ties}` : ""}</td>
          <td>${team.pf.toFixed(2)}</td>
        </tr>
      `;
    }

    return `
      <tr>
        <td>${index + 1}</td>
        <td>${escapeHtml(team.team)}</td>
        <td>${escapeHtml(team.coach)}</td>
        <td>${team.wins}</td>
        <td>${team.losses}${team.ties ? `-${team.ties}` : ""}</td>
        <td>${team.pf.toFixed(2)}</td>
        <td>${team.pa.toFixed(2)}</td>
        <td>${escapeHtml(String(team.streak || "-"))}</td>
        <td>${escapeHtml(team.division)}</td>
      </tr>
    `;
  }).join("");
}

function renderDivisionStandings(root, standings) {
  const divisions = ["East", "North", "West", "South"];
  divisions.forEach((division) => {
    const card = root.querySelector(`[data-division="${division}"]`);
    if (!card) return;
    const tbody = card.querySelector("tbody");
    const divisionTeams = standings.filter((team) => team.division === division);
    tbody.innerHTML = divisionTeams.map((team) => `
      <tr>
        <td>${escapeHtml(team.team)}</td>
        <td>${escapeHtml(team.coach)}</td>
        <td>${team.wins}-${team.losses}${team.ties ? `-${team.ties}` : ""}</td>
        <td>${team.pf.toFixed(2)}</td>
        <td>${team.pa.toFixed(2)}</td>
      </tr>
    `).join("") || `<tr><td colspan="5">No matched Sleeper teams found for this division.</td></tr>`;
  });
}

async function loadSleeperTransactions(leagueKey) {
  const leagueId = SLEEPER_LEAGUES[leagueKey];
  const root = document.querySelector(`[data-sleeper-transactions="${leagueKey}"]`);
  if (!leagueId || !root) return;

  const status = root.querySelector("[data-sleeper-status]");
  const list = root.querySelector("[data-transaction-list]");
  const transactionLimit = Number(root.dataset.transactionLimit || 25);
  if (status) status.textContent = "Loading live transaction wire from Sleeper...";

  try {
    const [rosters, users, state] = await Promise.all([
      sleeperFetch(`/league/${leagueId}/rosters`),
      sleeperFetch(`/league/${leagueId}/users`),
      sleeperFetch(`/state/nfl`)
    ]);

    const currentWeek = Math.max(1, Math.min(18, Number(state?.week || 1)));
    const weeks = Array.from({ length: currentWeek }, (_, index) => index + 1).reverse();
    const transactionBatches = await Promise.all(
      weeks.map((week) => sleeperFetch(`/league/${leagueId}/transactions/${week}`).catch(() => []))
    );

    const transactions = transactionBatches.flat().sort((a, b) => Number(b.created || 0) - Number(a.created || 0)).slice(0, transactionLimit);
    const usersById = Object.fromEntries(users.map((user) => [user.user_id, user]));
    const rostersById = Object.fromEntries(rosters.map((roster) => [roster.roster_id, roster]));
    const rosterNames = {};
    rosters.forEach((roster) => {
      rosterNames[roster.roster_id] = getSleeperTeamInfo(leagueKey, roster, usersById[roster.owner_id]).team;
    });

    let players = null;
    if (transactions.some((transaction) => transaction.adds || transaction.drops || transaction.draft_picks)) {
      players = await loadSleeperPlayers();
    }

    if (list) {
      list.innerHTML = transactions.length
        ? transactions.map((transaction) => renderTransactionItem(transaction, rosterNames, players)).join("")
        : `<div class="transaction-item"><h3>No transactions yet</h3><p>Sleeper has not returned transactions for the current season rounds.</p></div>`;
    }

    if (status) {
      status.innerHTML = `<span class="live-badge">Live from Sleeper</span> Latest transactions from league ID ${leagueId}`;
    }
  } catch (error) {
    console.error(error);
    if (status) status.textContent = "Could not load Sleeper transactions. Showing static fallback wire.";
  }
}

async function loadSleeperPlayers() {
  const storageKey = "nffl-sleeper-players-v1";
  const cached = sessionStorage.getItem(storageKey);
  if (cached) return JSON.parse(cached);
  const players = await sleeperFetch("/players/nfl");
  try { sessionStorage.setItem(storageKey, JSON.stringify(players)); } catch (_) {}
  return players;
}

function playerName(playerId, players) {
  const player = players?.[playerId];
  if (!player) return playerId;
  return player.full_name || `${player.first_name || ""} ${player.last_name || ""}`.trim() || playerId;
}

function playerInfo(playerId, players) {
  const player = players?.[playerId] || {};
  return {
    name: playerName(playerId, players),
    position: player.position || "-",
    team: player.team || "FA"
  };
}

function rosterMatchesPage(leagueKey, roster, user, targetTeam, targetCoach) {
  const info = getSleeperTeamInfo(leagueKey, roster, user);
  const pageTeam = normalizeName(targetTeam);
  const pageCoach = normalizeName(targetCoach);
  const infoTeam = normalizeName(info.team);
  const infoCoach = normalizeName(info.coach);
  return (pageTeam && (pageTeam === infoTeam || infoTeam.includes(pageTeam) || pageTeam.includes(infoTeam))) ||
         (pageCoach && (pageCoach === infoCoach || infoCoach.includes(pageCoach) || pageCoach.includes(infoCoach)));
}



function rosterIdentityValues(roster, user) {
  return [
    roster?.metadata?.team_name,
    user?.metadata?.team_name,
    user?.display_name,
    user?.username,
    roster?.owner_id
  ].map(normalizeName).filter(Boolean);
}

function findRosterForTeamPage(leagueKey, rosters, usersById, {
  teamKey = "",
  targetTeam = "",
  targetCoach = "",
  mappedRosterId = null
} = {}) {
  if (mappedRosterId) {
    const mapped = rosters.find((item) => Number(item.roster_id) === Number(mappedRosterId));
    if (mapped) return mapped;
  }

  // Match the permanent page key and current Sleeper account identity directly.
  // This fixes newly promoted/replacement owners even when the old static
  // franchise map or Supabase mapping has not been updated yet.
  const pageValues = [teamKey, targetTeam, targetCoach]
    .map(normalizeName)
    .filter(Boolean);

  const direct = rosters.find((roster) => {
    const values = rosterIdentityValues(roster, usersById[roster.owner_id]);
    return pageValues.some((pageValue) =>
      values.some((value) =>
        pageValue === value ||
        (pageValue.length >= 4 && value.includes(pageValue)) ||
        (value.length >= 4 && pageValue.includes(value))
      )
    );
  });
  if (direct) return direct;

  // Keep the existing branded team-map matcher as a final fallback.
  return rosters.find((roster) =>
    rosterMatchesPage(
      leagueKey,
      roster,
      usersById[roster.owner_id],
      targetTeam,
      targetCoach
    )
  ) || null;
}

async function waitForPublicSupabase(timeoutMs = 3500) {
  const started = Date.now();
  while (!window.nfflPublicSupabase && Date.now() - started < timeoutMs) {
    await new Promise((resolve) => setTimeout(resolve, 50));
  }
  return window.nfflPublicSupabase || null;
}

async function mappedSleeperRosterId(leagueKey, card) {
  const pageRoot = card.closest("[data-live-owner-team-key]") ||
    document.querySelector("[data-live-owner-team-key]");
  const teamKey = pageRoot?.dataset.liveOwnerTeamKey || card.dataset.teamKey || "";
  if (!teamKey) return null;

  const client = await waitForPublicSupabase();
  if (!client) return null;

  const { data, error } = await client
    .from("team_content")
    .select("sleeper_roster_id")
    .eq("league", leagueKey)
    .eq("team_key", teamKey)
    .maybeSingle();

  if (error) {
    console.warn("Could not read Sleeper roster mapping:", error.message);
    return null;
  }

  return Number(data?.sleeper_roster_id) || null;
}

async function loadSleeperRosters() {
  const rosterCards = document.querySelectorAll("[data-sleeper-roster]");
  if (!rosterCards.length) return;

  for (const card of rosterCards) {
    const leagueKey = card.dataset.sleeperRoster || "nffl";
    const leagueId = SLEEPER_LEAGUES[leagueKey];
    const status = card.querySelector("[data-roster-status]");
    const tbody = card.querySelector("[data-roster-list]");
    const targetTeam = card.dataset.teamName || "";
    const targetCoach = card.dataset.coach || "";

    if (!leagueId || !tbody) continue;
    if (status) status.textContent = "Loading live roster from Sleeper...";

    try {
      const [rosters, users, players] = await Promise.all([
        sleeperFetch(`/league/${leagueId}/rosters`),
        sleeperFetch(`/league/${leagueId}/users`),
        loadSleeperPlayers()
      ]);
      const usersById = Object.fromEntries(users.map((user) => [user.user_id, user]));

      // Use the permanent roster-slot mapping first. This keeps the page working
      // when a new Sleeper user replaces the previous owner.
      const mappedRosterId = await mappedSleeperRosterId(leagueKey, card);
      const pageRoot = card.closest("[data-live-owner-team-key]") ||
        document.querySelector("[data-live-owner-team-key]");
      const teamKey = pageRoot?.dataset.liveOwnerTeamKey || card.dataset.teamKey || "";

      const roster = findRosterForTeamPage(leagueKey, rosters, usersById, {
        teamKey,
        targetTeam,
        targetCoach,
        mappedRosterId
      });

      if (!roster) {
        tbody.innerHTML = `<tr><td colspan="4">No Sleeper roster match found yet.</td></tr>`;
        if (status) {
          status.textContent = mappedRosterId
            ? `Sleeper roster ${mappedRosterId} was mapped, but it was not returned by this league.`
            : "No roster slot is mapped to this franchise. Open Admin → Roster Sync and save the correct roster connection.";
        }
        continue;
      }

      const starters = new Set(roster.starters || []);
      const playerIds = roster.players || [];
      const rows = playerIds.map((id) => {
        const player = playerInfo(id, players);
        const slot = starters.has(id) ? "Starter" : "Bench";
        return { id, ...player, slot };
      }).sort((a, b) => {
        const slotOrder = { Starter: 0, Bench: 1 };
        const posOrder = { QB: 0, RB: 1, WR: 2, TE: 3, K: 4, DEF: 5 };
        return (slotOrder[a.slot] ?? 9) - (slotOrder[b.slot] ?? 9) || (posOrder[a.position] ?? 9) - (posOrder[b.position] ?? 9) || a.name.localeCompare(b.name);
      });

      tbody.innerHTML = rows.length ? rows.map((player) => `
        <tr>
          <td><span class="roster-slot ${player.slot === "Starter" ? "starter" : "bench"}">${player.slot}</span></td>
          <td>${escapeHtml(player.name)}</td>
          <td>${escapeHtml(player.position)}</td>
          <td>${escapeHtml(player.team)}</td>
        </tr>
      `).join("") : `<tr><td colspan="4">This Sleeper roster has no players listed yet.</td></tr>`;

      const info = getSleeperTeamInfo(leagueKey, roster, usersById[roster.owner_id]);
      if (status) {
        status.innerHTML = `<span class="live-badge">Live from Sleeper</span> ${escapeHtml(info.team)} roster updated automatically from roster ${roster.roster_id}`;
      }
    } catch (error) {
      console.error(error);
      if (status) status.textContent = "Could not load Sleeper roster right now.";
    }
  }
}

function renderTransactionItem(transaction, rosterNames, players) {
  const type = String(transaction.type || "transaction").replace(/_/g, " ");
  const date = transaction.created ? new Date(Number(transaction.created)).toLocaleDateString() : "Sleeper";

  const playerAdds = transaction.adds || {};
  const playerDrops = transaction.drops || {};
  const tradedPicks = Array.isArray(transaction.draft_picks) ? transaction.draft_picks : [];

  const rosterIds = Array.from(new Set([
    ...(transaction.roster_ids || []),
    ...Object.values(playerAdds),
    ...Object.values(playerDrops),
    ...tradedPicks.flatMap((pick) => [
      pick.owner_id,
      pick.previous_owner_id,
      pick.roster_id
    ]).filter(Boolean)
  ]));

  const teamName = (rosterId) => rosterNames[rosterId] || `Roster ${rosterId}`;
  const teams = rosterIds.map((id) => teamName(id)).filter(Boolean);

  const pickLabel = (pick) => {
    const season = pick.season || "Future";
    const round = pick.round ? `Round ${pick.round}` : "Draft";
    const originalTeam = pick.roster_id ? teamName(pick.roster_id) : "";
    return `${season} ${round} pick${originalTeam ? ` (via ${originalTeam})` : ""}`;
  };

  let headline = type.toUpperCase();
  let body = "Transaction processed on Sleeper.";

  if (transaction.type === "trade") {
    headline = `Trade: ${teams.join(" ↔ ") || "Multiple teams"}`;

    const sideOrder = rosterIds.filter((id) => {
      const receivedPlayer = Object.values(playerAdds).some((rosterId) => Number(rosterId) === Number(id));
      const sentPlayer = Object.values(playerDrops).some((rosterId) => Number(rosterId) === Number(id));
      const receivedPick = tradedPicks.some((pick) => Number(pick.owner_id) === Number(id));
      const sentPick = tradedPicks.some((pick) => Number(pick.previous_owner_id) === Number(id));
      return receivedPlayer || sentPlayer || receivedPick || sentPick;
    });

    const sideBlocks = sideOrder.map((rosterId) => {
      const receivedPlayers = Object.entries(playerAdds)
        .filter(([, ownerId]) => Number(ownerId) === Number(rosterId))
        .map(([playerId]) => playerName(playerId, players));

      const sentPlayers = Object.entries(playerDrops)
        .filter(([, ownerId]) => Number(ownerId) === Number(rosterId))
        .map(([playerId]) => playerName(playerId, players));

      const receivedPicks = tradedPicks
        .filter((pick) => Number(pick.owner_id) === Number(rosterId))
        .map(pickLabel);

      const sentPicks = tradedPicks
        .filter((pick) => Number(pick.previous_owner_id) === Number(rosterId))
        .map(pickLabel);

      const receivedAssets = [...receivedPlayers, ...receivedPicks];
      const sentAssets = [...sentPlayers, ...sentPicks];

      return `
        <section class="trade-side-block">
          <h4>${escapeHtml(teamName(rosterId))}</h4>
          ${receivedAssets.length ? `
            <div class="trade-asset-group trade-received">
              <strong>Receives</strong>
              <ul>${receivedAssets.map((asset) => `<li>${escapeHtml(asset)}</li>`).join("")}</ul>
            </div>
          ` : ""}
          ${sentAssets.length ? `
            <div class="trade-asset-group trade-sent">
              <strong>Sends</strong>
              <ul>${sentAssets.map((asset) => `<li>${escapeHtml(asset)}</li>`).join("")}</ul>
            </div>
          ` : ""}
        </section>
      `;
    }).join("");

    body = sideBlocks
      ? `<div class="trade-sides">${sideBlocks}</div>`
      : "Trade details are available through Sleeper.";
  } else {
    const adds = Object.entries(playerAdds).map(([id, rosterId]) =>
      `${escapeHtml(teamName(rosterId))} added ${escapeHtml(playerName(id, players))}`
    );
    const drops = Object.entries(playerDrops).map(([id, rosterId]) =>
      `${escapeHtml(teamName(rosterId))} dropped ${escapeHtml(playerName(id, players))}`
    );

    if (adds.length || drops.length) {
      headline = `${type}: ${teams[0] || "Roster move"}`;
      body = [...adds, ...drops].join(" • ");
    } else if (transaction.type === "waiver") {
      headline = `Waiver move: ${teams[0] || "Roster move"}`;
    } else if (transaction.type === "free_agent") {
      headline = `Free agent move: ${teams[0] || "Roster move"}`;
    }
  }

  return `
    <div class="transaction-item${transaction.type === "trade" ? " formatted-trade-item" : ""}">
      <span class="transaction-meta">${escapeHtml(type)} • ${escapeHtml(date)}</span>
      <h3>${escapeHtml(headline)}</h3>
      ${transaction.type === "trade" ? body : `<p>${body}</p>`}
    </div>
  `;
}



async function getSleeperContextForTeam(leagueKey, targetTeam, targetCoach) {
  const leagueId = SLEEPER_LEAGUES[leagueKey];
  if (!leagueId) return null;

  const [league, rosters, users] = await Promise.all([
    sleeperFetch(`/league/${leagueId}`),
    sleeperFetch(`/league/${leagueId}/rosters`),
    sleeperFetch(`/league/${leagueId}/users`)
  ]);

  const usersById = Object.fromEntries(users.map((user) => [user.user_id, user]));

  // Team pages are permanently connected to a Sleeper roster ID in Supabase.
  // Use that exact roster before attempting any username/team-name matching.
  const pageRoot = document.querySelector(`[data-live-owner-league="${leagueKey}"][data-live-owner-team-key]`) ||
    document.querySelector("[data-live-owner-team-key]");
  const teamKey = pageRoot?.dataset.liveOwnerTeamKey || "";
  let mappedRosterId = null;

  if (teamKey) {
    const client = await waitForPublicSupabase();
    if (client) {
      const { data, error } = await client
        .from("team_content")
        .select("sleeper_roster_id")
        .eq("league", leagueKey)
        .eq("team_key", teamKey)
        .maybeSingle();

      if (error) console.warn("Could not read team roster mapping:", error.message);
      mappedRosterId = Number(data?.sleeper_roster_id) || null;
    }
  }

  const roster = findRosterForTeamPage(leagueKey, rosters, usersById, {
    teamKey,
    targetTeam,
    targetCoach,
    mappedRosterId
  });

  const rosterNames = {};
  rosters.forEach((item) => {
    rosterNames[item.roster_id] = getSleeperTeamInfo(leagueKey, item, usersById[item.owner_id]).team;
  });

  return {
    league,
    rosters,
    users,
    usersById,
    roster: roster || null,
    rosterNames,
    mappedRosterId,
    teamKey
  };
}

async function loadSleeperDraftPicks() {
  const pickCards = document.querySelectorAll("[data-sleeper-draft-picks]");
  if (!pickCards.length) return;

  for (const card of pickCards) {
    const leagueKey = card.dataset.sleeperDraftPicks || "nffl";
    const leagueId = SLEEPER_LEAGUES[leagueKey];
    const status = card.querySelector("[data-draft-picks-status]");
    const tbody = card.querySelector("[data-draft-picks-list]");
    const targetTeam = card.dataset.teamName || "";
    const targetCoach = card.dataset.coach || "";

    if (!leagueId || !tbody) continue;
    if (status) status.textContent = "Loading future picks from Sleeper...";

    try {
      const context = await getSleeperContextForTeam(leagueKey, targetTeam, targetCoach);
      if (!context || !context.roster) {
        tbody.innerHTML = `<tr><td colspan="3">No Sleeper roster match found yet.</td></tr>`;
        if (status) status.textContent = context?.mappedRosterId ? `Mapped roster ${context.mappedRosterId} is not present in this Sleeper league.` : "No roster slot is connected to this franchise. Use Admin → Roster Sync.";
        continue;
      }

      const tradedPicks = await sleeperFetch(`/league/${leagueId}/traded_picks`).catch(() => []);
      const currentSeason = Number(context.league?.season || new Date().getFullYear());
      const rounds = Number(context.league?.settings?.draft_rounds || context.league?.settings?.taxi_slots || 4) || 4;
      const seasons = [currentSeason + 1, currentSeason + 2, currentSeason + 3];
      const ownership = new Map();

      context.rosters.forEach((roster) => {
        seasons.forEach((season) => {
          for (let round = 1; round <= rounds; round += 1) {
            ownership.set(`${season}-${round}-${roster.roster_id}`, roster.roster_id);
          }
        });
      });

      tradedPicks.forEach((pick) => {
        const season = Number(pick.season);
        const round = Number(pick.round);
        const originalRoster = Number(pick.roster_id);
        const owner = Number(pick.owner_id);
        const key = `${season}-${round}-${originalRoster}`;
        if (ownership.has(key)) ownership.set(key, owner);
      });

      const owned = [];
      ownership.forEach((owner, key) => {
        if (Number(owner) !== Number(context.roster.roster_id)) return;
        const [season, round, originalRoster] = key.split("-").map(Number);
        owned.push({
          season,
          round,
          originalTeam: context.rosterNames[originalRoster] || `Roster ${originalRoster}`
        });
      });

      owned.sort((a, b) => a.season - b.season || a.round - b.round || a.originalTeam.localeCompare(b.originalTeam));

      tbody.innerHTML = owned.length ? owned.map((pick) => `
        <tr>
          <td>${pick.season}</td>
          <td>Round ${pick.round}</td>
          <td>${escapeHtml(pick.originalTeam)}</td>
        </tr>
      `).join("") : `<tr><td colspan="3">No future picks found through Sleeper.</td></tr>`;

      if (status) status.innerHTML = `<span class="live-badge">Live from Sleeper</span> Future picks inferred from default picks + traded picks`;
    } catch (error) {
      console.error(error);
      if (status) status.textContent = "Could not load draft picks right now.";
    }
  }
}

async function loadSleeperTeamTransactions() {
  const transactionCards = document.querySelectorAll("[data-sleeper-team-transactions]");
  if (!transactionCards.length) return;

  for (const card of transactionCards) {
    const leagueKey = card.dataset.sleeperTeamTransactions || "nffl";
    const leagueId = SLEEPER_LEAGUES[leagueKey];
    const status = card.querySelector("[data-team-transactions-status]");
    const list = card.querySelector("[data-team-transactions-list]");
    const targetTeam = card.dataset.teamName || "";
    const targetCoach = card.dataset.coach || "";

    if (!leagueId || !list) continue;
    if (status) status.textContent = "Loading recent moves from Sleeper...";

    try {
      const context = await getSleeperContextForTeam(leagueKey, targetTeam, targetCoach);
      if (!context || !context.roster) {
        list.innerHTML = `<div class="transaction-item"><h3>No roster match found</h3><p>Could not match this team page to a Sleeper roster.</p></div>`;
        if (status) status.textContent = context?.mappedRosterId ? `Mapped roster ${context.mappedRosterId} is not present in this Sleeper league.` : "No roster slot is connected to this franchise. Use Admin → Roster Sync.";
        continue;
      }

      const state = await sleeperFetch(`/state/nfl`);
      const currentWeek = Math.max(1, Math.min(18, Number(state?.week || 1)));
      const weeks = Array.from({ length: currentWeek }, (_, index) => index + 1).reverse();
      const transactionBatches = await Promise.all(
        weeks.map((week) => sleeperFetch(`/league/${leagueId}/transactions/${week}`).catch(() => []))
      );

      const rosterId = Number(context.roster.roster_id);
      const teamTransactions = transactionBatches.flat()
        .filter((transaction) => transactionInvolvesRoster(transaction, rosterId))
        .sort((a, b) => Number(b.created || 0) - Number(a.created || 0))
        .slice(0, 12);

      let players = null;
      if (teamTransactions.some((transaction) => transaction.adds || transaction.drops || transaction.draft_picks)) {
        players = await loadSleeperPlayers();
      }

      list.innerHTML = teamTransactions.length
        ? teamTransactions.map((transaction) => renderTransactionItem(transaction, context.rosterNames, players)).join("")
        : `<div class="transaction-item"><h3>No recent moves yet</h3><p>Sleeper has not returned recent transactions for this team.</p></div>`;

      if (status) status.innerHTML = `<span class="live-badge">Live from Sleeper</span> Team-specific wire from Sleeper`;
    } catch (error) {
      console.error(error);
      if (status) status.textContent = "Could not load team transactions right now.";
    }
  }
}

function transactionInvolvesRoster(transaction, rosterId) {
  const targetRosterId = Number(rosterId);

  // Sleeper's roster_ids array represents the teams that directly participated
  // in the transaction. This is the safest source for trades.
  const directRosters = (transaction.roster_ids || []).map(Number);
  if (directRosters.includes(targetRosterId)) return true;

  // Adds and drops identify the team directly making a waiver/free-agent move.
  const addRosters = Object.values(transaction.adds || {}).map(Number);
  const dropRosters = Object.values(transaction.drops || {}).map(Number);
  if (addRosters.includes(targetRosterId) || dropRosters.includes(targetRosterId)) return true;

  // For traded draft picks:
  // - previous_owner_id = team sending the pick
  // - owner_id = team receiving the pick
  // - roster_id = franchise the pick originally belongs to
  //
  // The original franchise is NOT necessarily a participant in the trade, so
  // roster_id must never be used to decide whether the trade appears on that
  // franchise's transaction wire.
  const actualPickParticipants = (transaction.draft_picks || [])
    .flatMap((pick) => [pick.previous_owner_id, pick.owner_id])
    .map(Number)
    .filter(Number.isFinite);

  return actualPickParticipants.includes(targetRosterId);
}



/* ===========================
   SLEEPER DRAFT HISTORY
   Startup + rookie draft tabs
=========================== */

function draftSeason(draft) {
  return String(draft.season || draft.metadata?.season || draft.settings?.season || "").trim();
}

function draftNameText(draft) {
  return String([
    draft.metadata?.name,
    draft.name,
    draft.metadata?.description,
    draft.type,
    draft.metadata?.type
  ].filter(Boolean).join(" ")).toLowerCase();
}

function isStartupDraft(draft, index, sortedDrafts) {
  const text = draftNameText(draft);
  const rounds = Number(draft.settings?.rounds || draft.settings?.draft_rounds || 0);
  if (text.includes("startup") || text.includes("start-up")) return true;
  if (text.includes("rookie")) return false;
  if (rounds >= 10) return true;
  return index === 0 && sortedDrafts.length > 1;
}

function draftLabel(draft, index, sortedDrafts = []) {
  if (isStartupDraft(draft, index, sortedDrafts)) return "STARTUP";
  return draftSeason(draft) || `ROOKIE ${index + 1}`;
}

function sortSleeperDrafts(drafts) {
  const byDate = [...drafts].sort((a, b) => {
    const seasonA = Number(a.season || a.metadata?.season || 0);
    const seasonB = Number(b.season || b.metadata?.season || 0);
    if (seasonA !== seasonB) return seasonA - seasonB;
    return Number(a.created || 0) - Number(b.created || 0);
  });

  return byDate.sort((a, b) => {
    const aStartup = isStartupDraft(a, byDate.indexOf(a), byDate);
    const bStartup = isStartupDraft(b, byDate.indexOf(b), byDate);
    if (aStartup !== bStartup) return aStartup ? -1 : 1;
    const seasonA = Number(a.season || a.metadata?.season || 0);
    const seasonB = Number(b.season || b.metadata?.season || 0);
    if (seasonA !== seasonB) return seasonA - seasonB;
    return Number(a.created || 0) - Number(b.created || 0);
  });
}

async function fetchLeagueDraftsAcrossHistory(leagueId) {
  const draftsById = new Map();
  const seenLeagues = new Set();
  let currentLeagueId = leagueId;

  for (let depth = 0; currentLeagueId && depth < 10 && !seenLeagues.has(currentLeagueId); depth += 1) {
    seenLeagues.add(currentLeagueId);
    const [league, drafts] = await Promise.all([
      sleeperFetch(`/league/${currentLeagueId}`).catch(() => null),
      sleeperFetch(`/league/${currentLeagueId}/drafts`).catch(() => [])
    ]);

    (drafts || []).forEach((draft) => {
      if (draft?.draft_id && !draftsById.has(draft.draft_id)) draftsById.set(draft.draft_id, draft);
    });

    const leagueDraftId = league?.draft_id || league?.metadata?.draft_id;
    if (leagueDraftId && !draftsById.has(leagueDraftId)) {
      try {
        const draft = await sleeperFetch(`/draft/${leagueDraftId}`);
        if (draft?.draft_id) draftsById.set(draft.draft_id, draft);
      } catch (_) {}
    }

    currentLeagueId = league?.previous_league_id || null;
  }

  return [...draftsById.values()];
}

function formatDraftSlot(pick) {
  const round = Number(pick.round || 0);
  const pickInRound = Number(pick.draft_slot || pick.pick_no || 0);
  if (round && pickInRound) return `${round}.${String(pickInRound).padStart(2, "0")}`;
  if (pick.pick_no) return `Pick ${pick.pick_no}`;
  return "-";
}

function draftPickTeamName(pick, rosterNames, userNames) {
  const rosterId = Number(pick.roster_id || pick.picked_by);
  if (rosterNames[rosterId]) return rosterNames[rosterId];
  if (userNames[pick.picked_by]) return userNames[pick.picked_by];
  return pick.picked_by ? `Pick owner ${pick.picked_by}` : "TBD";
}

async function loadSleeperDraftHistory() {
  const roots = document.querySelectorAll("[data-sleeper-draft-history]");
  if (!roots.length) return;

  for (const root of roots) {
    const leagueKey = root.dataset.sleeperDraftHistory || "nffl";
    const leagueId = SLEEPER_LEAGUES[leagueKey];
    const status = root.querySelector("[data-draft-history-status], [data-season-standings-status], [data-season-playoffs-status]");
    const tabs = root.querySelector("[data-draft-tabs]");
    const panels = root.querySelector("[data-draft-panels]");

    if (!leagueId || !tabs || !panels) continue;
    if (status) status.textContent = "Loading draft history from Sleeper...";

    try {
      const [draftsRaw, rosters, users, players] = await Promise.all([
        fetchLeagueDraftsAcrossHistory(leagueId),
        sleeperFetch(`/league/${leagueId}/rosters`),
        sleeperFetch(`/league/${leagueId}/users`),
        loadSleeperPlayers()
      ]);

      const drafts = sortSleeperDrafts(draftsRaw || []);
      if (!drafts.length) {
        tabs.innerHTML = "";
        panels.innerHTML = `<div class="rank-item"><h3>No drafts found</h3><p>Sleeper has not returned any drafts for this league yet.</p></div>`;
        if (status) status.textContent = "No Sleeper drafts found yet.";
        continue;
      }

      const usersById = Object.fromEntries(users.map((user) => [user.user_id, user]));
      const userNames = Object.fromEntries(users.map((user) => [user.user_id, applySleeperIdentityOverride(applySleeperIdentityOverride(user.display_name || user.username || user.user_id))]));
      const rosterNames = {};
      rosters.forEach((roster) => {
        rosterNames[roster.roster_id] = getSleeperTeamInfo(leagueKey, roster, usersById[roster.owner_id]).team;
      });

      const pickSets = await Promise.all(
        drafts.map((draft) => sleeperFetch(`/draft/${draft.draft_id}/picks`).catch(() => []))
      );

      tabs.innerHTML = drafts.map((draft, index) => `
        <button class="draft-history-tab ${index === 0 ? "active" : ""}" data-draft-target="draft-${draft.draft_id}" type="button">
          ${escapeHtml(draftLabel(draft, index, drafts))}
        </button>
      `).join("");

      panels.innerHTML = drafts.map((draft, index) => {
        const picks = [...(pickSets[index] || [])].sort((a, b) => Number(a.pick_no || 0) - Number(b.pick_no || 0));
        const rows = picks.map((pick) => {
          const player = playerInfo(pick.player_id, players);
          return `
            <tr>
              <td>${escapeHtml(formatDraftSlot(pick))}</td>
              <td>${escapeHtml(draftPickTeamName(pick, rosterNames, userNames))}</td>
              <td>${escapeHtml(player.name)}</td>
              <td>${escapeHtml(player.position)}</td>
              <td>${escapeHtml(player.team)}</td>
            </tr>
          `;
        }).join("") || `<tr><td colspan="5">No picks are available for this draft yet.</td></tr>`;

        return `
          <div id="draft-${draft.draft_id}" class="draft-history-panel ${index === 0 ? "active" : ""}">
            <div class="table-card draft-history-card">
              <table class="draft-history-table">
                <thead><tr><th>Pick</th><th>Team</th><th>Player</th><th>Pos</th><th>NFL Team</th></tr></thead>
                <tbody>${rows}</tbody>
              </table>
            </div>
          </div>
        `;
      }).join("");

      tabs.querySelectorAll(".draft-history-tab").forEach((button) => {
        button.addEventListener("click", () => {
          tabs.querySelectorAll(".draft-history-tab").forEach((item) => item.classList.remove("active"));
          panels.querySelectorAll(".draft-history-panel").forEach((item) => item.classList.remove("active"));
          button.classList.add("active");
          const panel = panels.querySelector(`#${CSS.escape(button.dataset.draftTarget)}`);
          if (panel) panel.classList.add("active");
        });
      });

      if (status) status.innerHTML = `<span class="live-badge">Live from Sleeper</span> ${drafts.length} draft${drafts.length === 1 ? "" : "s"} loaded from league ID ${leagueId}`;
    } catch (error) {
      console.error(error);
      if (status) status.textContent = "Could not load Sleeper draft history right now.";
      panels.innerHTML = `<div class="rank-item"><h3>Draft history unavailable</h3><p>Sleeper did not return draft data. Try refreshing later.</p></div>`;
    }
  }
}




/* ===========================
   SEASON VAULT: Archived standings + playoff brackets
   Pulls the matching historical Sleeper league season when available.
=========================== */

async function findSleeperLeagueForSeason(leagueKey, targetSeason) {
  const startLeagueId = SLEEPER_LEAGUES[leagueKey];
  const wanted = String(targetSeason || "");
  const seen = new Set();
  let currentLeagueId = startLeagueId;
  let fallback = null;

  for (let depth = 0; currentLeagueId && depth < 12 && !seen.has(currentLeagueId); depth += 1) {
    seen.add(currentLeagueId);
    const league = await sleeperFetch(`/league/${currentLeagueId}`).catch(() => null);
    if (!league) break;
    if (!fallback) fallback = league;

    const leagueSeason = String(league.season || league.metadata?.season || "");
    if (leagueSeason === wanted) return league;

    currentLeagueId = league.previous_league_id || null;
  }

  return fallback;
}

async function loadSleeperSeasonStandings() {
  const roots = document.querySelectorAll("[data-sleeper-season-standings]");
  if (!roots.length) return;

  for (const root of roots) {
    const leagueKey = root.dataset.sleeperSeasonStandings || "nffl";
    const season = root.dataset.season || "2025";
    const status = root.querySelector("[data-season-standings-status]");
    const tbody = root.querySelector("[data-season-standings-body]");
    const leagueId = SLEEPER_LEAGUES[leagueKey];

    if (!leagueId || !tbody) continue;
    if (status) status.textContent = `Loading ${season} final standings from Sleeper...`;

    try {
      const league = await findSleeperLeagueForSeason(leagueKey, season);
      const archiveLeagueId = league?.league_id || leagueId;
      const [rosters, users] = await Promise.all([
        sleeperFetch(`/league/${archiveLeagueId}/rosters`),
        sleeperFetch(`/league/${archiveLeagueId}/users`)
      ]);

      const usersById = Object.fromEntries((users || []).map((user) => [user.user_id, user]));
      const standings = (rosters || []).map((roster) => {
        const user = usersById[roster.owner_id];
        const info = getSleeperTeamInfo(leagueKey, roster, user);
        const wins = Number(roster.settings?.wins || 0);
        const losses = Number(roster.settings?.losses || 0);
        const ties = Number(roster.settings?.ties || 0);
        const pf = sleeperPoints(roster.settings?.fpts, roster.settings?.fpts_decimal);
        const pa = sleeperPoints(roster.settings?.fpts_against, roster.settings?.fpts_against_decimal);
        return { ...info, wins, losses, ties, pf, pa, rosterId: roster.roster_id };
      }).sort((a, b) => {
        if (b.wins !== a.wins) return b.wins - a.wins;
        if (a.losses !== b.losses) return a.losses - b.losses;
        return b.pf - a.pf;
      });

      tbody.innerHTML = standings.map((team, index) => {
        const record = `${team.wins}-${team.losses}${team.ties ? `-${team.ties}` : ""}`;
        const knownResult = normalizeName(team.coach) === "crimsonchin1" || normalizeName(team.team) === "teamcrimsonchin1"
          ? "Champion"
          : (normalizeName(team.coach) === "cloudednicktv" || normalizeName(team.team) === "teamcloudednicktv" ? "Runner-Up" : (index === 0 ? "Best Record" : "-"));
        return `
          <tr>
            <td>${index + 1}</td>
            <td>${escapeHtml(team.team)}</td>
            <td>${escapeHtml(team.coach)}</td>
            <td>${escapeHtml(record)}</td>
            <td>${team.pf.toFixed(2)}</td>
            <td>${team.pa.toFixed(2)}</td>
            <td>${escapeHtml(knownResult)}</td>
          </tr>
        `;
      }).join("") || `<tr><td colspan="7">Sleeper did not return final standings for this season.</td></tr>`;

      if (status) {
        const exact = String(league?.season || "") === String(season);
        status.innerHTML = `<span class="live-badge">Sleeper Archive</span> ${exact ? season : "Latest available"} standings loaded from league ID ${archiveLeagueId}`;
      }
    } catch (error) {
      console.error(error);
      if (status) status.textContent = "Could not load archived Sleeper standings. Showing static fallback.";
    }
  }
}

function playoffRosterLabel(rosterId, rosterNames) {
  if (!rosterId) return "TBD";
  return rosterNames[Number(rosterId)] || `Roster ${rosterId}`;
}

function playoffTeamRow(rosterId, score, winnerId, rosterNames) {
  const isWinner = String(rosterId || "") === String(winnerId || "");
  return `
    <div class="playoff-team ${isWinner ? "winner" : ""}">
      <span>${escapeHtml(playoffRosterLabel(rosterId, rosterNames))}</span>
      <strong>${score !== undefined && score !== null ? escapeHtml(String(score)) : (isWinner ? "Winner" : "-")}</strong>
    </div>
  `;
}

async function loadSleeperSeasonPlayoffs() {
  const roots = document.querySelectorAll("[data-sleeper-season-playoffs]");
  if (!roots.length) return;

  for (const root of roots) {
    const leagueKey = root.dataset.sleeperSeasonPlayoffs || "nffl";
    const season = root.dataset.season || "2025";
    const status = root.querySelector("[data-season-playoffs-status]");
    const bracketRoot = root.querySelector("[data-season-playoffs-bracket]");
    const leagueId = SLEEPER_LEAGUES[leagueKey];

    if (!leagueId || !bracketRoot) continue;
    if (status) status.textContent = `Loading ${season} playoff bracket from Sleeper...`;

    try {
      const league = await findSleeperLeagueForSeason(leagueKey, season);
      const archiveLeagueId = league?.league_id || leagueId;
      const [bracket, rosters, users] = await Promise.all([
        sleeperFetch(`/league/${archiveLeagueId}/winners_bracket`).catch(() => []),
        sleeperFetch(`/league/${archiveLeagueId}/rosters`),
        sleeperFetch(`/league/${archiveLeagueId}/users`)
      ]);

      const usersById = Object.fromEntries((users || []).map((user) => [user.user_id, user]));
      const rosterNames = {};
      (rosters || []).forEach((roster) => {
        rosterNames[roster.roster_id] = getSleeperTeamInfo(leagueKey, roster, usersById[roster.owner_id]).team;
      });

      const allGames = [...(bracket || [])].sort((a, b) => Number(a.r || 0) - Number(b.r || 0) || Number(a.m || 0) - Number(b.m || 0));
      const winnerGames = allGames.filter((game) => Number(game.r || 1) <= 3);
      if (!winnerGames.length) {
        bracketRoot.innerHTML = `
          <div class="rank-item"><h3>No Sleeper bracket found</h3><p>Sleeper did not return the first three winners-bracket rounds for this archived season. You can still keep the manual championship result below.</p></div>
        `;
        if (status) status.textContent = "No Sleeper playoff bracket returned for this season.";
        continue;
      }

      const rounds = [...new Set(winnerGames.map((game) => Number(game.r || 1)))].slice(0, 3);
      function playoffRoundName(round, index, totalRounds) {
        if (index === totalRounds - 1) return "Championship";
        if (totalRounds === 3 && index === 0) return "Quarterfinals";
        if (totalRounds === 3 && index === 1) return "Semifinals";
        if (totalRounds === 2 && index === 0) return "Semifinals";
        return `Round ${round}`;
      }

      bracketRoot.innerHTML = rounds.map((round, index) => {
        let roundGames = winnerGames
          .filter((game) => Number(game.r || 1) === round)
          .sort((a, b) => Number(a.m || 0) - Number(b.m || 0));

        /*
          Sleeper's winners_bracket endpoint can include extra placement games
          inside the same round numbers. The NFFL archive should only show
          the actual championship bracket: up to 4 quarterfinals, 2 semifinals,
          and 1 championship game. Placement/toilet-bowl games should not be
          mixed into the main bracket.
        */
        const maxGamesByRoundIndex = rounds.length === 3 ? [4, 2, 1] : (rounds.length === 2 ? [2, 1] : [1]);
        const maxGames = maxGamesByRoundIndex[index] || 1;
        roundGames = roundGames.slice(0, maxGames);

        const roundName = playoffRoundName(round, index, rounds.length);
        return `
          <div class="playoff-round">
            <h3>${escapeHtml(roundName)}</h3>
            ${roundGames.map((game) => `
              <div class="playoff-game">
                ${playoffTeamRow(game.t1, game.t1_points, game.w, rosterNames)}
                ${playoffTeamRow(game.t2, game.t2_points, game.w, rosterNames)}
              </div>
            `).join("")}
          </div>
        `;
      }).join("");

      if (status) {
        const exact = String(league?.season || "") === String(season);
        status.innerHTML = `<span class="live-badge">Sleeper Archive</span> ${exact ? season : "Latest available"} playoff bracket loaded from league ID ${archiveLeagueId}`;
      }
    } catch (error) {
      console.error(error);
      if (status) status.textContent = "Could not load archived Sleeper playoff bracket. Showing static fallback.";
    }
  }
}


/* ===========================
   SLEEPER LIVE TRADE BLOCK
   Best-effort reader for trade block data exposed in roster/user metadata.
=========================== */

function collectPossibleTradeBlockValues(source, depth = 0) {
  if (!source || depth > 4) return [];
  const values = [];

  if (Array.isArray(source)) {
    values.push(source);
    source.forEach((item) => values.push(...collectPossibleTradeBlockValues(item, depth + 1)));
    return values;
  }

  if (typeof source === "string") {
    const trimmed = source.trim();
    if (!trimmed) return values;
    if (trimmed.startsWith("[") || trimmed.startsWith("{")) {
      try { values.push(...collectPossibleTradeBlockValues(JSON.parse(trimmed), depth + 1)); } catch (_) {}
    }
    values.push(trimmed);
    return values;
  }

  if (typeof source !== "object") return values;

  Object.entries(source).forEach(([key, value]) => {
    const normalizedKey = normalizeName(key);
    const looksLikeTradeBlock =
      normalizedKey.includes("tradeblock") ||
      normalizedKey.includes("tradingblock") ||
      normalizedKey.includes("playersontheblock") ||
      normalizedKey.includes("playersontblock") ||
      (normalizedKey.includes("trade") && normalizedKey.includes("block")) ||
      (normalizedKey.includes("block") && normalizedKey.includes("player"));

    if (looksLikeTradeBlock) values.push(value);
    if (value && typeof value === "object") values.push(...collectPossibleTradeBlockValues(value, depth + 1));
  });

  return values;
}

function extractPlayerIdsFromTradeBlockValue(value, players) {
  const ids = new Set();
  const addIfPlayer = (candidate) => {
    const text = String(candidate || "").trim();
    if (!text) return;
    if (players?.[text]) ids.add(text);
  };

  const walk = (item) => {
    if (!item) return;
    if (Array.isArray(item)) {
      item.forEach(walk);
      return;
    }
    if (typeof item === "string" || typeof item === "number") {
      const text = String(item).trim();
      if (players?.[text]) {
        ids.add(text);
        return;
      }
      if (text.includes(",")) text.split(",").forEach(addIfPlayer);
      if (text.includes("|")) text.split("|").forEach(addIfPlayer);
      if (text.includes(" ")) text.split(/\s+/).forEach(addIfPlayer);
      return;
    }
    if (typeof item === "object") {
      Object.entries(item).forEach(([key, val]) => {
        if (players?.[key] && (val === true || val === "true" || val === 1 || val === "1" || typeof val === "object")) ids.add(key);
        if (["player_id", "playerId", "id", "player"].includes(key)) addIfPlayer(val);
        walk(val);
      });
    }
  };

  walk(value);
  return [...ids];
}

function extractTradeBlockPlayers(roster, user, players) {
  const candidates = [roster?.metadata, roster?.settings, roster, user?.metadata, user]
    .flatMap((source) => collectPossibleTradeBlockValues(source));
  return [...new Set(candidates.flatMap((value) => extractPlayerIdsFromTradeBlockValue(value, players)))];
}

function renderTradeBlockCard(item, players) {
  const playerChips = item.playerIds.map((id) => {
    const player = playerInfo(id, players);
    return `<span class="trade-block-chip">${escapeHtml(player.name)} <small>${escapeHtml(player.position)} • ${escapeHtml(player.team)}</small></span>`;
  }).join("");

  return `
    <div class="trade-block-card">
      <h3>${escapeHtml(item.team)}</h3>
      <p>Coach: ${escapeHtml(item.coach)}${item.division ? ` • ${escapeHtml(item.division)}` : ""}</p>
      <div class="trade-block-assets">${playerChips}</div>
    </div>
  `;
}

async function loadSleeperTradeBlocks() {
  const roots = document.querySelectorAll("[data-sleeper-trade-block]");
  if (!roots.length) return;

  for (const root of roots) {
    const leagueKey = root.dataset.sleeperTradeBlock || "nffl";
    const leagueId = SLEEPER_LEAGUES[leagueKey];
    const status = root.querySelector("[data-trade-block-status]");
    const list = root.querySelector("[data-trade-block-list]");
    if (!leagueId || !list) continue;
    if (status) status.textContent = "Checking Sleeper for live trade block listings...";

    try {
      const [rosters, users, players] = await Promise.all([
        sleeperFetch(`/league/${leagueId}/rosters`),
        sleeperFetch(`/league/${leagueId}/users`),
        loadSleeperPlayers()
      ]);
      const usersById = Object.fromEntries(users.map((user) => [user.user_id, user]));
      const blockItems = rosters.map((roster) => {
        const user = usersById[roster.owner_id];
        const info = getSleeperTeamInfo(leagueKey, roster, user);
        const playerIds = extractTradeBlockPlayers(roster, user, players);
        return { ...info, rosterId: roster.roster_id, playerIds };
      }).filter((item) => item.playerIds.length);

      if (blockItems.length) {
        list.innerHTML = blockItems.map((item) => renderTradeBlockCard(item, players)).join("");
        if (status) status.innerHTML = `<span class="live-badge">Live from Sleeper</span> ${blockItems.length} roster${blockItems.length === 1 ? "" : "s"} with trade block assets loaded`;
      } else {
        list.innerHTML = `
          <div class="transaction-item">
            <h3>No live trade block assets found</h3>
            <p>Sleeper did not expose any trade block players through the public league data for this league. If managers use the Sleeper mobile trade block and it becomes available in roster metadata, this section will populate automatically.</p>
          </div>`;
        if (status) status.innerHTML = `<span class="live-badge">Checked Sleeper</span> No public trade block data returned`;
      }
    } catch (error) {
      console.error(error);
      if (status) status.textContent = "Could not load trade block data right now.";
    }
  }
}


/* ===========================
   HOME RECENT TRANSACTIONS + TEAM NEWS/HISTORY
=========================== */

const TEAM_POWER_RANKINGS_TOP4 = [
  { rank: 1, coach: "conorfigueroa", title: "Way Too Early Power Rankings: No. 1", text: "conorfigueroa opens the first NFFL rankings cycle at the top of the league." },
  { rank: 2, coach: "mrbshoff", title: "Way Too Early Power Rankings: No. 2", text: "mrbshoff starts the year inside the top two with clear title expectations." },
  { rank: 3, coach: "nastybob", title: "Way Too Early Power Rankings: No. 3", text: "nastybob's aggressive roster building lands him in the early contender tier." },
  { rank: 4, coach: "C137er", title: "Way Too Early Power Rankings: No. 4", text: "C137er begins the season as a dangerous top-four team." }
];

const STATIC_TEAM_HONORS = {
  nffl: {
    crimsonchin1: ["2025 NFFL Champion"],
    cloudednicktv: ["2025 NFFL Runner-Up"],
    carter867: ["2025 Best Regular Season Record: 11-3"]
  }
};

async function getRecentSleeperTransactions(leagueKey, limit = 3) {
  const leagueId = SLEEPER_LEAGUES[leagueKey];
  if (!leagueId) return { transactions: [], rosterNames: {}, players: null };

  const [rosters, users, state] = await Promise.all([
    sleeperFetch(`/league/${leagueId}/rosters`),
    sleeperFetch(`/league/${leagueId}/users`),
    sleeperFetch(`/state/nfl`)
  ]);

  const currentWeek = Math.max(1, Math.min(18, Number(state?.week || 1)));
  const weeks = Array.from({ length: currentWeek }, (_, index) => index + 1).reverse();
  const transactionBatches = await Promise.all(
    weeks.map((week) => sleeperFetch(`/league/${leagueId}/transactions/${week}`).catch(() => []))
  );

  const usersById = Object.fromEntries(users.map((user) => [user.user_id, user]));
  const rosterNames = {};
  rosters.forEach((roster) => {
    rosterNames[roster.roster_id] = getSleeperTeamInfo(leagueKey, roster, usersById[roster.owner_id]).team;
  });

  const transactions = transactionBatches.flat()
    .sort((a, b) => Number(b.created || 0) - Number(a.created || 0))
    .slice(0, limit);

  let players = null;
  if (transactions.some((transaction) => transaction.adds || transaction.drops || transaction.draft_picks)) {
    players = await loadSleeperPlayers();
  }

  return { transactions, rosterNames, players };
}

function renderHomeTransaction(transaction, rosterNames, players) {
  const type = String(transaction.type || "transaction").replace(/_/g, " ").toUpperCase();
  const created = transaction.created ? new Date(Number(transaction.created)) : null;
  const date = created ? created.toLocaleString([], { month: "short", day: "numeric", hour: "numeric", minute: "2-digit" }) : "Sleeper";
  const rosterIds = Array.from(new Set([...(transaction.roster_ids || []), ...Object.values(transaction.adds || {}), ...Object.values(transaction.drops || {})]));
  const teams = rosterIds.map((id) => rosterNames[id]).filter(Boolean);
  const adds = Object.entries(transaction.adds || {}).map(([id, rosterId]) => `${rosterNames[rosterId] || `Roster ${rosterId}`} added ${playerName(id, players)}`);
  const drops = Object.entries(transaction.drops || {}).map(([id, rosterId]) => `${rosterNames[rosterId] || `Roster ${rosterId}`} dropped ${playerName(id, players)}`);

  let headline = type;
  let summary = "Transaction processed on Sleeper.";
  if (transaction.type === "trade") {
    headline = `Trade: ${teams.join(" ↔ ") || "Multiple teams"}`;
    summary = [...adds, ...drops].slice(0, 3).join(" • ") || "Trade details available in the full transaction wire.";
  } else if (adds.length || drops.length) {
    headline = `${type}: ${teams[0] || "Roster move"}`;
    summary = [...adds, ...drops].slice(0, 3).join(" • ");
  }

  return `
    <div class="home-transaction-item">
      <span>${escapeHtml(type)} • ${escapeHtml(date)}</span>
      <strong>${escapeHtml(headline)}</strong>
      <p>${escapeHtml(summary)}</p>
    </div>
  `;
}

async function loadHomeTransactionSummaries() {
  const roots = document.querySelectorAll("[data-home-transactions]");
  if (!roots.length) return;

  for (const root of roots) {
    const leagueKey = root.dataset.homeTransactions || "nffl";
    const status = root.querySelector("[data-home-transactions-status]");
    const list = root.querySelector("[data-home-transactions-list]");
    if (!list) continue;
    if (status) status.textContent = "Loading the 3 most recent Sleeper transactions...";

    try {
      const { transactions, rosterNames, players } = await getRecentSleeperTransactions(leagueKey, 3);
      list.innerHTML = transactions.length
        ? transactions.map((transaction) => renderHomeTransaction(transaction, rosterNames, players)).join("")
        : `<div class="home-transaction-item"><span>Live Wire</span><strong>No recent transactions</strong><p>Sleeper has not returned any current transaction activity yet.</p></div>`;
      if (status) status.innerHTML = `<span class="live-badge">Live from Sleeper</span> Showing latest 3 moves`;
    } catch (error) {
      console.error(error);
      if (status) status.textContent = "Could not load recent transactions right now.";
    }
  }
}

function renderTeamNewsItem(category, title, text, url) {
  return `
    <a class="mini-news-item" href="${escapeHtml(url)}">
      <span>${escapeHtml(category)}</span>
      <strong>${escapeHtml(title)}</strong>
      <p>${escapeHtml(text)}</p>
    </a>
  `;
}

function loadTeamNewsPanels() {
  document.querySelectorAll("[data-team-news]").forEach((card) => {
    const list = card.querySelector("[data-team-news-list]");
    if (!list) return;
    const team = card.dataset.teamName || "";
    const coach = card.dataset.coach || "";
    const normTeam = normalizeName(team);
    const normCoach = normalizeName(coach);
    const items = [];

    searchIndex.forEach((entry) => {
      const haystack = normalizeName(`${entry.title} ${entry.description}`);
      if ((normTeam && haystack.includes(normTeam)) || (normCoach && haystack.includes(normCoach))) {
        items.push(renderTeamNewsItem(entry.category, entry.title, entry.description, entry.url));
      }
    });

    TEAM_POWER_RANKINGS_TOP4.forEach((entry) => {
      if (normalizeName(entry.coach) === normCoach) {
        items.push(renderTeamNewsItem("Power Rankings", entry.title, entry.text, "power-rankings.html"));
      }
    });

    if (normalizeName(coach) === "crimsonchin1") {
      items.push(renderTeamNewsItem("History", "CrimsonChin1 crowned 2025 NFFL Champion", "The franchise is listed in the permanent NFFL championship timeline.", "history.html"));
    }
    if (normalizeName(coach) === "carter867") {
      items.push(renderTeamNewsItem("History", "carter867 posts 2025's best regular season record", "The 11-3 campaign is archived in the Season Vault.", "history.html"));
    }

    items.push(renderTeamNewsItem("Team Hub", `${team} official team page`, `Roster, draft picks, transactions, and franchise notes for Coach ${coach}.`, "teams.html"));

    list.innerHTML = items.slice(0, 4).join("");
  });
}

async function fetchAllTimeRecordForOwner(leagueId, ownerId) {
  let wins = 0;
  let losses = 0;
  let ties = 0;
  let seasons = 0;
  const seenLeagues = new Set();
  let currentLeagueId = leagueId;

  for (let depth = 0; currentLeagueId && depth < 10 && !seenLeagues.has(currentLeagueId); depth += 1) {
    seenLeagues.add(currentLeagueId);
    try {
      const [league, rosters] = await Promise.all([
        sleeperFetch(`/league/${currentLeagueId}`).catch(() => null),
        sleeperFetch(`/league/${currentLeagueId}/rosters`).catch(() => [])
      ]);

      const roster = (rosters || []).find((item) => String(item.owner_id || '') === String(ownerId || ''));
      if (roster) {
        wins += Number(roster.settings?.wins || 0);
        losses += Number(roster.settings?.losses || 0);
        ties += Number(roster.settings?.ties || 0);
        seasons += 1;
      }

      currentLeagueId = league?.previous_league_id || null;
    } catch (_) {
      break;
    }
  }

  return { wins, losses, ties, seasons };
}

function formatRecord(wins, losses, ties = 0) {
  return `${Number(wins || 0)}-${Number(losses || 0)}${Number(ties || 0) ? `-${Number(ties || 0)}` : ''}`;
}

async function loadSleeperTeamHistory() {
  const cards = document.querySelectorAll("[data-sleeper-team-history]");
  if (!cards.length) return;

  for (const card of cards) {
    const leagueKey = card.dataset.sleeperTeamHistory || "nffl";
    const targetTeam = card.dataset.teamName || "";
    const targetCoach = card.dataset.coach || "";
    const status = card.querySelector("[data-team-history-status]");
    const list = card.querySelector("[data-team-history-list]");
    if (!list) continue;
    if (status) status.textContent = "Loading franchise snapshot from Sleeper...";

    try {
      const context = await getSleeperContextForTeam(leagueKey, targetTeam, targetCoach);
      if (!context || !context.roster) {
        list.innerHTML = `<div class="history-stat"><span>Status</span><strong>No Sleeper match</strong></div>`;
        if (status) status.textContent = context?.mappedRosterId ? `Mapped roster ${context.mappedRosterId} is not present in this Sleeper league.` : "No roster slot is connected to this franchise. Use Admin → Roster Sync.";
        continue;
      }

      const usersById = context.usersById;
      const standings = context.rosters.map((roster) => {
        const user = usersById[roster.owner_id];
        const info = getSleeperTeamInfo(leagueKey, roster, user);
        const wins = Number(roster.settings?.wins || 0);
        const losses = Number(roster.settings?.losses || 0);
        const ties = Number(roster.settings?.ties || 0);
        const pf = sleeperPoints(roster.settings?.fpts, roster.settings?.fpts_decimal);
        const pa = sleeperPoints(roster.settings?.fpts_against, roster.settings?.fpts_against_decimal);
        return { ...info, rosterId: roster.roster_id, wins, losses, ties, pf, pa };
      }).sort((a, b) => b.wins - a.wins || a.losses - b.losses || b.pf - a.pf);

      const rosterId = Number(context.roster.roster_id);
      const team = standings.find((item) => Number(item.rosterId) === rosterId);
      const rank = standings.findIndex((item) => Number(item.rosterId) === rosterId) + 1;
      const divisionTeams = standings.filter((item) => item.division === team.division);
      const divisionRank = divisionTeams.findIndex((item) => Number(item.rosterId) === rosterId) + 1;
      const record = formatRecord(team.wins, team.losses, team.ties);
      const allTime = await fetchAllTimeRecordForOwner(SLEEPER_LEAGUES[leagueKey], context.roster.owner_id);
      const allTimeRecord = formatRecord(allTime.wins, allTime.losses, allTime.ties);

      list.innerHTML = `
        <div class="history-stat"><span>Current Record</span><strong>${escapeHtml(record)}</strong></div>
        <div class="history-stat"><span>All-Time Record</span><strong>${escapeHtml(allTimeRecord)}</strong></div>
        <div class="history-stat"><span>League Rank</span><strong>${rank || "-"}</strong></div>
        <div class="history-stat"><span>Division Rank</span><strong>${divisionRank || "-"}</strong></div>
        <div class="history-stat"><span>Points For</span><strong>${team.pf.toFixed(2)}</strong></div>
        <div class="history-stat"><span>Points Against</span><strong>${team.pa.toFixed(2)}</strong></div>
        <div class="history-stat"><span>Championships</span><strong>${normalizeName(targetTeam) === 'team crimsonchin1' ? '1' : '0'}</strong></div>
        <div class="history-stat"><span>Best Record</span><strong>${normalizeName(targetTeam) === 'team carter867' ? '11-3 (2025)' : 'TBD'}</strong></div>
      `;
      if (status) status.innerHTML = `<span class="live-badge">Live from Sleeper</span> Current season + all-time franchise record`;
    } catch (error) {
      console.error(error);
      if (status) status.textContent = "Could not load franchise snapshot right now.";
    }
  }
}

loadTeamNewsPanels();

/* ===========================
   SMART SLEEPER REFRESH MANAGER
   Refreshes visible live data every 120 seconds.
=========================== */

const LIVE_REFRESH_INTERVAL_MS = 120000;
let liveRefreshTimer = null;
let liveRefreshInProgress = false;
let liveRefreshHasRun = false;

function pageHasLiveSleeperData() {
  return Boolean(document.querySelector([
    "[data-sleeper-standings]",
    "[data-sleeper-transactions]",
    "[data-sleeper-roster]",
    "[data-sleeper-draft-picks]",
    "[data-sleeper-team-transactions]",
    "[data-sleeper-draft-history]",
    "[data-sleeper-season-standings]",
    "[data-sleeper-season-playoffs]",
    "[data-home-transactions]",
    "[data-sleeper-team-history]"
  ].join(",")));
}

function visibleLeagueKeys(selector, dataKey) {
  return [...new Set(
    Array.from(document.querySelectorAll(selector))
      .map((element) => element.dataset[dataKey])
      .filter(Boolean)
  )];
}

function updateLastUpdatedIndicators(date = new Date()) {
  const text = date.toLocaleTimeString([], { hour: "numeric", minute: "2-digit", second: "2-digit" });
  document.querySelectorAll("[data-live-updated]").forEach((element) => {
    element.innerHTML = `<span class="live-badge">Live</span> Last updated: ${text}`;
  });
}

function ensureLiveUpdatedIndicators() {
  document.querySelectorAll([
    "[data-sleeper-standings]",
    "[data-sleeper-transactions]",
    "[data-sleeper-roster]",
    "[data-sleeper-draft-picks]",
    "[data-sleeper-team-transactions]",
    "[data-sleeper-draft-history]",
    "[data-sleeper-season-standings]",
    "[data-sleeper-season-playoffs]",
    "[data-home-transactions]",
    "[data-sleeper-team-history]"
  ].join(",")).forEach((root, index) => {
    if (root.querySelector("[data-live-updated]")) return;
    const indicator = document.createElement("div");
    indicator.className = "live-updated";
    indicator.setAttribute("data-live-updated", "");
    indicator.innerHTML = `<span class="live-badge">Live</span> Waiting for first update`;

    const status = root.querySelector("[data-sleeper-status], [data-roster-status], [data-draft-picks-status], [data-team-transactions-status], [data-draft-history-status], [data-season-standings-status], [data-season-playoffs-status], [data-home-transactions-status], [data-team-history-status]");
    if (status) {
      status.insertAdjacentElement("afterend", indicator);
    } else {
      root.prepend(indicator);
    }
  });
}

async function refreshVisibleSleeperData({ clearCache = true } = {}) {
  if (!pageHasLiveSleeperData() || liveRefreshInProgress) return;
  liveRefreshInProgress = true;

  try {
    if (clearCache) sleeperCache.clear();

    const standingsKeys = visibleLeagueKeys("[data-sleeper-standings]", "sleeperStandings");
    const transactionKeys = visibleLeagueKeys("[data-sleeper-transactions]", "sleeperTransactions");

    const tasks = [
      ...standingsKeys.map((leagueKey) => loadSleeperStandings(leagueKey)),
      ...transactionKeys.map((leagueKey) => loadSleeperTransactions(leagueKey))
    ];

    if (document.querySelector("[data-sleeper-roster]")) tasks.push(loadSleeperRosters());
    if (document.querySelector("[data-sleeper-draft-picks]")) tasks.push(loadSleeperDraftPicks());
    if (document.querySelector("[data-sleeper-team-transactions]")) tasks.push(loadSleeperTeamTransactions());
    if (document.querySelector("[data-home-transactions]")) tasks.push(loadHomeTransactionSummaries());
    if (document.querySelector("[data-sleeper-team-history]")) tasks.push(loadSleeperTeamHistory());
    if (!liveRefreshHasRun && document.querySelector("[data-sleeper-draft-history]")) tasks.push(loadSleeperDraftHistory());
    if (!liveRefreshHasRun && document.querySelector("[data-sleeper-season-standings]")) tasks.push(loadSleeperSeasonStandings());
    if (!liveRefreshHasRun && document.querySelector("[data-sleeper-season-playoffs]")) tasks.push(loadSleeperSeasonPlayoffs());

    await Promise.allSettled(tasks);
    applySleeperTextOverrides();
    applySleeperTextOverrides(document.body);
    updateLastUpdatedIndicators();
    liveRefreshHasRun = true;
  } finally {
    liveRefreshInProgress = false;
  }
}

function startLiveRefreshManager() {
  if (!pageHasLiveSleeperData()) return;
  ensureLiveUpdatedIndicators();
  refreshVisibleSleeperData({ clearCache: true });

  if (liveRefreshTimer) clearInterval(liveRefreshTimer);
  liveRefreshTimer = setInterval(() => {
    if (!document.hidden) refreshVisibleSleeperData({ clearCache: true });
  }, LIVE_REFRESH_INTERVAL_MS);

  document.addEventListener("visibilitychange", () => {
    if (!document.hidden) refreshVisibleSleeperData({ clearCache: true });
  });
}

startLiveRefreshManager();
