(function createTeamValidation(){
  const HEX = /^#[0-9a-f]{6}$/i;
  const HTTP_URL = /^https?:\/\/\S+$/i;

  function validateTeam(team, allTeams){
    const errors = [];
    const warnings = [];
    const comparable = (value) => String(value || '').trim().toLowerCase();
    const peers = (allTeams || []).filter((row) => Number(row.id) !== Number(team.id));

    if (!comparable(team.team_name)) errors.push('Team Name is required.');
    if (!comparable(team.team_key)) errors.push('Team Key is required.');
    if (!comparable(team.league)) errors.push('League is required.');
    if (!comparable(team.division) || comparable(team.division) === 'tbd') errors.push('Choose a division.');

    if (peers.some((row) =>
      comparable(row.league) === comparable(team.league) &&
      comparable(row.team_key) === comparable(team.team_key)
    )) errors.push('Team Key must be unique within its league.');

    const sleeperId = comparable(team.sleeper_owner_id);
    if (sleeperId && peers.some((row) =>
      comparable(row.league) === comparable(team.league) &&
      comparable(row.sleeper_owner_id) === sleeperId
    )) {
      errors.push('Sleeper Owner ID is already assigned to another team in this league.');
    }

    const rosterId = comparable(team.sleeper_roster_id);
    if (rosterId && peers.some((row) =>
      comparable(row.league) === comparable(team.league) &&
      comparable(row.sleeper_roster_id) === rosterId
    )) errors.push('Sleeper Roster ID is already assigned in this league.');

    const coach = comparable(team.coach_name);
    if (coach && coach !== 'vacant' && peers.some((row) => comparable(row.coach_name) === coach)) {
      warnings.push('Another franchise uses the same coach name.');
    }

    ['logo_url', 'banner_url', 'social_url'].forEach((field) => {
      const value = String(team[field] || '').trim();
      const localAsset = /^(\.\.\/|\.\/)?assets\/\S+$/i.test(value);
      if (value && !HTTP_URL.test(value) && !(field !== 'social_url' && localAsset)) {
        errors.push(`${field.replaceAll('_', ' ')} must be an http(s) URL${field === 'social_url' ? '.' : ' or an assets path.'}`);
      }
    });

    ['primary_color', 'secondary_color'].forEach((field) => {
      const value = String(team[field] || '').trim();
      if (value && !HEX.test(value)) errors.push(`${field.replaceAll('_', ' ')} must use six-digit hex format, such as #1A2B3C.`);
    });

    return { valid: errors.length === 0, errors, warnings };
  }

  window.NFFLTeamValidation = { validateTeam };
})();
