
(async function setupCrudEditor() {
  const cms = window.NFFLCMS;
  const body = document.body;
  const table = body.dataset.cmsTable;
  const order = body.dataset.cmsOrder || 'updated_at';
  const form = document.querySelector('[data-cms-form]');
  const list = document.querySelector('[data-cms-list]');
  const refresh = document.querySelector('[data-cms-refresh]');
  const newButton = document.querySelector('[data-cms-new]');
  const params = new URLSearchParams(location.search);
  const leagueFilter = params.get('league');

  if (!cms || !table || !form || !list) return;
  const client = cms.client();

  const leagueField = form.elements.namedItem('league');
  if (leagueFilter && leagueField) {
    leagueField.value = leagueFilter;
  }

  if (leagueFilter) {
    const pageTitle = document.querySelector('.page-title h1');
    if (pageTitle) {
      const label = leagueFilter === 'gleague' ? 'G-League' : 'NFFL';
      if (!pageTitle.textContent.startsWith(label)) pageTitle.textContent = `${label} ${pageTitle.textContent}`;
    }
  }

  function rowTitle(row) {
    return row.title || row.award_name || row.coach_name || row.team_name || row.content_key || `${table} #${row.id}`;
  }

  function rowSubtitle(row) {
    const parts = [];
    if (row.league) parts.push(row.league);
    if (row.season) parts.push(String(row.season));
    if (row.week !== null && row.week !== undefined) parts.push(`Week ${row.week}`);
    if (row.status) parts.push(row.status);
    if (row.published !== undefined) parts.push(row.published ? 'Published' : 'Draft');
    return parts.join(' • ');
  }

  async function loadRows() {
    cms.setStatus('Loading…');
    let query = client.from(table).select('*');
    if (leagueFilter && ['articles', 'awards', 'team_content', 'site_content', 'season_vaults'].includes(table)) {
      query = query.eq('league', leagueFilter);
    }
    if (order) query = query.order(order, { ascending: false, nullsFirst: false });
    const { data, error } = await query.limit(100);

    if (error) {
      cms.setStatus(error.message, 'error');
      list.innerHTML = `<div class="rank-item"><h3>Unable to load data</h3><p>${cms.escape(error.message)}</p></div>`;
      return;
    }

    cms.setStatus(`${data.length} record${data.length === 1 ? '' : 's'} loaded.`, 'success');
    list.innerHTML = data.length ? data.map((row) => `
      <article class="admin-record-card" data-row-id="${row.id}">
        <div>
          <h3>${cms.escape(rowTitle(row))}</h3>
          <p>${cms.escape(rowSubtitle(row))}</p>
        </div>
        <div class="admin-record-actions">
          <button type="button" data-edit> Edit </button>
          <button type="button" class="danger" data-delete> Delete </button>
        </div>
      </article>
    `).join('') : '<div class="rank-item"><h3>No Supabase records yet</h3><p>Use <a href="import-existing.html">Import Existing</a> to copy the current website content, or create a new entry using the form.</p></div>';

    list.querySelectorAll('[data-edit]').forEach((button) => {
      button.addEventListener('click', () => {
        const id = Number(button.closest('[data-row-id]').dataset.rowId);
        const row = data.find((item) => Number(item.id) === id);
        cms.fillForm(form, row);
        form.scrollIntoView({ behavior: 'smooth', block: 'start' });
      });
    });

    list.querySelectorAll('[data-delete]').forEach((button) => {
      button.addEventListener('click', async () => {
        const card = button.closest('[data-row-id]');
        const id = Number(card.dataset.rowId);
        if (!confirm('Delete this record? This cannot be undone.')) return;

        button.disabled = true;
        const { error } = await client.from(table).delete().eq('id', id);
        if (error) {
          cms.setStatus(error.message, 'error');
          button.disabled = false;
        } else {
          cms.setStatus('Record deleted.', 'success');
          await loadRows();
        }
      });
    });
  }

  form.addEventListener('submit', async (event) => {
    event.preventDefault();
    const submit = form.querySelector('button[type="submit"]');
    submit.disabled = true;
    cms.setStatus('Saving…');

    const payload = cms.formToObject(form);
    if (leagueFilter && Object.prototype.hasOwnProperty.call(payload, 'league')) {
      payload.league = leagueFilter;
    }
    const id = payload.id ? Number(payload.id) : null;
    delete payload.id;

    if (table === 'articles' && !payload.slug && payload.title) payload.slug = cms.slugify(payload.title);
    payload.updated_at = new Date().toISOString();

    const query = id
      ? client.from(table).update(payload).eq('id', id)
      : client.from(table).insert(payload);

    const { error } = await query;
    submit.disabled = false;

    if (error) {
      cms.setStatus(error.message, 'error');
      return;
    }

    cms.setStatus(id ? 'Changes saved.' : 'Record created.', 'success');
    cms.resetForm(form);
    await loadRows();
  });

  refresh?.addEventListener('click', loadRows);
  newButton?.addEventListener('click', () => {
    cms.resetForm(form);
    if (leagueFilter && leagueField) leagueField.value = leagueFilter;
    form.scrollIntoView({ behavior: 'smooth', block: 'start' });
  });

  await loadRows();
})();
