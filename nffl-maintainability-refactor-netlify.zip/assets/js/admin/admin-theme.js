
(function setupAdminTheme() {
  const storageKey = 'nffl-admin-theme';

  function apply(theme) {
    const dark = theme !== 'light';
    document.body.classList.toggle('admin-light-mode', !dark);
    document.body.classList.toggle('admin-dark-mode', dark);
    document.body.classList.toggle('dark-mode', dark);
    document.documentElement.dataset.adminTheme = dark ? 'dark' : 'light';
    document.documentElement.dataset.theme = dark ? 'dark' : 'light';

    document.querySelectorAll('[data-admin-theme-toggle]').forEach((button) => {
      button.setAttribute('aria-pressed', String(dark));
      const icon = button.querySelector('[data-admin-theme-icon]');
      const label = button.querySelector('[data-admin-theme-label]');
      if (icon) icon.textContent = dark ? '☀' : '☾';
      if (label) label.textContent = dark ? 'Light' : 'Dark';
      button.setAttribute('title', dark ? 'Switch to light mode' : 'Switch to dark mode');
    });
  }

  const saved = localStorage.getItem(storageKey) || 'dark';
  apply(saved);

  document.addEventListener('click', (event) => {
    const button = event.target.closest('[data-admin-theme-toggle]');
    if (!button) return;
    const next = document.body.classList.contains('admin-dark-mode') ? 'light' : 'dark';
    localStorage.setItem(storageKey, next);
    apply(next);
  });
})();
