(function nfflAdminCore(){
  let dirty=false;
  const banner=document.createElement('div');
  banner.id='admin-system-banner'; banner.setAttribute('role','alert');
  const toastRoot=document.createElement('div'); toastRoot.id='admin-toast-root'; toastRoot.setAttribute('aria-live','polite');

  function mount(){
    document.body.prepend(banner); document.body.append(toastRoot);
    document.querySelectorAll('form').forEach(form=>{
      form.addEventListener('input',()=>setDirty(true));
      form.addEventListener('change',()=>setDirty(true));
      form.addEventListener('submit',()=>setTimeout(()=>setDirty(false),0));
    });
  }
  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',mount); else mount();

  function showError(message){
    banner.textContent=message; banner.className='is-visible';
  }
  function clearError(){banner.textContent='';banner.className='';}
  function toast(message,type='success'){
    const node=document.createElement('div'); node.className=`admin-toast ${type}`; node.textContent=message;
    toastRoot.append(node); setTimeout(()=>node.remove(),4200);
  }
  function setDirty(value){
    dirty=Boolean(value); document.body.classList.toggle('admin-has-unsaved-changes',dirty);
    document.querySelectorAll('[data-admin-unsaved]').forEach(node=>node.textContent=dirty?'Unsaved changes':'All changes saved');
  }
  function setBusy(target,busy,label='Saving…'){
    const root=target instanceof HTMLFormElement?target:target?.closest?.('form')||target;
    root?.querySelectorAll('button,input,textarea,select').forEach(node=>{
      if(node.type!=='hidden') node.disabled=Boolean(busy);
    });
    if(target instanceof HTMLButtonElement){
      if(busy){target.dataset.originalLabel=target.textContent;target.textContent=label;}
      else if(target.dataset.originalLabel){target.textContent=target.dataset.originalLabel;delete target.dataset.originalLabel;}
    }
  }
  async function probe(){
    const client=window.nfflSupabase;
    if(!client) throw new Error('Supabase client is unavailable.');
    const tables=['profiles','site_content','managed_items','season_vaults','team_content','articles','awards','hot_seat'];
    const results=[];
    for(const table of tables){
      const {error,count}=await client.from(table).select('*',{head:true,count:'exact'}).limit(1);
      results.push({table,ok:!error,count:count??null,error:error?.message||''});
    }
    return results;
  }
  window.addEventListener('error',event=>showError(`Admin error: ${event.message||'A script failed to load.'}`));
  window.addEventListener('unhandledrejection',event=>showError(`Admin request failed: ${event.reason?.message||event.reason||'Unknown error'}`));
  window.addEventListener('beforeunload',event=>{if(!dirty)return;event.preventDefault();event.returnValue='';});
  window.NFFLAdmin={showError,clearError,toast,setDirty,setBusy,probe};
})();
