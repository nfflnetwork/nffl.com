
(async function setupArticleStudio() {
  const client = window.nfflSupabase;
  const form = document.querySelector('#article-studio-form');
  const list = document.querySelector('#article-list');
  const search = document.querySelector('#article-search');
  const status = document.querySelector('#article-status');
  const title = document.querySelector('#article-editor-title');
  const preview = document.querySelector('#article-preview-link');
  const relatedRoot = document.querySelector('#related-story-fields');
  const placementRoot = document.querySelector('#article-placement-manager');
  const placementStatus = document.querySelector('#article-placement-status');

  if (!client || !form || !list) return;

  let rows = [];
  let selectedId = null;
  let placementRows = [];

  const esc = (value) => String(value ?? '')
    .replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;')
    .replaceAll('"','&quot;').replaceAll("'","&#039;");

  relatedRoot.innerHTML = [1,2,3].map((i) => `
    <fieldset class="related-story-fieldset">
      <legend>Related Story ${i}</legend>
      <div class="admin-form-grid">
        <label>Category<input name="related_${i}_category"></label>
        <label>Title<input name="related_${i}_title"></label>
      </div>
      <label>URL<input name="related_${i}_url"></label>
    </fieldset>
  `).join('');

  function setStatus(message, type='') {
    status.textContent = message;
    status.className = `admin-form-status ${type}`.trim();
  }

  function slugify(value) {
    return String(value || '').toLowerCase().trim().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '');
  }

  function renderList() {
    const q = search.value.trim().toLowerCase();
    const items = rows.filter((row) => `${row.title} ${row.category} ${row.status}`.toLowerCase().includes(q));
    list.innerHTML = items.length ? items.map((row) => `
      <button type="button" class="article-admin-card${selectedId === row.id ? ' active' : ''}" data-article-id="${row.id}">
        <span>${row.category || 'League News'}</span>
        <strong>${row.title}</strong>
        <small>${row.status}${row.featured ? ' • Featured' : ''}</small>
      </button>
    `).join('') : '<div class="rank-item"><h3>No articles found</h3></div>';

    list.querySelectorAll('[data-article-id]').forEach((button) => {
      button.addEventListener('click', () => {
        const row = rows.find((item) => Number(item.id) === Number(button.dataset.articleId));
        if (row) fill(row);
      });
    });
  }

  function clear() {
    selectedId = null;
    form.reset();
    form.author_name.value = 'NFFL Network Staff';
    title.textContent = 'New Article';
    preview.href = '../news.html';
    renderList();
  }

  function setRelated(items=[]) {
    [1,2,3].forEach((i) => {
      const item = items[i-1] || {};
      form[`related_${i}_category`].value = item.category || '';
      form[`related_${i}_title`].value = item.title || '';
      form[`related_${i}_url`].value = item.url || '';
    });
  }

  function fill(row) {
    selectedId = row.id;
    title.textContent = `Edit: ${row.title}`;
    Object.entries(row).forEach(([key,value]) => {
      const field = form.elements.namedItem(key);
      if (!field) return;
      if (field.type === 'checkbox') field.checked = Boolean(value);
      else if (key === 'published_at' && value) field.value = new Date(value).toISOString().slice(0,16);
      else if (key === 'tags' && Array.isArray(value)) field.value = value.join(', ');
      else field.value = value ?? '';
    });

    setRelated(row.related_links || []);
    form.previous_title.value = row.previous_link?.title || '';
    form.previous_url.value = row.previous_link?.url || '';
    form.next_title.value = row.next_link?.title || '';
    form.next_url.value = row.next_link?.url || '';
    preview.href = row.slug ? `../article.html?slug=${encodeURIComponent(row.slug)}` : '../news.html';
    renderList();
  }

  async function load() {
    const { data, error } = await client.from('articles').select('*').order('updated_at', { ascending:false });
    if (error) {
      setStatus(error.message, 'error');
      return;
    }
    rows = data || [];
    renderList();
  }

  document.querySelectorAll('[data-article-tab]').forEach((button) => {
    button.addEventListener('click', () => {
      const tab = button.dataset.articleTab;
      document.querySelectorAll('[data-article-tab]').forEach((b) => b.classList.toggle('active', b === button));
      document.querySelectorAll('[data-article-panel]').forEach((panel) => panel.hidden = panel.dataset.articlePanel !== tab);
    });
  });

  document.querySelector('#article-new').addEventListener('click', clear);
  search.addEventListener('input', renderList);

  form.addEventListener('submit', async (event) => {
    event.preventDefault();

    const related = [1,2,3].map((i) => ({
      category: form[`related_${i}_category`].value.trim(),
      title: form[`related_${i}_title`].value.trim(),
      url: form[`related_${i}_url`].value.trim()
    })).filter((item) => item.title && item.url);

    const payload = {
      league: form.league.value,
      title: form.title.value.trim(),
      slug: form.slug.value.trim() || slugify(form.title.value),
      category: form.category.value.trim() || null,
      tags: form.tags.value.split(',').map((tag) => tag.trim()).filter(Boolean),
      subtitle: form.subtitle.value.trim() || null,
      summary: form.summary.value.trim() || null,
      body: form.body.value.trim() || null,
      image_url: form.image_url.value.trim() || null,
      author_name: form.author_name.value.trim() || 'NFFL Network Staff',
      reading_time: form.reading_time.value.trim() || null,
      pull_quote: form.pull_quote.value.trim() || null,
      pull_quote_attribution: form.pull_quote_attribution.value.trim() || null,
      team_key: form.team_key.value.trim() || null,
      team_name: form.team_name.value.trim() || null,
      team_coach: form.team_coach.value.trim() || null,
      team_division: form.team_division.value.trim() || null,
      team_status: form.team_status.value.trim() || null,
      related_links: related,
      previous_link: form.previous_url.value.trim() ? { title: form.previous_title.value.trim(), url: form.previous_url.value.trim() } : null,
      next_link: form.next_url.value.trim() ? { title: form.next_title.value.trim(), url: form.next_url.value.trim() } : null,
      seo_description: form.seo_description.value.trim() || null,
      status: form.status.value,
      featured: form.featured.checked,
      show_on_homepage: form.show_on_homepage.checked,
      show_in_headlines: form.show_in_headlines.checked,
      pinned: form.pinned.checked,
      breaking: form.breaking.checked,
      published_at: form.published_at.value ? new Date(form.published_at.value).toISOString() : null,
      updated_at: new Date().toISOString()
    };

    setStatus('Saving…');
    const query = selectedId
      ? client.from('articles').update(payload).eq('id', selectedId).select().single()
      : client.from('articles').insert(payload).select().single();

    const { data, error } = await query;
    if (error) {
      setStatus(error.message, 'error');
      return;
    }

    const index = rows.findIndex((row) => row.id === data.id);
    if (index >= 0) rows[index] = data;
    else rows.unshift(data);

    fill(data);
    populatePlacementSelects();
    setStatus('Article saved.', 'success');
  });

  document.querySelector('#article-delete').addEventListener('click', async () => {
    if (!selectedId || !confirm('Delete this article?')) return;
    const { error } = await client.from('articles').delete().eq('id', selectedId);
    if (error) {
      setStatus(error.message, 'error');
      return;
    }
    rows = rows.filter((row) => row.id !== selectedId);
    clear();
    setStatus('Article deleted.', 'success');
  });


  function setPlacementStatus(message, type='') {
    if (!placementStatus) return;
    placementStatus.textContent = message;
    placementStatus.className = `admin-form-status ${type}`.trim();
  }

  function articleOptionLabel(article) {
    const category = article.category || 'League News';
    return `${article.title} — ${category}`;
  }

  function populatePlacementSelects() {
    if (!placementRoot) return;
    const published = rows
      .filter((row) => row.status === 'published')
      .sort((a,b) => String(a.title).localeCompare(String(b.title)));

    placementRoot.querySelectorAll('select[data-placement-key]').forEach((select) => {
      const key = select.dataset.placementKey;
      const position = Number(select.dataset.placementPosition);
      const current = placementRows.find((row) =>
        row.league === 'nffl' &&
        row.placement_key === key &&
        Number(row.position) === position
      );
      select.innerHTML = `<option value="">Automatic / none selected</option>` +
        published.map((article) =>
          `<option value="${article.id}" ${Number(current?.article_id) === Number(article.id) ? 'selected' : ''}>${esc(articleOptionLabel(article))}</option>`
        ).join('');
    });
  }

  async function loadPlacements() {
    if (!placementRoot) return;
    const { data, error } = await client
      .from('article_placements')
      .select('*')
      .eq('league','nffl')
      .order('placement_key')
      .order('position');
    if (error) {
      setPlacementStatus(error.message, 'error');
      return;
    }
    placementRows = data || [];
    populatePlacementSelects();
  }

  async function savePlacements() {
    if (!placementRoot) return;
    const payload = [...placementRoot.querySelectorAll('select[data-placement-key]')].map((select) => ({
      league: 'nffl',
      placement_key: select.dataset.placementKey,
      position: Number(select.dataset.placementPosition),
      article_id: Number(select.value) || null,
      updated_at: new Date().toISOString()
    }));

    setPlacementStatus('Saving article placements…');
    const { data, error } = await client
      .from('article_placements')
      .upsert(payload, { onConflict:'league,placement_key,position' })
      .select();

    if (error) {
      setPlacementStatus(error.message, 'error');
      return;
    }

    placementRows = data || payload;
    setPlacementStatus('Homepage, News, and ticker selections saved.', 'success');
  }

  document.querySelectorAll('[data-placement-tab]').forEach((button) => {
    button.addEventListener('click', () => {
      const tab = button.dataset.placementTab;
      document.querySelectorAll('[data-placement-tab]').forEach((item) => item.classList.toggle('active', item === button));
      document.querySelectorAll('[data-placement-panel]').forEach((panel) => {
        panel.hidden = panel.dataset.placementPanel !== tab;
      });
    });
  });

  document.querySelector('#save-article-placements')?.addEventListener('click', () => {
    savePlacements().catch((error) => setPlacementStatus(error.message, 'error'));
  });


  async function loadNewsroomSettings() {
    const keys = [
      'newsroom.note',
      'newsroom.note.author',
      'newsroom.status.season',
      'newsroom.status.week',
      'newsroom.status.trade',
      'newsroom.status.waivers',
      'newsroom.status.next',
      'newsroom.status.health'
    ];

    const { data, error } = await client
      .from('site_content')
      .select('content_key,title,body')
      .in('content_key', keys);

    if (error) {
      const node = document.querySelector('#newsroom-settings-status');
      if (node) {
        node.textContent = error.message;
        node.className = 'admin-form-status error';
      }
      return;
    }

    const map = Object.fromEntries((data || []).map((row) => [row.content_key,row]));
    const values = {
      '#newsroom-note-title': map['newsroom.note']?.title,
      '#newsroom-note-body': map['newsroom.note']?.body,
      '#newsroom-note-author': map['newsroom.note.author']?.body,
      '#newsroom-status-season': map['newsroom.status.season']?.body,
      '#newsroom-status-week': map['newsroom.status.week']?.body,
      '#newsroom-status-trade': map['newsroom.status.trade']?.body,
      '#newsroom-status-waivers': map['newsroom.status.waivers']?.body,
      '#newsroom-status-next': map['newsroom.status.next']?.body,
      '#newsroom-status-health': map['newsroom.status.health']?.body
    };

    Object.entries(values).forEach(([selector,value]) => {
      const field = document.querySelector(selector);
      if (field && value) field.value = value;
    });
  }

  async function saveNewsroomSettings() {
    const statusNode = document.querySelector('#newsroom-settings-status');
    const payload = [
      {
        content_key:'newsroom.note',
        title:document.querySelector('#newsroom-note-title')?.value.trim() || 'Inside the NFFL Newsroom',
        body:document.querySelector('#newsroom-note-body')?.value.trim() || '',
        updated_at:new Date().toISOString()
      },
      {
        content_key:'newsroom.note.author',
        title:'Editor Byline',
        body:document.querySelector('#newsroom-note-author')?.value.trim() || 'NFFL Network Staff',
        updated_at:new Date().toISOString()
      },
      {
        content_key:'newsroom.status.season',
        title:'Season',
        body:document.querySelector('#newsroom-status-season')?.value.trim() || '',
        updated_at:new Date().toISOString()
      },
      {
        content_key:'newsroom.status.week',
        title:'Current Week',
        body:document.querySelector('#newsroom-status-week')?.value.trim() || '',
        updated_at:new Date().toISOString()
      },
      {
        content_key:'newsroom.status.trade',
        title:'Trade Window',
        body:document.querySelector('#newsroom-status-trade')?.value || '',
        updated_at:new Date().toISOString()
      },
      {
        content_key:'newsroom.status.waivers',
        title:'Waivers',
        body:document.querySelector('#newsroom-status-waivers')?.value || '',
        updated_at:new Date().toISOString()
      },
      {
        content_key:'newsroom.status.next',
        title:'Next Event',
        body:document.querySelector('#newsroom-status-next')?.value.trim() || '',
        updated_at:new Date().toISOString()
      },
      {
        content_key:'newsroom.status.health',
        title:'League Health',
        body:document.querySelector('#newsroom-status-health')?.value || 'Operational',
        updated_at:new Date().toISOString()
      }
    ];

    if (statusNode) {
      statusNode.textContent = 'Saving newsroom settings…';
      statusNode.className = 'admin-form-status';
    }

    const { error } = await client
      .from('site_content')
      .upsert(payload, { onConflict:'content_key' });

    if (statusNode) {
      statusNode.textContent = error ? error.message : 'Newsroom settings saved.';
      statusNode.className = `admin-form-status ${error ? 'error' : 'success'}`;
    }
  }

  document.querySelector('#save-newsroom-settings')?.addEventListener('click', () => {
    saveNewsroomSettings().catch((error) => {
      const statusNode = document.querySelector('#newsroom-settings-status');
      if (statusNode) {
        statusNode.textContent = error.message;
        statusNode.className = 'admin-form-status error';
      }
    });
  });

  clear();
  await load();
  await loadPlacements();
  await loadNewsroomSettings();
})();

