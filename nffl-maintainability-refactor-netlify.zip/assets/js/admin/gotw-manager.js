
(async function setupStaticGotwManager() {
  const client = window.nfflSupabase;
  const leagueField = document.querySelector('#gotw-league');
  const weekField = document.querySelector('#gotw-week');
  const matchupField = document.querySelector('#gotw-matchup');
  const autoField = document.querySelector('#gotw-auto');
  const headlineField = document.querySelector('#gotw-headline');
  const subheadlineField = document.querySelector('#gotw-subheadline');
  const imageField = document.querySelector('#gotw-image');
  const preview = document.querySelector('#gotw-admin-preview');
  const status = document.querySelector('#gotw-status');
  const saveButton = document.querySelector('#save-gotw');

  if (!client || !leagueField || !weekField || !matchupField) return;

  let staticSchedule = {};

  function setStatus(message,type='') {
    status.textContent = message;
    status.className = `admin-form-status ${type}`.trim();
  }

  function contentKey() {
    return `${leagueField.value}.schedule.gotw.week${weekField.value}`;
  }

  async function loadStaticSchedule() {
    try {
      const response = await fetch('../schedule.html');
      const html = await response.text();
      const doc = new DOMParser().parseFromString(html,'text/html');

      staticSchedule = {};
      doc.querySelectorAll('[data-schedule-week-panel]').forEach((panel) => {
        const week = Number(panel.dataset.scheduleWeekPanel);
        staticSchedule[week] = [...panel.querySelectorAll('.matchup')].map((matchup,index) => {
          const teams = matchup.querySelectorAll('.schedule-team');
          return {
            id:index + 1,
            away:teams[0]?.textContent.trim() || matchup.children[0]?.textContent.trim() || 'Away',
            home:teams[1]?.textContent.trim() || matchup.children[2]?.textContent.trim() || 'Home'
          };
        });
      });
    } catch (error) {
      console.warn('Could not parse static schedule:',error.message);
    }
  }

  function renderPreview() {
    const rows = staticSchedule[Number(weekField.value)] || [];
    const selected = rows.find((row)=>String(row.id)===String(matchupField.value));
    if (!selected) {
      preview.innerHTML = '<span>Preview</span><strong>No matchup selected.</strong>';
      return;
    }

    preview.innerHTML = `
      <span>Week ${weekField.value}</span>
      <strong>${selected.away} vs ${selected.home}</strong>
      <p>${headlineField.value.trim() || 'Game of the Week'}${subheadlineField.value.trim() ? ` — ${subheadlineField.value.trim()}` : ''}</p>`;
  }

  function populateMatchups() {
    const rows = staticSchedule[Number(weekField.value)] || [];
    matchupField.innerHTML = '<option value="">Choose a matchup…</option>' +
      rows.map((row)=>`<option value="${row.id}">${row.away} vs ${row.home}</option>`).join('');
  }

  async function loadSaved() {
    const { data, error } = await client
      .from('site_content')
      .select('content_key,title,body,image_url,metadata')
      .eq('content_key',contentKey())
      .maybeSingle();

    if (error) {
      setStatus(error.message,'error');
      return;
    }

    const meta = data?.metadata || {};
    matchupField.value = meta.matchup_id ?? '';
    autoField.checked = Boolean(meta.auto);
    headlineField.value = data?.title || '';
    subheadlineField.value = data?.body || '';
    imageField.value = data?.image_url || meta.image_url || '';
    renderPreview();
  }

  async function refreshWeek() {
    populateMatchups();
    await loadSaved();
    setStatus(`Week ${weekField.value} static matchups loaded.`,'success');
  }

  async function save() {
    const rows = staticSchedule[Number(weekField.value)] || [];
    const selected = rows.find((row)=>String(row.id)===String(matchupField.value));

    const payload = {
      content_key:contentKey(),
      league:leagueField.value,
      title:headlineField.value.trim() || 'Game of the Week',
      body:subheadlineField.value.trim() || '',
      image_url:imageField.value.trim() || null,
      metadata:{
        league:leagueField.value,
        week:Number(weekField.value),
        matchup_id:selected?.id ?? null,
        away_name:selected?.away ?? null,
        home_name:selected?.home ?? null,
        auto:false
      },
      updated_at:new Date().toISOString()
    };

    setStatus('Saving Game of the Week…');

    const { error } = await client
      .from('site_content')
      .upsert(payload,{onConflict:'content_key'});

    if (error) setStatus(error.message,'error');
    else setStatus('Game of the Week saved for the Schedule page only.','success');
  }

  leagueField.addEventListener('change',refreshWeek);
  weekField.addEventListener('change',refreshWeek);
  matchupField.addEventListener('change',renderPreview);
  headlineField.addEventListener('input',renderPreview);
  subheadlineField.addEventListener('input',renderPreview);
  saveButton.addEventListener('click',()=>save().catch((error)=>setStatus(error.message,'error')));

  await loadStaticSchedule();
  await refreshWeek();
})();
