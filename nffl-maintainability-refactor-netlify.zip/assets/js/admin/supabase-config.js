// Public browser configuration. Safe to expose when RLS is enabled.
// Shared connection values are defined once in assets/js/config.js.

if (!window.supabase?.createClient) {
  console.error("Supabase library did not load.");
} else {
  window.nfflSupabase = window.supabase.createClient(
    window.NFFL_SUPABASE_URL,
    window.NFFL_SUPABASE_PUBLISHABLE_KEY,
    {
      auth: {
        persistSession: true,
        autoRefreshToken: true,
        detectSessionInUrl: true
      }
    }
  );
}
