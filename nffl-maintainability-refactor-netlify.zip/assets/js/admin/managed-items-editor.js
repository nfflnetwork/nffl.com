
(async function setupManagedItemsEditor() {
  const client = window.nfflSupabase;
  const form = document.querySelector('[data-managed-form]');
  const list = document.querySelector('[data-managed-list]');
  const status = document.querySelector('[data-managed-status]');
  const body = document.body;

  if (!client || !form || !list) return;

  const params = new URLSearchParams(location.search);
  const contentType = body.dataset.contentType;
  const leagueFilter = params.get('league') || body.dataset.defaultLeague || 'nffl';

  const leagueField = form.elements.namedItem('league');
  if (leagueField) leagueField.value = leagueFilter;


  function normalizeScheduleNames(value) {
    if (contentType !== 'schedule_game') return value;
    return String(value || '')
      .replaceAll('royaltyharris','allyotarola')
      .replaceAll('jkawski87','damianhartfield')
      .replaceAll('KURSED','DJSP')
      .replaceAll('CrimsonChin1','Knightmare005');
  }

  function setStatus(message, type = '') {
    status.textContent = message;
    status.className = `admin-form-status ${type}`.trim();
  }

  async function loadRows() {
    setStatus('Loading…');
    let query = client.from('managed_items')
      .select('*')
      .eq('content_type', contentType)
      .eq('league', leagueFilter)
      .order('week', { ascending: true, nullsFirst: true })
      .order('rank', { ascending: true, nullsFirst: true })
      .order('updated_at', { ascending: false });

    const { data, error } = await query;
    if (error) {
      setStatus(error.message, 'error');
      list.innerHTML = `<div class="rank-item"><h3>Unable to load records</h3><p>${error.message}</p></div>`;
      return;
    }

    setStatus(`${data.length} record${data.length === 1 ? '' : 's'} loaded.`, 'success');
    list.innerHTML = data.length ? data.map((row) => `
      <article class="admin-record-card" data-row-id="${row.id}">
        <div>
          <h3>${row.rank ? `${row.rank}. ` : ''}${normalizeScheduleNames(row.title || row.item_key || 'Untitled')}</h3>
          <p>${[
            row.week ? `Week ${row.week}` : '',
            row.subtitle || '',
            row.is_active ? 'Active' : 'Hidden'
          ].filter(Boolean).join(' • ')}</p>
        </div>
        <div class="admin-record-actions">
          <button type="button" data-edit>Edit</button>
          <button type="button" class="danger" data-delete>Delete</button>
        </div>
      </article>
    `).join('') : '<div class="rank-item"><h3>No records yet</h3><p>Use Import Existing or create the first entry.</p></div>';

    list.querySelectorAll('[data-edit]').forEach((button) => {
      button.addEventListener('click', () => {
        const id = Number(button.closest('[data-row-id]').dataset.rowId);
        const row = data.find((item) => Number(item.id) === id);
        Object.entries(row).forEach(([key, value]) => {
          const field = form.elements.namedItem(key);
          if (!field) return;
          if (field.type === 'checkbox') field.checked = Boolean(value);
          else if (key === 'metadata') field.value = JSON.stringify(value || {}, null, 2);
          else field.value = ['title','body'].includes(key) ? normalizeScheduleNames(value ?? '') : value ?? '';
        });
        form.scrollIntoView({ behavior: 'smooth', block: 'start' });
      });
    });

    list.querySelectorAll('[data-delete]').forEach((button) => {
      button.addEventListener('click', async () => {
        const id = Number(button.closest('[data-row-id]').dataset.rowId);
        if (!confirm('Delete this item?')) return;
        const { error } = await client.from('managed_items').delete().eq('id', id);
        if (error) setStatus(error.message, 'error');
        else await loadRows();
      });
    });
  }

  form.addEventListener('submit', async (event) => {
    event.preventDefault();
    const fd = new FormData(form);
    const payload = Object.fromEntries(fd.entries());
    const id = payload.id ? Number(payload.id) : null;
    delete payload.id;

    if (contentType === 'schedule_game') {
      payload.title = normalizeScheduleNames(payload.title);
      payload.body = normalizeScheduleNames(payload.body);
    }

    payload.content_type = contentType;
    payload.league = leagueFilter;
    payload.week = payload.week ? Number(payload.week) : null;
    payload.rank = payload.rank ? Number(payload.rank) : null;
    payload.season = payload.season ? Number(payload.season) : null;
    payload.is_active = form.elements.namedItem('is_active')?.checked ?? true;
    payload.updated_at = new Date().toISOString();

    try {
      payload.metadata = payload.metadata ? JSON.parse(payload.metadata) : {};
    } catch {
      setStatus('Metadata must be valid JSON.', 'error');
      return;
    }

    const query = id
      ? client.from('managed_items').update(payload).eq('id', id)
      : client.from('managed_items').insert(payload);

    const { error } = await query;
    if (error) {
      setStatus(error.message, 'error');
      return;
    }

    form.reset();
    if (leagueField) leagueField.value = leagueFilter;
    setStatus('Saved.', 'success');
    await loadRows();
  });

  document.querySelector('[data-managed-new]')?.addEventListener('click', () => {
    form.reset();
    if (leagueField) leagueField.value = leagueFilter;
  });

  await loadRows();
})();
