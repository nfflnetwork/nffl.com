
(async function setupHistoryManager() {
  const client = window.nfflSupabase;
  const pageForm = document.querySelector('#history-page-form');
  const itemForm = document.querySelector('#history-item-form');
  const seasonForm = document.querySelector('#season-vault-form');
  const itemModal = document.querySelector('#history-item-modal');
  const seasonModal = document.querySelector('#season-vault-modal');
  if (!client || !pageForm || !itemForm || !seasonForm || !itemModal || !seasonModal) return;

  const pageStatus = document.querySelector('#history-page-status');
  const itemStatus = document.querySelector('#history-item-status');
  const seasonStatus = document.querySelector('#season-vault-status');
  const itemDelete = document.querySelector('#delete-history-item');
  const seasonDelete = document.querySelector('#delete-season-vault');
  const championshipExtras = document.querySelector('#championship-extra-fields');

  const pageDefaults = {
    hero_title:'NFFL History',
    hero_body:'The official record of the National Fantasy Football League — champions, legendary teams, major trades, draft classes, records, and the moments that shaped the league.',
    founded:'2025',
    teams:'12',
    current_season:'2026',
    archive_status:'Building',
    featured_title:'NFFL Network Era Begins',
    featured_body:'The launch of NFFL Network turned the league into a full media ecosystem with team pages, live data, G-League coverage, draft history, and a transaction wire.',
    featured_link:'article-nffl-network-live.html'
  };


  let historyItems = [];
  let seasonVaults = [];

  const esc = (value) => String(value ?? '')
    .replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;')
    .replaceAll('"','&quot;').replaceAll("'","&#039;");

  function setStatus(node,message,type='') {
    if (!node) return;
    node.textContent = message;
    node.className = `admin-form-status ${type}`.trim();
  }

  function slug(value) {
    return String(value || '').toLowerCase().trim()
      .replace(/[^a-z0-9]+/g,'-').replace(/^-+|-+$/g,'').slice(0,60) || 'item';
  }

  function setFormBusy(form,busy) {
    form?.querySelectorAll('button,input,textarea,select').forEach((node)=>{
      if (node.type !== 'hidden') node.disabled = Boolean(busy);
    });
  }

  async function assertWrite(result,label) {
    if (result.error) throw result.error;
    if (Array.isArray(result.data) && result.data.length === 0) {
      throw new Error(`${label} did not return a saved row. Check Supabase RLS policies.`);
    }
    return result.data;
  }

  function setTab(name) {
    document.querySelectorAll('[data-history-admin-tab]').forEach((button)=>{
      button.classList.toggle('active',button.dataset.historyAdminTab===name);
    });
    document.querySelectorAll('[data-history-admin-panel]').forEach((panel)=>{
      panel.hidden = panel.dataset.historyAdminPanel !== name;
    });
  }

  document.querySelectorAll('[data-history-admin-tab]').forEach((button)=>{
    button.addEventListener('click',()=>setTab(button.dataset.historyAdminTab));
  });

  document.querySelector('#refresh-history-preview')?.addEventListener('click',()=>{
    const frame = document.querySelector('#history-live-preview');
    if (frame) frame.src = `../history.html?preview=${Date.now()}`;
  });

  async function loadPageContent() {
    const keys = Object.keys(pageDefaults).map((key)=>`history.${key}`);
    const {data,error} = await client.from('site_content')
      .select('content_key,title,body')
      .in('content_key',keys);

    if (error) {
      setStatus(pageStatus,error.message,'error');
      return;
    }

    const map = Object.fromEntries((data || []).map((row)=>[row.content_key,row]));
    Object.entries(pageDefaults).forEach(([key,fallback])=>{
      const field = pageForm.elements.namedItem(key);
      if (field) field.value = map[`history.${key}`]?.body || map[`history.${key}`]?.title || fallback;
    });
    setStatus(pageStatus,'History page content loaded.','success');
  }

  pageForm.addEventListener('submit',async(event)=>{
    event.preventDefault();
    const rows = [];
    new FormData(pageForm).forEach((value,key)=>{
      rows.push({
        content_key:`history.${key}`,
        league:'nffl',
        title:key,
        body:String(value).trim(),
        updated_at:new Date().toISOString()
      });
    });

    setStatus(pageStatus,'Saving…');
    setFormBusy(pageForm,true);
    try {
      const result = await client.from('site_content').upsert(rows,{onConflict:'content_key'}).select('content_key');
      await assertWrite(result,'Page content save');
      setStatus(pageStatus,'History page saved and verified.','success');
    } catch (error) {
      setStatus(pageStatus,error.message || 'Page save failed.','error');
    } finally {
      setFormBusy(pageForm,false);
    }
  });

  function kindLabel(kind) {
    return kind === 'championship' ? 'Champion' : 'Timeline Event';
  }

  function renderHistoryLists() {
    ['championship','timeline'].forEach((kind)=>{
      const root = document.querySelector(`[data-history-manager-list="${kind}"]`);
      const rows = historyItems
        .filter((row)=>row.metadata?.kind===kind)
        .sort((a,b)=>(a.rank||999)-(b.rank||999));

      root.innerHTML = rows.length ? rows.map((row,index)=>`
        <article class="history-manager-card" data-history-item-id="${row.id}">
          <div class="history-manager-order">
            <button type="button" data-move-history="-1" ${index===0?'disabled':''}>↑</button>
            <strong>${row.rank || index+1}</strong>
            <button type="button" data-move-history="1" ${index===rows.length-1?'disabled':''}>↓</button>
          </div>
          <div class="history-manager-copy">
            <span>${esc(row.subtitle || row.season || kindLabel(kind))}</span>
            <strong>${esc(row.title || 'Untitled')}</strong>
            <p>${esc(row.body || 'No description')}</p>
            ${kind === 'championship' ? `<small>Runner-Up: ${esc(row.metadata?.runner_up || 'Not entered')} • Record: ${esc(row.metadata?.best_record || 'Not entered')} • Final: ${esc(row.metadata?.final_score || 'Not entered')}</small>` : ''}
          </div>
          <button class="button" type="button" data-edit-history>Edit</button>
        </article>`).join('') :
        `<div class="history-manager-empty"><strong>No ${kindLabel(kind).toLowerCase()} entries yet.</strong><p>Add the first one above.</p></div>`;
    });

    document.querySelectorAll('[data-edit-history]').forEach((button)=>{
      button.addEventListener('click',()=>{
        const id = Number(button.closest('[data-history-item-id]').dataset.historyItemId);
        const row = historyItems.find((item)=>Number(item.id)===id);
        openHistoryModal(row?.metadata?.kind,row);
      });
    });

    document.querySelectorAll('[data-move-history]').forEach((button)=>{
      button.addEventListener('click',async()=>{
        const id = Number(button.closest('[data-history-item-id]').dataset.historyItemId);
        const direction = Number(button.dataset.moveHistory);
        const row = historyItems.find((item)=>Number(item.id)===id);
        const siblings = historyItems
          .filter((item)=>item.metadata?.kind===row.metadata?.kind)
          .sort((a,b)=>(a.rank||999)-(b.rank||999));
        const index = siblings.findIndex((item)=>Number(item.id)===id);
        const target = siblings[index + direction];
        if (!target) return;

        const a = row.rank || index+1;
        const b = target.rank || index+1+direction;
        setStatus(itemStatus,'Reordering…');
        try {
          const results = await Promise.all([
            client.from('managed_items').update({rank:b,updated_at:new Date().toISOString()}).eq('id',row.id).select('id,rank'),
            client.from('managed_items').update({rank:a,updated_at:new Date().toISOString()}).eq('id',target.id).select('id,rank')
          ]);
          results.forEach((result)=>{
            if (result.error) throw result.error;
            if (!result.data?.length) throw new Error('Reorder was blocked. Check Supabase RLS policies.');
          });
          await loadHistoryItems();
          setStatus(itemStatus,'Order saved and verified.','success');
        } catch (error) {
          setStatus(itemStatus,error.message || 'Reorder failed.','error');
        }
      });
    });
  }

  async function loadHistoryItems() {
    const {data,error} = await client.from('managed_items')
      .select('*')
      .eq('league','nffl')
      .eq('content_type','history_item')
      .order('rank',{ascending:true});

    if (error) {
      setStatus(itemStatus,error.message,'error');
      return;
    }
    historyItems = data || [];
    renderHistoryLists();
    setStatus(itemStatus,`${historyItems.length} history item${historyItems.length===1?'':'s'} loaded.`,'success');
  }

  function openHistoryModal(kind,row=null) {
    itemForm.reset();
    itemForm.elements.id.value = row?.id || '';
    itemForm.elements.kind.value = kind;
    itemForm.elements.rank.value = row?.rank || historyItems.filter((item)=>item.metadata?.kind===kind).length + 1;
    itemForm.elements.subtitle.value = row?.subtitle || row?.season || '';
    itemForm.elements.title.value = row?.title || '';
    itemForm.elements.body.value = row?.body || '';
    itemForm.elements.runner_up.value = row?.metadata?.runner_up || '';
    itemForm.elements.best_record.value = row?.metadata?.best_record || '';
    itemForm.elements.final_score.value = row?.metadata?.final_score || '';
    itemForm.elements.is_active.checked = row?.is_active !== false;
    championshipExtras.hidden = kind !== 'championship';
    itemDelete.hidden = !row;
    document.querySelector('#history-item-form-title').textContent = `${row ? 'Edit' : 'Add'} ${kindLabel(kind)}`;
    itemModal.hidden = false;
    document.body.classList.add('history-modal-open');
  }

  document.querySelectorAll('[data-new-history-item]').forEach((button)=>{
    button.addEventListener('click',()=>openHistoryModal(button.dataset.newHistoryItem));
  });

  document.querySelectorAll('[data-close-history-modal]').forEach((button)=>{
    button.addEventListener('click',()=>{
      itemModal.hidden = true;
      document.body.classList.remove('history-modal-open');
    });
  });

  itemForm.addEventListener('submit',async(event)=>{
    event.preventDefault();
    const fd = new FormData(itemForm);
    const id = Number(fd.get('id')) || null;
    const kind = String(fd.get('kind') || 'timeline');
    const subtitle = String(fd.get('subtitle') || '').trim();
    const title = String(fd.get('title') || '').trim();
    if (!title) {
      setStatus(itemStatus,'Add a title.','error');
      return;
    }

    const normalizedTitle = title.toLowerCase();
    const normalizedSubtitle = subtitle.toLowerCase();
    const duplicate = historyItems.find((row)=>
      Number(row.id) !== Number(id) &&
      String(row.metadata?.kind || '').toLowerCase() === kind.toLowerCase() &&
      String(row.title || '').trim().toLowerCase() === normalizedTitle &&
      String(row.subtitle || '').trim().toLowerCase() === normalizedSubtitle
    );
    if (duplicate) {
      setStatus(itemStatus,'That history entry already exists. Edit the existing entry instead.','error');
      return;
    }

    const payload = {
      content_type:'history_item',
      league:'nffl',
      season:Number(subtitle) || null,
      rank:Number(fd.get('rank')) || 1,
      item_key:id ? historyItems.find((row)=>Number(row.id)===id)?.item_key : `history-${kind}-${slug(subtitle)}-${slug(title)}`,
      title,
      subtitle,
      body:String(fd.get('body') || '').trim(),
      metadata:kind === 'championship' ? {
        kind,
        runner_up:String(fd.get('runner_up') || '').trim(),
        best_record:String(fd.get('best_record') || '').trim(),
        final_score:String(fd.get('final_score') || '').trim()
      } : {kind},
      is_active:itemForm.elements.is_active.checked,
      updated_at:new Date().toISOString()
    };

    setFormBusy(itemForm,true);
    setStatus(itemStatus,'Saving…');
    try {
      const query = id
        ? client.from('managed_items').update(payload).eq('id',id).select('*')
        : client.from('managed_items').insert(payload).select('*');
      await assertWrite(await query,'History save');
      itemModal.hidden = true;
      document.body.classList.remove('history-modal-open');
      await loadHistoryItems();
      setStatus(itemStatus,'History entry saved and verified.','success');
    } catch (error) {
      setStatus(itemStatus,error.message || 'History save failed.','error');
    } finally {
      setFormBusy(itemForm,false);
    }
  });

  itemDelete.addEventListener('click',async()=>{
    const id = Number(itemForm.elements.id.value);
    if (!id || !confirm('Delete this history item?')) return;
    const {error} = await client.from('managed_items').delete().eq('id',id);
    if (error) setStatus(itemStatus,error.message,'error');
    else {
      itemModal.hidden = true;
      document.body.classList.remove('history-modal-open');
      await loadHistoryItems();
    }
  });

  function renderSeasonVaults() {
    const root = document.querySelector('#season-vault-admin-list');
    root.innerHTML = seasonVaults.length ? seasonVaults.map((row)=>`
      <article class="history-manager-card" data-season-vault-id="${row.id}">
        <div class="history-manager-copy">
          <span>${esc(row.season)}</span>
          <strong>${esc(row.champion || 'Champion TBD')}</strong>
          <p>Runner-Up: ${esc(row.runner_up || 'TBD')} • Best Record: ${esc(row.best_record_team || 'TBD')} ${row.best_record ? `(${esc(row.best_record)})` : ''}</p>
          <small>${row.published ? 'Published' : 'Hidden'}</small>
        </div>
        <button class="button" type="button" data-edit-season-vault>Edit</button>
      </article>`).join('') :
      '<div class="history-manager-empty"><strong>No season vaults yet.</strong><p>Add the first season above.</p></div>';

    document.querySelectorAll('[data-edit-season-vault]').forEach((button)=>{
      button.addEventListener('click',()=>{
        const id = Number(button.closest('[data-season-vault-id]').dataset.seasonVaultId);
        const row = seasonVaults.find((item)=>Number(item.id)===id);
        openSeasonModal(row);
      });
    });
  }

  async function loadSeasonVaults() {
    const {data,error} = await client.from('season_vaults')
      .select('*')
      .eq('league','nffl')
      .order('season',{ascending:false});

    if (error) {
      setStatus(seasonStatus,error.message,'error');
      return;
    }
    seasonVaults = data || [];
    renderSeasonVaults();
    setStatus(seasonStatus,`${seasonVaults.length} season vault${seasonVaults.length===1?'':'s'} loaded.`,'success');
  }

  function openSeasonModal(row=null) {
    seasonForm.reset();
    seasonForm.elements.id.value = row?.id || '';
    seasonForm.elements.season.value = row?.season || '';
    seasonForm.elements.champion.value = row?.champion || '';
    seasonForm.elements.runner_up.value = row?.runner_up || '';
    seasonForm.elements.best_record_team.value = row?.best_record_team || '';
    seasonForm.elements.best_record.value = row?.best_record || '';
    seasonForm.elements.season_summary.value = row?.season_summary || '';
    seasonForm.elements.published.checked = row?.published !== false;
    seasonDelete.hidden = !row;
    seasonModal.hidden = false;
    document.body.classList.add('history-modal-open');
  }

  document.querySelector('#new-season-vault')?.addEventListener('click',()=>openSeasonModal());

  document.querySelectorAll('[data-close-season-modal]').forEach((button)=>{
    button.addEventListener('click',()=>{
      seasonModal.hidden = true;
      document.body.classList.remove('history-modal-open');
    });
  });

  seasonForm.addEventListener('submit',async(event)=>{
    event.preventDefault();
    const fd = new FormData(seasonForm);
    const id = Number(fd.get('id')) || null;
    const season = Number(fd.get('season'));
    if (!Number.isInteger(season) || season < 2000 || season > 2200) {
      setStatus(seasonStatus,'Enter a valid four-digit season.','error');
      return;
    }
    const duplicate = seasonVaults.find((row)=>Number(row.season)===season && Number(row.id)!==Number(id));
    if (duplicate) {
      setStatus(seasonStatus,'That season already exists. Edit its current card instead.','error');
      return;
    }
    const payload = {
      league:'nffl', season,
      champion:String(fd.get('champion') || '').trim(),
      runner_up:String(fd.get('runner_up') || '').trim(),
      best_record_team:String(fd.get('best_record_team') || '').trim(),
      best_record:String(fd.get('best_record') || '').trim(),
      season_summary:String(fd.get('season_summary') || '').trim(),
      published:seasonForm.elements.published.checked,
      updated_at:new Date().toISOString()
    };

    setFormBusy(seasonForm,true);
    setStatus(seasonStatus,'Saving…');
    try {
      const query = id
        ? client.from('season_vaults').update(payload).eq('id',id).select('*')
        : client.from('season_vaults').insert(payload).select('*');
      await assertWrite(await query,'Season save');
      seasonModal.hidden = true;
      document.body.classList.remove('history-modal-open');
      await loadSeasonVaults();
      setStatus(seasonStatus,'Season saved and verified.','success');
    } catch (error) {
      setStatus(seasonStatus,error.message || 'Season save failed.','error');
    } finally {
      setFormBusy(seasonForm,false);
    }
  });

  seasonDelete.addEventListener('click',async()=>{
    const id = Number(seasonForm.elements.id.value);
    if (!id || !confirm('Delete this season vault?')) return;
    const {error} = await client.from('season_vaults').delete().eq('id',id);
    if (error) setStatus(seasonStatus,error.message,'error');
    else {
      seasonModal.hidden = true;
      document.body.classList.remove('history-modal-open');
      await loadSeasonVaults();
    }
  });

  document.addEventListener('keydown',(event)=>{
    if (event.key !== 'Escape') return;
    itemModal.hidden = true;
    seasonModal.hidden = true;
    document.body.classList.remove('history-modal-open');
  });

  setTab('page');
  setStatus(itemStatus,'Loading history…');
  setStatus(seasonStatus,'Loading seasons…');
  await Promise.all([loadPageContent(),loadHistoryItems(),loadSeasonVaults()]);
})();
