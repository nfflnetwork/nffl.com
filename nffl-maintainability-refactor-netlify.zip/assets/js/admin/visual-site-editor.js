
(async function setupVisualSiteEditor() {
  const client = window.nfflSupabase;
  const pageSelect = document.querySelector('#visual-page-select');
  const frame = document.querySelector('#visual-site-frame');
  const frameShell = document.querySelector('#visual-frame-shell');
  const status = document.querySelector('#visual-editor-status');
  const pageStatus = document.querySelector('#visual-page-status');
  const unsavedCount = document.querySelector('#visual-unsaved-count');
  const inspectorForm = document.querySelector('#visual-inspector-form');
  const inspectorEmpty = document.querySelector('#visual-inspector-empty');
  const toggleMode = document.querySelector('#visual-toggle-mode');
  const publishButton = document.querySelector('#visual-save-all');
  const draftButton = document.querySelector('#visual-save-draft');
  const undoButton = document.querySelector('#visual-undo');
  const redoButton = document.querySelector('#visual-redo');
  const openLive = document.querySelector('#visual-open-live');
  const floatingBar = document.querySelector('#visual-floating-savebar');
  const floatingCount = document.querySelector('#visual-floating-count');
  const sectionList = document.querySelector('#visual-section-list');

  if (!client || !pageSelect || !frame) return;

  let inventory = null;
  let editMode = true;
  let selectedMessage = null;
  let frameReady = false;
  let lastHistoryTime = 0;
  let lastHistoryKey = null;
  let pageSections = [];

  const drafts = new Map();
  const baseValues = new Map();
  const undoStack = [];
  const redoStack = [];

  const typeIcons = { text: '✏️', link: '🔗', image: '🖼️' };

  function setStatus(message, type = '') {
    if (!status) return;
    status.textContent = message;
    status.className = `admin-form-status ${type}`.trim();
  }

  function identityKey(identity) {
    return JSON.stringify(identity);
  }

  function clone(value) {
    return JSON.parse(JSON.stringify(value || {}));
  }

  function valuesEqual(a, b) {
    return JSON.stringify(a || {}) === JSON.stringify(b || {});
  }

  function currentPagePath() {
    return frame.dataset.pagePath || pageSelect.value || '';
  }

  function localDraftKey(path = currentPagePath()) {
    return `nffl-visual-draft:${path}`;
  }

  function postToFrame(type, payload = {}) {
    if (!frame.contentWindow) return;
    frame.contentWindow.postMessage({
      source: 'nffl-admin-visual-editor',
      type,
      ...payload
    }, location.origin);
  }

  function updateControls() {
    const count = drafts.size;
    unsavedCount.textContent = `${count} unsaved change${count === 1 ? '' : 's'}`;
    unsavedCount.classList.toggle('has-changes', count > 0);
    publishButton.disabled = count === 0;
    draftButton.disabled = count === 0;
    undoButton.disabled = undoStack.length === 0;
    redoButton.disabled = redoStack.length === 0;

    if (floatingBar) {
      floatingBar.hidden = count === 0;
      floatingCount.textContent = `${count} unsaved change${count === 1 ? '' : 's'}`;
    }
  }


  function renderSections() {
    if (!sectionList) return;
    sectionList.innerHTML = pageSections.length ? pageSections.map((section,index) => `
      <article class="visual-section-row" data-section-key="${section.key}">
        <div><span>${index + 1}</span><strong>${section.label || section.key}</strong></div>
        <div>
          <button type="button" data-section-move="up" ${index === 0 ? 'disabled' : ''}>↑</button>
          <button type="button" data-section-move="down" ${index === pageSections.length - 1 ? 'disabled' : ''}>↓</button>
        </div>
      </article>
    `).join('') : '<p class="meta">No movable non-Sleeper sections were found.</p>';

    sectionList.querySelectorAll('[data-section-move]').forEach((button) => {
      button.addEventListener('click', () => {
        const row = button.closest('[data-section-key]');
        postToFrame('move-section', {
          section_key: row.dataset.sectionKey,
          direction: button.dataset.sectionMove
        });
      });
    });
  }

  async function saveSectionOrder() {
    const path = currentPagePath();
    if (!path || !pageSections.length) return;

    const rows = pageSections.map((section,index) => ({
      page_path: path,
      section_key: section.key,
      position: index + 1,
      updated_at: new Date().toISOString()
    }));

    const { error } = await client
      .from('page_section_order')
      .upsert(rows, { onConflict: 'page_path,section_key' });

    if (error) throw new Error(`Section order: ${error.message}`);
  }

  async function loadInventory() {
    if (inventory) return inventory;
    const response = await fetch('existing-content-data.json', { cache: 'no-store' });
    if (!response.ok) throw new Error('Could not load the website page list.');
    inventory = await response.json();
    return inventory;
  }

  function pageGroup(path) {
    if (path === 'index.html') return 'Main Homepage';
    if (path === 'g-league/index.html') return 'G-League Homepage';
    if (path.startsWith('g-league/')) return 'G-League Pages';
    if (path.startsWith('history/seasons/')) return 'Season Vault';
    if (path.startsWith('team-') || path.includes('/team-')) return 'Team Pages';
    if (path.startsWith('article-') || path === 'article.html') return 'Article Pages';
    return 'NFFL Pages';
  }

  function populatePages(data) {
    const groups = {};
    (data.page_catalog || []).forEach((page) => {
      const group = pageGroup(page.path);
      groups[group] ||= [];
      groups[group].push(page);
    });

    pageSelect.innerHTML = '<option value="">Choose a page…</option>' +
      Object.entries(groups).map(([group, pages]) => `
        <optgroup label="${group}">
          ${pages.sort((a,b) => a.title.localeCompare(b.title)).map((page) =>
            `<option value="${page.path}">${page.title} — ${page.path}</option>`
          ).join('')}
        </optgroup>
      `).join('');
  }

  function clearEditorState() {
    drafts.clear();
    baseValues.clear();
    undoStack.length = 0;
    redoStack.length = 0;
    selectedMessage = null;
    frameReady = false;
    pageSections = [];
    renderSections();
    inspectorForm.hidden = true;
    inspectorEmpty.hidden = false;
    updateControls();
  }

  function loadPage(path) {
    if (!path) return;
    if (drafts.size && !confirm('Discard unsaved preview changes and open another page?')) {
      pageSelect.value = currentPagePath();
      return;
    }

    clearEditorState();
    frame.dataset.pagePath = path;
    frame.src = `../${path}?admin_edit=1&visual_editor=${Date.now()}`;
    openLive.href = `../${path}`;
    pageStatus.textContent = `Loading ${path}…`;
  }

  function configureInspector(message) {
    selectedMessage = message;
    inspectorEmpty.hidden = true;
    inspectorForm.hidden = false;

    const identity = message.identity;
    const key = identityKey(identity);
    const value = drafts.get(key)?.value || message.value || {};
    const type = identity.element_type || 'text';

    if (!baseValues.has(key)) baseValues.set(key, clone(message.value));

    document.querySelector('#visual-element-icon').textContent = typeIcons[type] || '✏️';
    document.querySelector('#visual-section-label').textContent = message.label?.sectionLabel || 'Page content';
    document.querySelector('#visual-element-label').textContent = message.label?.preview || 'Selected element';
    document.querySelector('#visual-element-location').textContent =
      identity.storage === 'site_elements'
        ? `${identity.page_path} • ${identity.element_key}`
        : `${identity.content_key} • ${identity.field}`;

    inspectorForm.text_value.value = value.text_value ?? '';
    inspectorForm.href.value = value.href ?? '';
    inspectorForm.src.value = value.src ?? '';
    inspectorForm.alt_text.value = value.alt_text ?? '';
    inspectorForm.open_new_tab.checked = Boolean(value.open_new_tab);

    document.querySelector('#visual-text-field').hidden = type === 'image';
    document.querySelector('#visual-link-field').hidden = type !== 'link';
    document.querySelector('#visual-image-field').hidden = type !== 'image';
    document.querySelector('#visual-alt-field').hidden = type !== 'image';
    document.querySelector('#visual-new-tab-field').hidden = type !== 'link';

    setStatus('Editing directly on the website preview.');
  }

  function inspectorValue() {
    const type = selectedMessage?.identity?.element_type || 'text';
    if (type === 'image') {
      return {
        src: inspectorForm.src.value,
        alt_text: inspectorForm.alt_text.value
      };
    }
    if (type === 'link') {
      return {
        text_value: inspectorForm.text_value.value,
        href: inspectorForm.href.value,
        open_new_tab: inspectorForm.open_new_tab.checked
      };
    }
    return { text_value: inspectorForm.text_value.value };
  }

  function setDraft(identity, value, { recordHistory = true, source = 'editor' } = {}) {
    const key = identityKey(identity);
    const previous = clone(drafts.get(key)?.value || baseValues.get(key) || {});
    const next = clone(value);

    if (!baseValues.has(key)) baseValues.set(key, clone(previous));
    if (valuesEqual(previous, next)) return;

    if (recordHistory) {
      const now = Date.now();
      const canCoalesce = source === 'typing' && lastHistoryKey === key && now - lastHistoryTime < 650;
      if (canCoalesce && undoStack.length) {
        undoStack[undoStack.length - 1].after = next;
      } else {
        undoStack.push({ identity: clone(identity), before: previous, after: next });
      }
      lastHistoryKey = key;
      lastHistoryTime = now;
      redoStack.length = 0;
    }

    const base = baseValues.get(key) || {};
    if (valuesEqual(base, next)) drafts.delete(key);
    else drafts.set(key, { identity: clone(identity), value: next });

    updateControls();
  }

  function applyDraftToFrame(identity, value) {
    postToFrame('apply-value', { identity, value });
  }

  function applyInspectorDraft() {
    if (!selectedMessage) return;
    const value = inspectorValue();
    setDraft(selectedMessage.identity, value, { source: 'inspector' });
    applyDraftToFrame(selectedMessage.identity, value);
    setStatus('Applied to preview. Publish when ready.', 'success');
  }

  function undo() {
    const action = undoStack.pop();
    if (!action) return;
    redoStack.push(action);
    setDraft(action.identity, action.before, { recordHistory: false });
    applyDraftToFrame(action.identity, action.before);
    if (selectedMessage && identityKey(selectedMessage.identity) === identityKey(action.identity)) {
      configureInspector({ ...selectedMessage, value: action.before });
    }
    updateControls();
    setStatus('Undid the last change.');
  }

  function redo() {
    const action = redoStack.pop();
    if (!action) return;
    undoStack.push(action);
    setDraft(action.identity, action.after, { recordHistory: false });
    applyDraftToFrame(action.identity, action.after);
    if (selectedMessage && identityKey(selectedMessage.identity) === identityKey(action.identity)) {
      configureInspector({ ...selectedMessage, value: action.after });
    }
    updateControls();
    setStatus('Redid the last change.');
  }

  function serializeDrafts() {
    return [...drafts.values()];
  }

  function saveLocalDraft() {
    const path = currentPagePath();
    if (!path || !drafts.size) return;
    localStorage.setItem(localDraftKey(path), JSON.stringify({
      page_path: path,
      saved_at: new Date().toISOString(),
      drafts: serializeDrafts()
    }));
    setStatus('Draft saved in this browser. It is not public yet.', 'success');
    pageStatus.textContent = 'Draft saved locally. Publish when ready.';
  }

  function restoreLocalDraft() {
    const path = currentPagePath();
    const raw = localStorage.getItem(localDraftKey(path));
    if (!raw || !frameReady) return;

    try {
      const saved = JSON.parse(raw);
      if (!Array.isArray(saved.drafts) || !saved.drafts.length) return;
      if (!confirm(`A saved draft from ${new Date(saved.saved_at).toLocaleString()} was found. Restore it?`)) return;

      saved.drafts.forEach((draft) => {
        setDraft(draft.identity, draft.value, { recordHistory: false });
        applyDraftToFrame(draft.identity, draft.value);
      });
      pageStatus.textContent = 'Saved draft restored in preview.';
      setStatus('Draft restored. It is still not public.', 'success');
    } catch (error) {
      console.warn('Could not restore visual draft:', error);
    }
  }

  async function saveSiteElement(draft) {
    const { identity, value } = draft;
    const payload = {
      page_path: identity.page_path,
      element_key: identity.element_key,
      element_type: identity.element_type,
      text_value: value.text_value ?? null,
      href: value.href ?? null,
      src: value.src ?? null,
      alt_text: value.alt_text ?? null,
      open_new_tab: Boolean(value.open_new_tab),
      is_active: true,
      updated_at: new Date().toISOString()
    };

    const { error } = await client
      .from('site_elements')
      .upsert(payload, { onConflict: 'page_path,element_key' });

    if (error) throw new Error(error.message);
  }

  async function saveSiteContent(draft) {
    const { identity, value } = draft;
    const field = identity.field;
    let storedValue = null;

    if (field === 'link_url') storedValue = value.href ?? value.text_value ?? null;
    else if (field === 'image_url') storedValue = value.src ?? null;
    else storedValue = value.text_value ?? null;

    const payload = {
      content_key: identity.content_key,
      league: identity.content_key.startsWith('gleague.') ? 'gleague' : 'nffl',
      [field]: storedValue,
      updated_at: new Date().toISOString()
    };

    const { error } = await client
      .from('site_content')
      .upsert(payload, { onConflict: 'content_key' });

    if (error) throw new Error(error.message);
  }


  async function saveManagedItem(draft) {
    const { identity, value } = draft;
    let storedValue = value.text_value ?? null;

    if (identity.field === 'image_url') storedValue = value.src ?? null;
    if (identity.field === 'metadata.link_url') {
      const { data: current, error: readError } = await client
        .from('managed_items')
        .select('metadata')
        .eq('id', identity.id)
        .single();
      if (readError) throw new Error(readError.message);
      const metadata = { ...(current?.metadata || {}), link_url: value.href ?? null };
      const { error } = await client
        .from('managed_items')
        .update({ metadata, updated_at: new Date().toISOString() })
        .eq('id', identity.id);
      if (error) throw new Error(error.message);
      return;
    }

    const payload = {
      [identity.field]: storedValue,
      updated_at: new Date().toISOString()
    };
    const { error } = await client.from('managed_items').update(payload).eq('id', identity.id);
    if (error) throw new Error(error.message);
  }

  async function saveArticleField(draft) {
    const { identity, value } = draft;
    let storedValue = value.text_value ?? null;

    if (identity.field === 'image_url') storedValue = value.src ?? null;
    if (identity.field === 'slug') {
      const href = value.href || '';
      const match = href.match(/[?&]slug=([^&]+)/);
      storedValue = match ? decodeURIComponent(match[1]) : String(href).replace(/^.*article-/, '').replace(/\.html.*$/, '');
    }

    const payload = {
      [identity.field]: storedValue,
      updated_at: new Date().toISOString()
    };
    const { error } = await client.from('articles').update(payload).eq('id', identity.id);
    if (error) throw new Error(error.message);
  }

  async function publishDrafts() {
    if (!drafts.size) return;
    publishButton.disabled = true;
    setStatus(`Publishing ${drafts.size} change${drafts.size === 1 ? '' : 's'}…`);

    try {
      for (const draft of drafts.values()) {
        if (draft.identity.storage === 'page_section_order') continue;
        if (draft.identity.storage === 'site_content') await saveSiteContent(draft);
        else if (draft.identity.storage === 'managed_items') await saveManagedItem(draft);
        else if (draft.identity.storage === 'articles') await saveArticleField(draft);
        else await saveSiteElement(draft);
      }
      if ([...drafts.values()].some((draft) => draft.identity.storage === 'page_section_order')) {
        await saveSectionOrder();
      }

      const path = currentPagePath();
      localStorage.removeItem(localDraftKey(path));
      drafts.forEach((draft, key) => baseValues.set(key, clone(draft.value)));
      drafts.clear();
      undoStack.length = 0;
      redoStack.length = 0;
      updateControls();
      setStatus('Published successfully.', 'success');
      pageStatus.textContent = 'Published. The live website will show these changes after refresh.';
    } catch (error) {
      setStatus(error.message, 'error');
    } finally {
      updateControls();
    }
  }

  window.addEventListener('message', (event) => {
    if (event.origin !== location.origin || event.source !== frame.contentWindow) return;
    const message = event.data || {};
    if (message.source !== 'nffl-inline-editor') return;

    if (message.type === 'bridge-loaded') {
      if (editMode) postToFrame('enable');
      pageStatus.textContent = editMode
        ? 'Edit mode: click or double-click a gold-outlined element.'
        : 'Preview mode: links and controls behave normally.';
    }

    if (message.type === 'ready') {
      frameReady = true;
      pageSections = Array.isArray(message.sections) ? message.sections : [];
      renderSections();
      pageStatus.textContent = `Visual editor ready — ${message.count} editable elements found.`;
      setTimeout(restoreLocalDraft, 200);
    }

    if (message.type === 'sections-updated') {
      pageSections = Array.isArray(message.sections) ? message.sections : [];
      renderSections();
      setStatus(message.moved ? 'Section moved in preview. Publish to save the layout.' : 'Page structure refreshed.', message.moved ? 'success' : '');
      if (message.moved) {
        const identity = {
          storage: 'page_section_order',
          page_path: currentPagePath(),
          element_type: 'layout'
        };
        setDraft(identity, { order: pageSections.map((section) => section.key) }, { source: 'layout' });
      }
    }

    if (message.type === 'selected' || message.type === 'open-inspector') {
      configureInspector(message);
    }

    if (message.type === 'draft') {
      const key = identityKey(message.identity);
      if (!baseValues.has(key)) baseValues.set(key, clone(message.value));
      setDraft(message.identity, message.value, { source: 'typing' });

      if (
        selectedMessage &&
        identityKey(selectedMessage.identity) === key
      ) {
        configureInspector({ ...selectedMessage, value: message.value });
      }
    }

    if (message.type === 'save-request') publishDrafts();
    if (message.type === 'undo-request') undo();
    if (message.type === 'redo-request') redo();
  });

  frame.addEventListener('load', () => {
    frameReady = false;
    if (editMode) setTimeout(() => postToFrame('enable'), 150);
  });

  pageSelect.addEventListener('change', () => loadPage(pageSelect.value));

  document.querySelectorAll('[data-preview-size]').forEach((button) => {
    button.addEventListener('click', () => {
      document.querySelectorAll('[data-preview-size]').forEach((item) => item.classList.toggle('active', item === button));
      frameShell.className = `visual-frame-shell ${button.dataset.previewSize}`;
    });
  });

  toggleMode.addEventListener('click', () => {
    editMode = !editMode;
    toggleMode.textContent = editMode ? 'Preview Mode' : 'Edit Mode';
    toggleMode.classList.toggle('active', !editMode);
    postToFrame(editMode ? 'enable' : 'disable');
    pageStatus.textContent = editMode
      ? 'Edit mode: click or double-click a gold-outlined element.'
      : 'Preview mode: the page behaves normally.';
  });

  document.querySelector('#visual-refresh').addEventListener('click', () => {
    if (drafts.size && !confirm('Refresh and discard unsaved preview changes?')) return;
    clearEditorState();
    localStorage.removeItem(localDraftKey());
    frame.contentWindow?.location.reload();
  });

  document.querySelector('#visual-apply-draft').addEventListener('click', applyInspectorDraft);

  document.querySelector('#visual-restore').addEventListener('click', () => {
    if (!selectedMessage) return;
    const key = identityKey(selectedMessage.identity);
    const original = baseValues.get(key);
    if (!original) return;
    setDraft(selectedMessage.identity, original, { source: 'restore' });
    applyDraftToFrame(selectedMessage.identity, original);
    configureInspector({ ...selectedMessage, value: original });
    setStatus('Selected change restored to its published value.');
  });

  inspectorForm.addEventListener('input', () => {
    if (!selectedMessage) return;
    const value = inspectorValue();
    applyDraftToFrame(selectedMessage.identity, value);
    setDraft(selectedMessage.identity, value, { source: 'typing' });
  });

  undoButton.addEventListener('click', undo);
  redoButton.addEventListener('click', redo);
  draftButton.addEventListener('click', saveLocalDraft);
  publishButton.addEventListener('click', publishDrafts);
  document.querySelector('#visual-floating-draft')?.addEventListener('click', saveLocalDraft);
  document.querySelector('#visual-floating-publish')?.addEventListener('click', publishDrafts);

  window.addEventListener('keydown', (event) => {
    const key = event.key.toLowerCase();
    if ((event.ctrlKey || event.metaKey) && key === 's') {
      event.preventDefault();
      publishDrafts();
    }
    if ((event.ctrlKey || event.metaKey) && key === 'z' && !event.shiftKey) {
      event.preventDefault();
      undo();
    }
    if ((event.ctrlKey || event.metaKey) && (key === 'y' || (event.shiftKey && key === 'z'))) {
      event.preventDefault();
      redo();
    }
  });

  window.addEventListener('beforeunload', (event) => {
    if (!drafts.size) return;
    event.preventDefault();
    event.returnValue = '';
  });

  try {
    const data = await loadInventory();
    populatePages(data);
    const requestedPage = new URLSearchParams(location.search).get('page') || 'index.html';
    if ((data.page_catalog || []).some((page) => page.path === requestedPage)) {
      pageSelect.value = requestedPage;
      loadPage(requestedPage);
    }
  } catch (error) {
    pageStatus.textContent = error.message;
  }

  updateControls();
})();
