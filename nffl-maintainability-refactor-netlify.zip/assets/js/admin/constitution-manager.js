(function initConstitutionManager() {
  const STORAGE_KEY = 'nffl.constitution.manager.v1';
  const form = document.querySelector('[data-constitution-form]');
  const list = document.querySelector('[data-constitution-list]');
  const preview = document.querySelector('[data-constitution-preview]');
  const status = document.querySelector('[data-constitution-status]');
  if (!form || !list || !preview) return;

  let articles = [];
  let selectedId = null;

  function setStatus(message, type = '') {
    if (!status) return;
    status.textContent = message;
    status.className = `admin-form-status ${type}`.trim();
  }

  function uid() {
    return `article-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 7)}`;
  }

  function slugify(value) {
    return String(value || 'article')
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/^-|-$/g, '') || 'article';
  }

  function escapeHtml(value) {
    return String(value || '').replace(/[&<>'"]/g, (char) => ({
      '&': '&amp;',
      '<': '&lt;',
      '>': '&gt;',
      "'": '&#039;',
      '"': '&quot;'
    }[char]));
  }

  function detectType(article) {
    const text = `${article.title} ${article.body}`.toLowerCase();
    if (text.includes('penalt') || text.includes('removal') || text.includes('warning')) return 'penalty';
    if (text.includes('commissioner') || text.includes('vote')) return 'commissioner';
    if (text.includes('definition') || text.includes('structure') || text.includes('format')) return 'definition';
    if (text.includes('official') || text.includes('record') || text.includes('fee')) return 'important';
    return 'standard';
  }

  function bodyToHtml(body) {
    return escapeHtml(body).split(/\n{2,}/).map((block) => {
      const lines = block.split('\n').filter(Boolean);
      if (lines.every((line) => /^[-•]\s+/.test(line))) {
        return `<ul>${lines.map((line) => `<li>${line.replace(/^[-•]\s+/, '')}</li>`).join('')}</ul>`;
      }
      if (lines.every((line) => /^\d+\.\s+/.test(line))) {
        return `<ol>${lines.map((line) => `<li>${line.replace(/^\d+\.\s+/, '')}</li>`).join('')}</ol>`;
      }
      if (lines.length === 1 && /:$/.test(lines[0])) return `<h3>${lines[0].replace(/:$/, '')}</h3>`;
      return `<p>${lines.join('<br>')}</p>`;
    }).join('');
  }

  function extractBody(article) {
    const clone = article.cloneNode(true);
    clone.querySelector('h2')?.remove();
    return clone.innerText.trim();
  }

  async function preservedFromPublicPage() {
    try {
      const response = await fetch('../rules.html', { cache: 'no-store' });
      const html = await response.text();
      const doc = new DOMParser().parseFromString(html, 'text/html');
      return Array.from(doc.querySelectorAll('.constitution-article')).map((article, index) => {
        const title = article.querySelector('h2')?.textContent.trim() || `Article ${index + 1}`;
        const body = extractBody(article);
        const item = {
          id: article.id || slugify(title),
          slug: article.id || slugify(title),
          title,
          summary: body.split('\n').find(Boolean) || '',
          body,
          visible: true,
          type: 'standard'
        };
        item.type = detectType(item);
        return item;
      });
    } catch (error) {
      console.warn('Could not parse public Constitution page:', error);
      return [{
        id: 'opening',
        slug: 'opening',
        title: 'Article I - Opening Statement',
        summary: 'Purpose and expected owner conduct.',
        body: 'The purpose of the NFFL is simple: have fun, enjoy the competition, and hopefully take home some money.\n\nAll league members are expected to be respectful, stay engaged throughout the season, compete in good faith, and enjoy the league.',
        visible: true,
        type: 'important'
      }];
    }
  }

  async function load() {
    try {
      const saved = JSON.parse(localStorage.getItem(STORAGE_KEY) || 'null');
      if (Array.isArray(saved) && saved.length) return saved;
    } catch {}
    return preservedFromPublicPage();
  }

  function save() {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(articles));
  }

  function renderList() {
    list.innerHTML = articles.map((article, index) => `
      <article class="constitution-record-card ${article.visible ? '' : 'is-hidden'}" data-id="${escapeHtml(article.id)}">
        <div class="constitution-record-order">
          <button type="button" data-move="up" ${index === 0 ? 'disabled' : ''}>↑</button>
          <button type="button" data-move="down" ${index === articles.length - 1 ? 'disabled' : ''}>↓</button>
        </div>
        <div class="constitution-record-copy">
          <span>${escapeHtml(article.type)} ${article.visible ? 'visible' : 'hidden'}</span>
          <strong>${escapeHtml(article.title)}</strong>
          <small>#${escapeHtml(article.slug)} · ${escapeHtml(article.summary || 'No summary')}</small>
        </div>
        <div class="constitution-record-actions">
          <button type="button" data-edit>Edit</button>
          <button type="button" data-toggle>${article.visible ? 'Hide' : 'Show'}</button>
          <button type="button" data-delete>Delete</button>
        </div>
      </article>
    `).join('');
  }

  function renderPreview(onlyId = null) {
    const source = articles.filter((article) => article.visible && (!onlyId || article.id === onlyId));
    preview.innerHTML = source.length ? source.map((article) => `
      <article class="constitution-callout is-${escapeHtml(article.type)}">
        <h2>${escapeHtml(article.title)}</h2>
        ${article.summary ? `<p><strong>${escapeHtml(article.summary)}</strong></p>` : ''}
        ${bodyToHtml(article.body)}
      </article>
    `).join('') : '<p class="no-results">No visible constitution articles to preview.</p>';
  }

  function fillForm(article) {
    selectedId = article?.id || null;
    form.elements.id.value = article?.id || '';
    form.elements.title.value = article?.title || '';
    form.elements.slug.value = article?.slug || '';
    form.elements.type.value = article?.type || 'standard';
    form.elements.summary.value = article?.summary || '';
    form.elements.body.value = article?.body || '';
    form.elements.visible.checked = article?.visible !== false;
  }

  function refresh() {
    renderList();
    renderPreview();
  }

  form.addEventListener('submit', (event) => {
    event.preventDefault();
    const fd = new FormData(form);
    const id = fd.get('id') || uid();
    const payload = {
      id,
      title: fd.get('title'),
      slug: fd.get('slug') || slugify(fd.get('title')),
      type: fd.get('type'),
      summary: fd.get('summary'),
      body: fd.get('body'),
      visible: form.elements.visible.checked
    };
    const index = articles.findIndex((item) => item.id === id);
    if (index >= 0) articles[index] = payload;
    else articles.push(payload);
    save();
    selectedId = id;
    setStatus('Saved locally. Export JSON or copy the preview when you are ready to publish changes.', 'success');
    refresh();
  });

  list.addEventListener('click', (event) => {
    const card = event.target.closest('[data-id]');
    if (!card) return;
    const id = card.dataset.id;
    const index = articles.findIndex((item) => item.id === id);
    if (index < 0) return;
    const action = event.target.dataset.move || (event.target.dataset.edit !== undefined ? 'edit' : event.target.dataset.toggle !== undefined ? 'toggle' : event.target.dataset.delete !== undefined ? 'delete' : '');
    if (action === 'up' && index > 0) [articles[index - 1], articles[index]] = [articles[index], articles[index - 1]];
    if (action === 'down' && index < articles.length - 1) [articles[index + 1], articles[index]] = [articles[index], articles[index + 1]];
    if (action === 'toggle') articles[index].visible = !articles[index].visible;
    if (action === 'delete') {
      if (!confirm('Delete this constitution article from the manager?')) return;
      articles.splice(index, 1);
    }
    if (action === 'edit') fillForm(articles[index]);
    save();
    refresh();
  });

  document.querySelector('[data-constitution-new]')?.addEventListener('click', () => fillForm({ id: '', title: '', slug: '', type: 'standard', summary: '', body: '', visible: true }));
  document.querySelector('[data-constitution-preview-one]')?.addEventListener('click', () => renderPreview(selectedId));
  document.querySelector('[data-constitution-print]')?.addEventListener('click', () => window.print());
  document.querySelector('[data-constitution-reset]')?.addEventListener('click', async () => {
    if (!confirm('Restore the preserved constitution defaults in this manager?')) return;
    articles = await preservedFromPublicPage();
    selectedId = articles[0]?.id || null;
    fillForm(articles[0] || {});
    save();
    refresh();
    setStatus('Preserved rules restored.', 'success');
  });
  document.querySelector('[data-constitution-export]')?.addEventListener('click', () => {
    const blob = new Blob([JSON.stringify(articles, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'nffl-constitution-articles.json';
    a.click();
    URL.revokeObjectURL(url);
  });
  document.querySelector('[data-constitution-import]')?.addEventListener('change', async (event) => {
    const file = event.target.files?.[0];
    if (!file) return;
    try {
      const data = JSON.parse(await file.text());
      if (!Array.isArray(data)) throw new Error('JSON must be an article array.');
      articles = data;
      selectedId = articles[0]?.id || null;
      fillForm(articles[0] || {});
      save();
      refresh();
      setStatus('Imported constitution JSON.', 'success');
    } catch (error) {
      setStatus(error.message, 'error');
    }
  });

  (async () => {
    articles = await load();
    selectedId = articles[0]?.id || null;
    fillForm(articles[0] || {});
    refresh();
  })();
})();
