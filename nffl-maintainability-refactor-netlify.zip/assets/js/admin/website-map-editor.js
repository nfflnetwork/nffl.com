
(async function setupWebsiteMapEditor() {
  const client = window.nfflSupabase;
  const pageSelect = document.querySelector('#website-page-select');
  const search = document.querySelector('#website-element-search');
  const sectionTabs = document.querySelector('#website-section-tabs');
  const elementList = document.querySelector('#website-element-list');
  const count = document.querySelector('#website-element-count');
  const openPage = document.querySelector('#website-open-page');
  const viewPage = document.querySelector('#website-view-page');
  const form = document.querySelector('#website-element-form');
  const empty = document.querySelector('#website-editor-empty');
  const status = document.querySelector('#website-editor-status');

  if (!client || !pageSelect || !form) return;

  let inventory = null;
  let currentRows = [];
  let selected = null;
  let activeSection = 'All';

  const typeIcons = { text: '✏️', link: '🔗', image: '🖼️' };

  function setStatus(message, type = '') {
    status.textContent = message;
    status.className = `admin-form-status ${type}`.trim();
  }

  async function loadInventory() {
    if (inventory) return inventory;
    const response = await fetch('existing-content-data.json', { cache: 'no-store' });
    if (!response.ok) throw new Error('Could not load the website inventory.');
    inventory = await response.json();
    return inventory;
  }

  function pageGroup(path) {
    if (path.startsWith('g-league/')) return 'G-League';
    if (path.startsWith('history/seasons/')) return 'Season Vault';
    if (path.startsWith('team-') || path.includes('/team-')) return 'Team Pages';
    if (path.startsWith('article-')) return 'Article Pages';
    return 'NFFL';
  }

  function populatePages(data) {
    const groups = {};
    data.page_catalog.forEach((page) => {
      const group = pageGroup(page.path);
      groups[group] ||= [];
      groups[group].push(page);
    });

    pageSelect.innerHTML = '<option value="">Choose a page…</option>' +
      Object.entries(groups).map(([group, pages]) => `
        <optgroup label="${group}">
          ${pages.sort((a,b) => a.title.localeCompare(b.title)).map((page) =>
            `<option value="${page.path}">${page.title} — ${page.path}</option>`
          ).join('')}
        </optgroup>
      `).join('');
  }

  function getOriginal(row) {
    return inventory.site_elements.find((item) =>
      item.page_path === row.page_path && item.element_key === row.element_key
    ) || row;
  }

  function renderSections() {
    const sections = ['All', ...new Set(currentRows.map((row) => row.section_label || 'General'))];
    if (!sections.includes(activeSection)) activeSection = 'All';

    sectionTabs.innerHTML = sections.map((section) => `
      <button type="button" class="${section === activeSection ? 'active' : ''}" data-section="${section}">
        ${section}
      </button>
    `).join('');

    sectionTabs.querySelectorAll('[data-section]').forEach((button) => {
      button.addEventListener('click', () => {
        activeSection = button.dataset.section;
        renderSections();
        renderElements();
      });
    });
  }

  function renderElements() {
    const q = search.value.trim().toLowerCase();
    const rows = currentRows.filter((row) => {
      const sectionMatch = activeSection === 'All' || (row.section_label || 'General') === activeSection;
      const searchText = `${row.element_label} ${row.section_label} ${row.text_value} ${row.href} ${row.src}`.toLowerCase();
      return sectionMatch && (!q || searchText.includes(q));
    });

    count.textContent = `${rows.length} editable item${rows.length === 1 ? '' : 's'}`;

    elementList.innerHTML = rows.length ? rows.map((row) => `
      <button type="button" class="website-element-card${selected?.id === row.id ? ' active' : ''}" data-element-id="${row.id}">
        <span class="website-element-type">${typeIcons[row.element_type] || '✏️'}</span>
        <span class="website-element-copy">
          <strong>${row.element_label}</strong>
          <small>${row.section_label || 'General'} • ${row.element_type}</small>
        </span>
      </button>
    `).join('') : '<div class="rank-item"><h3>No matching items</h3><p>Try another section or search term.</p></div>';

    elementList.querySelectorAll('[data-element-id]').forEach((button) => {
      button.addEventListener('click', () => {
        const row = currentRows.find((item) => Number(item.id) === Number(button.dataset.elementId));
        if (row) openElement(row);
      });
    });
  }

  function configureFields(type) {
    document.querySelector('#website-text-field').hidden = type === 'image';
    document.querySelector('#website-link-field').hidden = type !== 'link';
    document.querySelector('#website-image-field').hidden = type !== 'image';
    document.querySelector('#website-alt-field').hidden = type !== 'image';
    document.querySelector('#website-new-tab-field').hidden = type !== 'link';
  }

  function fillForm(row) {
    form.id.value = row.id || '';
    form.page_path.value = row.page_path;
    form.element_key.value = row.element_key;
    form.element_type.value = row.element_type;
    form.text_value.value = row.text_value ?? '';
    form.href.value = row.href ?? '';
    form.src.value = row.src ?? '';
    form.alt_text.value = row.alt_text ?? '';
    form.open_new_tab.checked = Boolean(row.open_new_tab);
  }

  function openElement(row) {
    selected = row;
    empty.hidden = true;
    form.hidden = false;
    configureFields(row.element_type);
    fillForm(row);

    document.querySelector('#website-element-type-icon').textContent = typeIcons[row.element_type] || '✏️';
    document.querySelector('#website-selected-section').textContent = row.section_label || 'General';
    document.querySelector('#website-selected-label').textContent = row.element_label;
    document.querySelector('#website-selected-location').textContent = `${row.page_path} • ${row.element_key}`;

    const original = getOriginal(row);
    const preview = original.element_type === 'image'
      ? `${original.src || ''}${original.alt_text ? ` — ${original.alt_text}` : ''}`
      : original.element_type === 'link'
        ? `${original.text_value || '(complex link)'} → ${original.href || ''}`
        : original.text_value || '';
    document.querySelector('#website-original-preview').textContent = preview;

    viewPage.href = `../${row.page_path}`;
    renderElements();
    document.querySelector('#website-element-editor').scrollIntoView({ behavior: 'smooth', block: 'start' });
  }

  async function loadPage(path) {
    if (!path) {
      currentRows = [];
      elementList.innerHTML = '<div class="rank-item"><h3>Choose a page</h3></div>';
      return;
    }

    openPage.href = `../${path}`;
    viewPage.href = `../${path}`;
    count.textContent = 'Loading…';

    const rows = [];
    let start = 0;
    const pageSize = 1000;

    while (true) {
      const { data, error } = await client
        .from('site_elements')
        .select('*')
        .eq('page_path', path)
        .order('section_label')
        .order('element_key')
        .range(start, start + pageSize - 1);

      if (error) {
        elementList.innerHTML = `<div class="rank-item"><h3>Could not load page</h3><p>${error.message}</p></div>`;
        return;
      }

      rows.push(...(data || []));
      if (!data || data.length < pageSize) break;
      start += pageSize;
    }

    currentRows = rows;
    selected = null;
    activeSection = 'All';
    empty.hidden = false;
    form.hidden = true;
    renderSections();
    renderElements();
  }

  pageSelect.addEventListener('change', () => loadPage(pageSelect.value));
  search.addEventListener('input', renderElements);

  document.querySelector('#website-restore-original').addEventListener('click', () => {
    if (!selected) return;
    const original = getOriginal(selected);
    fillForm({ ...selected, ...original, id: selected.id });
    setStatus('Original website value loaded into the form. Press Save Element to publish it.');
  });

  form.addEventListener('submit', async (event) => {
    event.preventDefault();
    if (!selected) return;

    const payload = {
      page_path: form.page_path.value,
      element_key: form.element_key.value,
      section_label: selected.section_label,
      element_label: selected.element_label,
      element_type: form.element_type.value,
      text_value: form.element_type.value === 'image' ? null : (form.text_value.value || null),
      href: form.element_type.value === 'link' ? (form.href.value || null) : null,
      src: form.element_type.value === 'image' ? (form.src.value || null) : null,
      alt_text: form.element_type.value === 'image' ? (form.alt_text.value || null) : null,
      open_new_tab: form.element_type.value === 'link' ? form.open_new_tab.checked : false,
      is_active: true,
      updated_at: new Date().toISOString()
    };

    setStatus('Saving…');
    const { data, error } = await client
      .from('site_elements')
      .update(payload)
      .eq('id', selected.id)
      .select()
      .single();

    if (error) {
      setStatus(error.message, 'error');
      return;
    }

    const index = currentRows.findIndex((row) => row.id === data.id);
    if (index >= 0) currentRows[index] = data;
    selected = data;
    setStatus('Saved. Refresh the public page to see the change.', 'success');
    renderElements();
  });

  try {
    const data = await loadInventory();
    populatePages(data);

    const requestedPage = new URLSearchParams(location.search).get('page');
    if (requestedPage && data.page_catalog.some((page) => page.path === requestedPage)) {
      pageSelect.value = requestedPage;
      await loadPage(requestedPage);
    }
  } catch (error) {
    elementList.innerHTML = `<div class="rank-item"><h3>Editor unavailable</h3><p>${error.message}</p></div>`;
  }
})();
