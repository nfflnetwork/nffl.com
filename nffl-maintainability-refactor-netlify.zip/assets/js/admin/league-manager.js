
(async function setupLeagueManager() {
  const client = window.nfflSupabase;
  const pageForm = document.querySelector('#league-page-form');
  const itemForm = document.querySelector('#league-item-form');
  const modal = document.querySelector('#league-item-modal');
  const pageStatus = document.querySelector('#league-page-status');
  const itemStatus = document.querySelector('#league-item-status');
  const deleteButton = document.querySelector('#delete-league-item');
  const championExtras = document.querySelector('#league-champion-extra-fields');
  if (!client || !pageForm || !itemForm || !modal) return;

  const defaults = {
    hero_title:'The Home of the NFFL',
    hero_body:'A 12-team dynasty league built around competition, history, accountability, and year-round storytelling.',
    league_status:'Active',
    season_label:'2026 NFFL Season',
    teams:'12',
    divisions:'4',
    regular_season:'14 Weeks',
    playoff_teams:'8 Teams',
    established:'2025',
    current_season:'Season 2',
    commissioner_heading:"Commissioners' Message",
    commissioner_message:"The NFFL exists to create a competitive, organized, and memorable dynasty experience. Every season adds another chapter to the league's history.",
    commissioner_name:'NFFL Commissioners',
    overview:"The NFFL combines long-term roster building, active league management, original media coverage, and a connected developmental G-League.",
    mission_heading:'League Mission',
    mission_body:'The NFFL exists to create a competitive, organized, and memorable dynasty experience where every franchise contributes to a permanent shared history.',
    format:'Dynasty Fantasy Football',
    scoring:'Half PPR • TEP • IDP',
    platform:'Sleeper',
    rule_integrity:'Every franchise is expected to maintain an active and competitive roster.',
    rule_accountability:'League participation, communication, and long-term management matter.',
    rule_history:'Records and achievements remain attached to the franchise.',
    gleague_summary:'The G-League serves as the official coaching pipeline for future NFFL vacancies.'
  };

  const types = ['league_champion','league_timeline','league_leadership'];

  const defaultItems = [
    {
      content_type:'league_champion',
      league:'nffl',
      rank:1,
      item_key:'league-champion-2025-26',
      title:'CrimsonChin1',
      subtitle:'2025–26',
      body:'Inaugural NFFL Champion',
      metadata:{},
      is_active:true
    },
    {
      content_type:'league_timeline',
      league:'nffl',
      rank:1,
      item_key:'league-timeline-founded',
      title:'NFFL Founded',
      subtitle:'2025',
      body:"The inaugural franchises begin the league's first season.",
      metadata:{},
      is_active:true
    },
    {
      content_type:'league_timeline',
      league:'nffl',
      rank:2,
      item_key:'league-timeline-network-launch',
      title:'NFFL Network Launches',
      subtitle:'2026',
      body:"The league's full media and history platform goes live.",
      metadata:{},
      is_active:true
    },
    {
      content_type:'league_leadership',
      league:'nffl',
      rank:1,
      item_key:'league-leadership-conorfigueroa',
      title:'conorfigueroa',
      subtitle:'Commissioner',
      body:'League operations and governance',
      metadata:{},
      is_active:true
    },
    {
      content_type:'league_leadership',
      league:'nffl',
      rank:2,
      item_key:'league-leadership-elliottmintz',
      title:'elliottmintz',
      subtitle:'Commissioner',
      body:'League operations and governance',
      metadata:{},
      is_active:true
    },
    {
      content_type:'league_leadership',
      league:'nffl',
      rank:3,
      item_key:'league-leadership-mjd413',
      title:'mjd413',
      subtitle:'Commissioner',
      body:'League operations and governance',
      metadata:{},
      is_active:true
    }
  ];

  let items = [];

  const esc = (value) => String(value ?? '')
    .replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;')
    .replaceAll('"','&quot;').replaceAll("'","&#039;");

  function status(node,message,type='') {
    node.textContent = message;
    node.className = `admin-form-status ${type}`.trim();
  }

  function setTab(name) {
    document.querySelectorAll('[data-league-admin-tab]').forEach((button)=>{
      button.classList.toggle('active',button.dataset.leagueAdminTab===name);
    });
    document.querySelectorAll('[data-league-admin-panel]').forEach((panel)=>{
      panel.hidden = panel.dataset.leagueAdminPanel !== name;
    });
  }

  document.querySelectorAll('[data-league-admin-tab]').forEach((button)=>{
    button.addEventListener('click',()=>setTab(button.dataset.leagueAdminTab));
  });

  document.querySelector('#refresh-league-preview')?.addEventListener('click',()=>{
    const frame = document.querySelector('#league-live-preview');
    if (frame) frame.src = `../league.html?preview=${Date.now()}`;
  });

  async function loadPageContent() {
    const keys = Object.keys(defaults).map((key)=>`league.${key}`);
    const {data,error} = await client.from('site_content')
      .select('content_key,title,body')
      .in('content_key',keys);

    if (error) {
      status(pageStatus,error.message,'error');
      return;
    }

    const map = Object.fromEntries((data || []).map((row)=>[row.content_key,row]));
    Object.entries(defaults).forEach(([key,fallback])=>{
      const field = pageForm.elements.namedItem(key);
      if (!field) return;
      let value = map[`league.${key}`]?.body || map[`league.${key}`]?.title || fallback;
      if (key === 'commissioner_name' && value === 'NFFL Commissioner') value = 'NFFL Commissioners';
      field.value = value;
    });
    status(pageStatus,'League page content loaded.','success');
  }

  pageForm.addEventListener('submit',async(event)=>{
    event.preventDefault();
    const rows = [];
    new FormData(pageForm).forEach((value,key)=>{
      rows.push({
        content_key:`league.${key}`,
        league:'nffl',
        title:key,
        body:String(value).trim(),
        updated_at:new Date().toISOString()
      });
    });

    status(pageStatus,'Saving page content…');
    const {error} = await client.from('site_content').upsert(rows,{onConflict:'content_key'});
    status(pageStatus,error ? error.message : 'League page content saved.',error ? 'error' : 'success');
  });

  function typeLabel(type) {
    return {
      league_champion:'Champion',
      league_timeline:'Timeline Event',
      league_leadership:'Leader'
    }[type] || 'League Item';
  }

  function renderLists() {
    types.forEach((type)=>{
      const root = document.querySelector(`[data-league-manager-list="${type}"]`);
      const rows = items
        .filter((row)=>row.content_type===type)
        .sort((a,b)=>(a.rank||999)-(b.rank||999));

      root.innerHTML = rows.length ? rows.map((row,index)=>`
        <article class="league-manager-edit-card" data-league-item-id="${row.id}">
          <div class="league-manager-order">
            <button type="button" data-move-item="-1" ${index===0?'disabled':''} aria-label="Move up">↑</button>
            <strong>${row.rank || index+1}</strong>
            <button type="button" data-move-item="1" ${index===rows.length-1?'disabled':''} aria-label="Move down">↓</button>
          </div>
          <div class="league-manager-edit-copy">
            <span>${esc(row.subtitle || typeLabel(type))}</span>
            <strong>${esc(row.title || 'Untitled')}</strong>
            <p>${esc(row.body || 'No description')}</p>
            ${type === 'league_champion' ? `<div class="league-manager-champion-meta">
              <span>Runner-Up: ${esc(row.metadata?.runner_up || 'Not entered')}</span>
              <span>Record: ${esc(row.metadata?.champion_record || 'Not entered')}</span>
              <span>Final: ${esc(row.metadata?.final_score || 'Not entered')}</span>
            </div>` : ''}
            <small>${row.is_active === false ? 'Hidden' : 'Visible on public page'}</small>
          </div>
          <button class="button" type="button" data-edit-league-item>Edit</button>
        </article>`).join('') :
        `<div class="league-manager-empty">
          <strong>No ${typeLabel(type).toLowerCase()} entries yet.</strong>
          <p>Use the Add button above to create the first one.</p>
        </div>`;
    });

    document.querySelectorAll('[data-edit-league-item]').forEach((button)=>{
      button.addEventListener('click',()=>{
        const id = Number(button.closest('[data-league-item-id]').dataset.leagueItemId);
        const row = items.find((item)=>Number(item.id)===id);
        openModal(row?.content_type,row);
      });
    });

    document.querySelectorAll('[data-move-item]').forEach((button)=>{
      button.addEventListener('click',async()=>{
        const card = button.closest('[data-league-item-id]');
        const id = Number(card.dataset.leagueItemId);
        const direction = Number(button.dataset.moveItem);
        const row = items.find((item)=>Number(item.id)===id);
        const siblings = items.filter((item)=>item.content_type===row.content_type)
          .sort((a,b)=>(a.rank||999)-(b.rank||999));
        const currentIndex = siblings.findIndex((item)=>Number(item.id)===id);
        const target = siblings[currentIndex + direction];
        if (!target) return;

        const rowRank = row.rank || currentIndex+1;
        const targetRank = target.rank || currentIndex+1+direction;
        await Promise.all([
          client.from('managed_items').update({rank:targetRank,updated_at:new Date().toISOString()}).eq('id',row.id),
          client.from('managed_items').update({rank:rowRank,updated_at:new Date().toISOString()}).eq('id',target.id)
        ]);
        await loadItems();
      });
    });
  }


  async function ensureExistingPublicEntries() {
    const {data,error} = await client.from('managed_items')
      .select('id,content_type,item_key,title,subtitle,body,rank,is_active')
      .eq('league','nffl')
      .in('content_type',types);

    if (error) {
      status(itemStatus,error.message,'error');
      return;
    }

    const existing = data || [];
    const existingKeys = new Set(existing.map((row)=>row.item_key));
    const missing = defaultItems.filter((row)=>!existingKeys.has(row.item_key));

    if (missing.length) {
      const {error:insertError} = await client.from('managed_items').insert(missing);
      if (insertError) {
        status(itemStatus,insertError.message,'error');
        return;
      }
    }

    const wrongChampion = existing.find((row)=>
      row.content_type === 'league_champion' &&
      /2025.?26/i.test(String(row.subtitle || '')) &&
      /knightmare005/i.test(String(row.title || ''))
    );

    if (wrongChampion) {
      await client.from('managed_items')
        .update({
          title:'CrimsonChin1',
          body:wrongChampion.body || 'Inaugural NFFL Champion',
          updated_at:new Date().toISOString()
        })
        .eq('id',wrongChampion.id);
    }

    const placeholderLeader = existing.find((row)=>
      row.content_type === 'league_leadership' &&
      /^nffl commissioner$/i.test(String(row.title || '').trim())
    );

    if (placeholderLeader) {
      await client.from('managed_items').delete().eq('id',placeholderLeader.id);
    }
  }

  async function loadItems() {
    const {data,error} = await client.from('managed_items')
      .select('*')
      .eq('league','nffl')
      .in('content_type',types)
      .order('rank',{ascending:true});

    if (error) {
      status(itemStatus,error.message,'error');
      return;
    }

    items = (data || []).map((row)=>{
      const season = String(row.subtitle || '');
      if (row.content_type==='league_champion' &&
          /2025.?26/i.test(season) &&
          /knightmare005/i.test(String(row.title || ''))) {
        return {...row,title:'CrimsonChin1'};
      }
      return row;
    });
    renderLists();
  }

  function openModal(type,row=null) {
    itemForm.reset();
    itemForm.elements.id.value = row?.id || '';
    itemForm.elements.content_type.value = type;
    itemForm.elements.rank.value = row?.rank || (items.filter((item)=>item.content_type===type).length + 1);
    itemForm.elements.subtitle.value = row?.subtitle || '';
    itemForm.elements.title.value = row?.title || '';
    itemForm.elements.body.value = row?.body || '';
    itemForm.elements.runner_up.value = row?.metadata?.runner_up || '';
    itemForm.elements.champion_record.value = row?.metadata?.champion_record || '';
    itemForm.elements.final_score.value = row?.metadata?.final_score || '';
    championExtras.hidden = type !== 'league_champion';
    itemForm.elements.is_active.checked = row?.is_active !== false;
    document.querySelector('#league-item-form-title').textContent =
      `${row ? 'Edit' : 'Add'} ${typeLabel(type)}`;
    deleteButton.hidden = !row;
    status(itemStatus,'');
    modal.hidden = false;
    document.body.classList.add('league-modal-open');
    setTimeout(()=>itemForm.elements.title.focus(),50);
  }

  function closeModal() {
    modal.hidden = true;
    document.body.classList.remove('league-modal-open');
  }

  document.querySelectorAll('[data-new-league-item]').forEach((button)=>{
    button.addEventListener('click',()=>openModal(button.dataset.newLeagueItem));
  });
  document.querySelectorAll('[data-close-league-modal]').forEach((button)=>{
    button.addEventListener('click',closeModal);
  });

  itemForm.addEventListener('submit',async(event)=>{
    event.preventDefault();
    const fd = new FormData(itemForm);
    const id = Number(fd.get('id')) || null;
    const type = String(fd.get('content_type') || '');
    const payload = {
      content_type:type,
      league:'nffl',
      rank:Number(fd.get('rank')) || 1,
      item_key:`${type}-${id || Date.now()}`,
      title:String(fd.get('title') || '').trim(),
      subtitle:String(fd.get('subtitle') || '').trim(),
      body:String(fd.get('body') || '').trim(),
      metadata:type === 'league_champion' ? {
        runner_up:String(fd.get('runner_up') || '').trim(),
        champion_record:String(fd.get('champion_record') || '').trim(),
        final_score:String(fd.get('final_score') || '').trim()
      } : {},
      is_active:itemForm.elements.is_active.checked,
      updated_at:new Date().toISOString()
    };

    if (!payload.title) {
      status(itemStatus,'Add a title or name.','error');
      return;
    }

    status(itemStatus,'Saving…');
    const query = id
      ? client.from('managed_items').update(payload).eq('id',id)
      : client.from('managed_items').insert(payload);
    const {error} = await query;

    if (error) status(itemStatus,error.message,'error');
    else {
      await loadItems();
      closeModal();
    }
  });

  deleteButton.addEventListener('click',async()=>{
    const id = Number(itemForm.elements.id.value);
    if (!id || !confirm('Delete this League page item?')) return;
    const {error} = await client.from('managed_items').delete().eq('id',id);
    if (error) status(itemStatus,error.message,'error');
    else {
      await loadItems();
      closeModal();
    }
  });

  document.addEventListener('keydown',(event)=>{
    if (event.key==='Escape' && !modal.hidden) closeModal();
  });

  setTab('page');
  await ensureExistingPublicEntries();
  await Promise.all([loadPageContent(),loadItems()]);
})();
