(function createAdminDataService(){
  const TEAM_TABLE = 'team_content';
  const TEAM_IDENTITY_FIELDS = Object.freeze(['id', 'league', 'team_key', 'created_at', 'updated_at']);
  const TEAM_EDITABLE_FIELDS = Object.freeze([
    'team_name', 'coach_name', 'about_coach', 'franchise_notes', 'team_news',
    'current_team', 'division', 'status', 'coach_record', 'current_record',
    'all_time_record', 'championships', 'runner_up_finishes', 'best_finish',
    'best_record', 'established_year', 'staff_history', 'franchise_timeline',
    'logo_url', 'banner_url', 'primary_color', 'secondary_color', 'social_url',
    'sleeper_roster_id', 'sleeper_owner_id', 'sleeper_owner_name',
    'sleeper_owner_avatar', 'sleeper_owner_synced_at', 'last_game', 'next_game',
    'division_titles', 'hall_of_fame_members', 'season_vault_note', 'trophy_notes'
  ]);
  const TEAM_COLUMNS = Object.freeze([...TEAM_IDENTITY_FIELDS, ...TEAM_EDITABLE_FIELDS]);
  const TEAM_NUMBER_FIELDS = new Set(['established_year', 'sleeper_roster_id']);

  const getClient = () => window.nfflSupabase;
  const message = (error, fallback = 'Database request failed.') => error?.message || fallback;

  async function run(label, operation, { requireRows = false } = {}){
    const client = getClient();
    if (!client) throw new Error('Supabase is not connected. Check assets/js/admin/supabase-config.js.');
    let result;
    try {
      result = await operation(client);
    } catch (error) {
      throw new Error(`${label}: ${message(error)}`);
    }
    if (result?.error) throw new Error(`${label}: ${message(result.error)}`);
    if (requireRows && (!Array.isArray(result?.data) || result.data.length === 0)) {
      throw new Error(`${label}: Supabase returned no row. Check authentication and RLS policies.`);
    }
    return result?.data ?? null;
  }

  async function verifyById(table, id, columns = '*'){
    return run(`Verify ${table}`, client => client.from(table).select(columns).eq('id', id).single());
  }

  async function saveById(table, payload, id = null){
    const data = await run(`Save ${table}`, client => {
      const query = id
        ? client.from(table).update(payload).eq('id', id)
        : client.from(table).insert(payload);
      return query.select('*');
    }, { requireRows: true });
    return data[0];
  }

  async function removeById(table, id){
    await run(`Delete ${table}`, client => client.from(table).delete().eq('id', id));
    const client = getClient();
    const { data, error } = await client.from(table).select('id').eq('id', id).maybeSingle();
    if (error) throw new Error(`Verify deletion: ${message(error)}`);
    if (data) throw new Error(`Delete ${table}: the row still exists after deletion.`);
    return true;
  }

  async function upsert(table, rows, onConflict){
    const payload = Array.isArray(rows) ? rows : [rows];
    return run(`Save ${table}`, client => client.from(table).upsert(payload, { onConflict }).select('*'), { requireRows: true });
  }

  function normalizeTeamValue(field, value){
    if (value === undefined) return undefined;
    if (value === null || value === '') return null;
    if (TEAM_NUMBER_FIELDS.has(field)) {
      const number = Number(value);
      return Number.isFinite(number) ? number : value;
    }
    return typeof value === 'string' ? value.trim() : value;
  }

  function teamChanges(original, candidate){
    return TEAM_EDITABLE_FIELDS.reduce((changes, field) => {
      const before = normalizeTeamValue(field, original?.[field]);
      const after = normalizeTeamValue(field, candidate?.[field]);
      if (after !== undefined && before !== after) changes[field] = after;
      return changes;
    }, {});
  }

  async function loadTeams(){
    console.info('[Teams CMS] Loading Teams...');
    const rows = await run('Load teams', client =>
      client.from(TEAM_TABLE).select(TEAM_COLUMNS.join(',')).order('team_name')
    );
    console.info('[Teams CMS] Loaded Teams', { count: rows?.length || 0 });
    return rows || [];
  }

  async function loadTeam(league, teamKey){
    console.info('[Teams CMS] Loading Team...', { league, teamKey });
    const row = await run('Load team', client =>
      client.from(TEAM_TABLE)
        .select(TEAM_COLUMNS.join(','))
        .eq('league', league)
        .eq('team_key', teamKey)
        .single()
    );
    console.info('[Teams CMS] Loaded Team', { league, teamKey });
    return row;
  }

  async function saveTeam(original, candidate){
    if (!original?.id) throw new Error('Save team: no persisted team is selected.');
    const changes = teamChanges(original, candidate);
    const updatedColumns = Object.keys(changes);
    if (!updatedColumns.length) return { row: original, updatedColumns: [] };

    const payload = { ...changes, updated_at: new Date().toISOString() };
    console.info('[Teams CMS] Saving Team...', {
      league: original.league,
      teamKey: original.team_key
    });
    console.info('[Teams CMS] Updated Columns', updatedColumns);

    const data = await run('Save team', client =>
      client.from(TEAM_TABLE)
        .update(payload)
        .eq('id', original.id)
        .eq('league', original.league)
        .eq('team_key', original.team_key)
        .select(TEAM_COLUMNS.join(','))
    , { requireRows: true });

    const row = data[0];
    console.info('[Teams CMS] Save Complete', { id: row.id, updatedColumns });
    return { row, updatedColumns };
  }

  function downloadJson(filename, data){
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement('a');
    anchor.href = url;
    anchor.download = filename;
    anchor.click();
    setTimeout(() => URL.revokeObjectURL(url), 0);
  }

  window.NFFLAdminData = {
    TEAM_COLUMNS,
    TEAM_EDITABLE_FIELDS,
    run,
    saveById,
    removeById,
    upsert,
    verifyById,
    downloadJson,
    normalizeTeamValue,
    teamChanges,
    loadTeams,
    loadTeam,
    saveTeam
  };
})();
