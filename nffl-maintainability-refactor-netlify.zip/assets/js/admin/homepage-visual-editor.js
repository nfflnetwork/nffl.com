
(async function setupHomepageVisualEditor() {
  const client = window.nfflSupabase;
  const dataNode = document.querySelector('#homepage-block-data');
  const cards = [...document.querySelectorAll('[data-homepage-key]')];
  const form = document.querySelector('#homepage-visual-form');
  const empty = document.querySelector('#homepage-editor-empty');
  const status = document.querySelector('#homepage-editor-status');
  const selectedLabel = document.querySelector('#homepage-selected-label');
  const selectedLocation = document.querySelector('#homepage-selected-location');
  const selectedIcon = document.querySelector('#homepage-selected-icon');
  const titleField = document.querySelector('#homepage-title-field');
  const bodyField = document.querySelector('#homepage-body-field');
  const previewTitle = document.querySelector('#homepage-preview-title');
  const previewBody = document.querySelector('#homepage-preview-body');
  const originalButton = document.querySelector('#homepage-use-original');

  if (!client || !dataNode || !form) return;

  const blocks = JSON.parse(dataNode.textContent);
  let selected = null;

  function setStatus(message, type = '') {
    status.textContent = message;
    status.className = `admin-form-status ${type}`.trim();
  }

  function updatePreview() {
    previewTitle.textContent = form.title.value.trim() || '';
    previewBody.textContent = form.body.value.trim() || '';
    previewTitle.hidden = !previewTitle.textContent;
    previewBody.hidden = !previewBody.textContent;
  }

  function loadOriginalValues() {
    if (!selected) return;
    form.title.value = selected.default_title || '';
    form.body.value = selected.default_body || '';
    form.image_url.value = '';
    updatePreview();
    setStatus('Original website text loaded. Press Save This Section to publish it.');
  }

  async function openBlock(key) {
    selected = blocks.find((block) => block.key === key);
    if (!selected) return;

    cards.forEach((card) => card.classList.toggle('active', card.dataset.homepageKey === key));
    empty.hidden = true;
    form.hidden = false;

    form.content_key.value = selected.key;
    selectedLabel.textContent = selected.label;
    selectedLocation.textContent = selected.location;
    selectedIcon.textContent = selected.icon;

    titleField.hidden = !selected.uses_title;
    bodyField.hidden = !selected.uses_body;
    titleField.querySelector('span')?.remove();

    if (selected.uses_title) {
      titleField.childNodes[0].nodeValue = `${selected.title_label || 'Title'} `;
    }
    if (selected.uses_body) {
      bodyField.childNodes[0].nodeValue = `${selected.body_label || 'Text'} `;
    }

    setStatus('Loading saved content…');

    const { data, error } = await client
      .from('site_content')
      .select('*')
      .eq('content_key', selected.key)
      .maybeSingle();

    if (error) {
      setStatus(error.message, 'error');
      return;
    }

    if (data) {
      form.title.value = data.title || '';
      form.body.value = data.body || '';
      form.image_url.value = data.image_url || '';
      setStatus('Saved homepage content loaded.', 'success');
    } else {
      form.title.value = selected.default_title || '';
      form.body.value = selected.default_body || '';
      form.image_url.value = '';
      setStatus('Showing the original website text.');
    }

    updatePreview();
    document.querySelector('#homepage-edit-panel').scrollIntoView({ behavior: 'smooth', block: 'start' });
  }

  cards.forEach((card) => {
    card.addEventListener('click', () => openBlock(card.dataset.homepageKey));
  });

  form.title.addEventListener('input', updatePreview);
  form.body.addEventListener('input', updatePreview);
  originalButton.addEventListener('click', loadOriginalValues);

  form.addEventListener('submit', async (event) => {
    event.preventDefault();
    if (!selected) {
      setStatus('Choose a homepage section first.', 'error');
      return;
    }

    const payload = {
      content_key: selected.key,
      league: 'nffl',
      title: selected.uses_title ? (form.title.value.trim() || null) : null,
      body: selected.uses_body ? (form.body.value.trim() || null) : null,
      image_url: form.image_url.value.trim() || null,
      updated_at: new Date().toISOString()
    };

    setStatus('Saving…');
    const { error } = await client
      .from('site_content')
      .upsert(payload, { onConflict: 'content_key' });

    if (error) {
      setStatus(error.message, 'error');
      return;
    }

    setStatus('Saved. Refresh the public homepage to see the update.', 'success');
  });

  const requestedKey = new URLSearchParams(location.search).get('key');
  if (requestedKey && blocks.some((block) => block.key === requestedKey)) {
    openBlock(requestedKey);
  }
})();
