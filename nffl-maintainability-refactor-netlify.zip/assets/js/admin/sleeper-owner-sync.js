
(async function setupOwnerSync2() {
  const client = window.nfflSupabase;
  const dataService = window.NFFLAdminData;
  const franchiseList = document.querySelector('#owner-franchise-list');
  const rosterGrid = document.querySelector('#owner-roster-grid');
  const preview = document.querySelector('#owner-preview-card');
  const status = document.querySelector('#owner-sync-status');
  const search = document.querySelector('#owner-search');
  if (!client || !dataService || !franchiseList || !rosterGrid || !preview) return;

  const leagueIds = {
    nffl: '1314378987576774656',
    gleague: '1314378817090916352'
  };

  let activeLeague = 'nffl';
  let teams = [];
  let seeds = [];
  let sleeper = {};
  let selectedKey = null;
  const pending = new Map();

  const esc = (value) => String(value ?? '')
    .replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;')
    .replaceAll('"','&quot;').replaceAll("'","&#039;");
  const norm = (value) => String(value || '').toLowerCase().replace(/[^a-z0-9]/g,'');

  function setStatus(message, type='') {
    status.textContent = message;
    status.className = `admin-form-status ${type}`.trim();
  }

  async function api(path) {
    const response = await fetch(`https://api.sleeper.app/v1${path}`, { cache:'no-store' });
    if (!response.ok) throw new Error(`Sleeper API returned ${response.status}`);
    return response.json();
  }

  function teamId(team) {
    return `${team.league}:${team.team_key}`;
  }

  function selectedRosterId(team) {
    return pending.has(teamId(team))
      ? pending.get(teamId(team))
      : Number(team.sleeper_roster_id) || null;
  }

  function ownerName(user, roster) {
    return user?.display_name || user?.username || roster?.owner_id || 'Vacant';
  }

  function avatarUrl(avatar) {
    return avatar ? `https://sleepercdn.com/avatars/thumbs/${encodeURIComponent(avatar)}` : '';
  }

  async function loadSeeds() {
    try {
      const response = await fetch('existing-content-data.json', { cache:'no-store' });
      const data = await response.json();
      seeds = data.team_content || data.teams || [];
    } catch (_) {
      seeds = [];
    }
  }

  async function loadTeams() {
    teams = await dataService.loadTeams();
  }

  async function loadSleeper(league) {
    const [rosters, users, tradedPicks] = await Promise.all([
      api(`/league/${leagueIds[league]}/rosters`),
      api(`/league/${leagueIds[league]}/users`),
      api(`/league/${leagueIds[league]}/traded_picks`).catch(() => [])
    ]);
    const usersById = Object.fromEntries((users || []).map((user) => [user.user_id,user]));
    const options = (rosters || []).map((roster) => {
      const user = usersById[roster.owner_id];
      const pickCount = (tradedPicks || []).filter((pick) => Number(pick.owner_id) === Number(roster.roster_id)).length;
      return {
        roster_id:Number(roster.roster_id),
        owner_id:roster.owner_id || null,
        owner_name:ownerName(user, roster),
        username:user?.username || '',
        team_name:roster.metadata?.team_name || user?.metadata?.team_name || '',
        avatar:user?.avatar || null,
        players:(roster.players || []).length,
        picks:pickCount
      };
    });
    sleeper[league] = { rosters, users, usersById, options };
  }

  function allRows() {
    const map = new Map();
    seeds.forEach((seed) => map.set(`${seed.league}:${seed.team_key}`, { ...seed }));
    teams.forEach((row) => map.set(`${row.league}:${row.team_key}`, { ...map.get(`${row.league}:${row.team_key}`), ...row }));
    return [...map.values()];
  }

  function activeRows() {
    const q = norm(search?.value);
    return allRows()
      .filter((row) => row.league === activeLeague)
      .filter((row) => !q || norm(`${row.team_name} ${row.coach_name} ${row.sleeper_owner_name} ${row.team_key}`).includes(q))
      .sort((a,b) => String(a.team_name || a.team_key).localeCompare(String(b.team_name || b.team_key)));
  }

  function duplicateSet() {
    const counts = {};
    allRows().filter((row) => row.league === activeLeague).forEach((row) => {
      const id = selectedRosterId(row);
      if (id) counts[id] = (counts[id] || 0) + 1;
    });
    return new Set(Object.entries(counts).filter(([,count]) => count > 1).map(([id]) => Number(id)));
  }

  function stateFor(team) {
    const rosterId = selectedRosterId(team);
    if (!rosterId) return 'unmatched';
    if (duplicateSet().has(Number(rosterId))) return 'duplicate';
    const exists = sleeper[team.league]?.options.some((item) => item.roster_id === Number(rosterId));
    return exists ? 'connected' : 'missing';
  }

  function renderFranchises() {
    const rows = activeRows();
    franchiseList.innerHTML = rows.length ? rows.map((team) => {
      const state = stateFor(team);
      const selected = selectedKey === teamId(team);
      return `
        <button type="button" class="owner2-franchise-card ${state} ${selected ? 'active' : ''}" data-team-key="${esc(team.team_key)}">
          <span>${state === 'connected' ? '✓' : state === 'duplicate' ? '!' : state === 'missing' ? '×' : '○'}</span>
          <div>
            <strong>${esc(team.team_name || team.team_key)}</strong>
            <small>${esc(team.coach_name || 'Coach TBD')}</small>
          </div>
          <b>${selectedRosterId(team) ? `#${selectedRosterId(team)}` : 'Unassigned'}</b>
        </button>`;
    }).join('') : '<p class="meta">No franchises found.</p>';

    franchiseList.querySelectorAll('[data-team-key]').forEach((button) => {
      button.addEventListener('click', () => {
        selectedKey = `${activeLeague}:${button.dataset.teamKey}`;
        renderAll();
      });
    });
  }

  function renderRosters() {
    const team = allRows().find((row) => teamId(row) === selectedKey);
    const options = sleeper[activeLeague]?.options || [];
    const usedBy = new Map();
    allRows().filter((row) => row.league === activeLeague).forEach((row) => {
      const id = selectedRosterId(row);
      if (id) usedBy.set(Number(id), row);
    });

    document.querySelector('#owner-selected-label').textContent = team
      ? `Assigning: ${team.team_name || team.team_key}`
      : 'Select a franchise first';

    if (!team) {
      rosterGrid.innerHTML = '<div class="rank-item"><h3>Select a franchise</h3><p>Then choose the matching Sleeper roster.</p></div>';
      return;
    }

    rosterGrid.innerHTML = options.map((option) => {
      const assignedTeam = usedBy.get(option.roster_id);
      const selected = Number(selectedRosterId(team)) === option.roster_id;
      const assignedElsewhere = assignedTeam && teamId(assignedTeam) !== teamId(team);
      return `
        <article class="owner2-roster-card ${selected ? 'selected' : ''} ${assignedElsewhere ? 'used' : ''}">
          <div class="owner2-avatar">${option.avatar ? `<img src="${avatarUrl(option.avatar)}" alt="">` : '<span>🏈</span>'}</div>
          <div class="owner2-roster-copy">
            <span>Roster #${option.roster_id}</span>
            <h3>${esc(option.owner_name)}</h3>
            <p>${esc(option.team_name || 'No custom Sleeper team name')}</p>
            <small>${option.players} players • ${option.picks} traded picks</small>
            ${assignedElsewhere ? `<em>Currently assigned to ${esc(assignedTeam.team_name || assignedTeam.team_key)}</em>` : ''}
          </div>
          <button type="button" data-connect-roster="${option.roster_id}">
            ${selected ? 'Connected' : assignedElsewhere ? 'Reassign Here' : 'Connect'}
          </button>
        </article>`;
    }).join('');

    rosterGrid.querySelectorAll('[data-connect-roster]').forEach((button) => {
      button.addEventListener('click', () => {
        const rosterId = Number(button.dataset.connectRoster);
        pending.set(teamId(team), rosterId);
        renderAll();
        setStatus(`${team.team_name || team.team_key} is ready to connect to roster ${rosterId}. Save All Connections to publish.`,'success');
      });
    });
  }

  function renderPreview() {
    const team = allRows().find((row) => teamId(row) === selectedKey);
    if (!team) {
      preview.innerHTML = '<span class="owner2-preview-icon">↻</span><h3>No franchise selected</h3><p>Choose a website franchise to preview its mapping.</p>';
      return;
    }
    const rosterId = selectedRosterId(team);
    const option = sleeper[team.league]?.options.find((item) => item.roster_id === Number(rosterId));
    const state = stateFor(team);
    preview.innerHTML = `
      <span class="owner2-preview-status ${state}">${state === 'connected' ? 'Valid connection' : state === 'duplicate' ? 'Duplicate roster' : state === 'missing' ? 'Roster unavailable' : 'Not connected'}</span>
      <h3>${esc(team.team_name || team.team_key)}</h3>
      <p><strong>Coach:</strong> ${esc(team.coach_name || 'TBD')}</p>
      <hr>
      ${option ? `
        <div class="owner2-preview-owner">
          <div class="owner2-avatar">${option.avatar ? `<img src="${avatarUrl(option.avatar)}" alt="">` : '<span>🏈</span>'}</div>
          <div><span>Current Sleeper account</span><strong>${esc(option.owner_name)}</strong><small>${option.username ? '@'+esc(option.username) : `Roster ${option.roster_id}`}</small></div>
        </div>
        <dl>
          <div><dt>Roster ID</dt><dd>${option.roster_id}</dd></div>
          <div><dt>Players</dt><dd>${option.players}</dd></div>
          <div><dt>Sleeper Team</dt><dd>${esc(option.team_name || 'None')}</dd></div>
          <div><dt>Traded Picks</dt><dd>${option.picks}</dd></div>
        </dl>` :
        '<p>No valid Sleeper roster is selected.</p>'}
      <a class="button" href="${team.league === 'gleague' ? '../g-league/' : '../'}team-${esc(team.team_key)}.html" target="_blank">Open Team Page</a>`;
  }

  function updateHealth() {
    const rows = allRows().filter((row) => row.league === activeLeague);
    const connected = rows.filter((row) => stateFor(row) === 'connected').length;
    const problems = rows.length - connected;
    document.querySelector('#owner-api-health').textContent = sleeper[activeLeague] ? 'Connected' : 'Unavailable';
    document.querySelector('#owner-team-count').textContent = rows.length;
    document.querySelector('#owner-connected-count').textContent = connected;
    document.querySelector('#owner-problem-count').textContent = problems;
  }

  function renderAll() {
    renderFranchises();
    renderRosters();
    renderPreview();
    updateHealth();
  }

  function scoreMatch(team, option) {
    const targets = [team.team_name,team.current_team,team.coach_name,team.sleeper_owner_name].map(norm).filter(Boolean);
    const candidates = [option.team_name,option.owner_name,option.username,option.owner_id].map(norm).filter(Boolean);
    let score = 0;
    targets.forEach((target) => candidates.forEach((candidate) => {
      if (target === candidate) score = Math.max(score,100);
      else if (target && candidate && (target.includes(candidate) || candidate.includes(target))) score = Math.max(score,80);
    }));
    return score;
  }

  function autoMatch() {
    const rows = allRows().filter((row) => row.league === activeLeague);
    const options = sleeper[activeLeague]?.options || [];
    const used = new Set(rows.map(selectedRosterId).filter(Boolean).map(Number));
    let matched = 0;
    rows.forEach((team) => {
      if (selectedRosterId(team)) return;
      const best = options.filter((option) => !used.has(option.roster_id))
        .map((option) => ({ option, score:scoreMatch(team,option) }))
        .sort((a,b) => b.score-a.score)[0];
      if (best?.score >= 80) {
        pending.set(teamId(team),best.option.roster_id);
        used.add(best.option.roster_id);
        matched += 1;
      }
    });
    renderAll();
    setStatus(`${matched} safe match${matched === 1 ? '' : 'es'} prepared. Review before saving.`,'success');
  }

  async function repairMissing() {
    const rows = allRows();
    const missing = seeds.filter((seed) => !teams.some((team) => team.league === seed.league && team.team_key === seed.team_key));
    if (!missing.length) return setStatus('No missing franchise records found.','success');
    const payload = missing.map((seed) => ({
      league:seed.league,
      team_key:seed.team_key,
      team_name:seed.team_name || seed.current_team || seed.team_key,
      coach_name:seed.coach_name || null,
      current_team:seed.current_team || seed.team_name || null,
      division:seed.division || null,
      status:seed.status || 'Active',
      updated_at:new Date().toISOString()
    }));
    await dataService.upsert('team_content', payload, 'league,team_key');
    await loadTeams();
    renderAll();
    setStatus(`${payload.length} missing team record${payload.length === 1 ? '' : 's'} repaired.`,'success');
  }

  async function saveAll() {
    const rows = allRows().filter((row) => row.league === activeLeague);
    if (duplicateSet().size) {
      setStatus(`Duplicate roster assignments must be fixed first: ${[...duplicateSet()].join(', ')}.`,'error');
      return;
    }

    const payload = rows.map((team) => {
      const rosterId = selectedRosterId(team);
      const option = sleeper[team.league]?.options.find((item) => item.roster_id === Number(rosterId));
      return {
        league:team.league,
        team_key:team.team_key,
        team_name:team.team_name || team.team_key,
        coach_name:team.coach_name || null,
        current_team:team.current_team || team.team_name || null,
        division:team.division || null,
        status:team.status || 'Active',
        sleeper_roster_id:rosterId,
        sleeper_owner_id:option?.owner_id || null,
        sleeper_owner_name:option?.owner_name || null,
        sleeper_owner_avatar:option?.avatar || null,
        sleeper_owner_synced_at:new Date().toISOString(),
        updated_at:new Date().toISOString()
      };
    });

    setStatus('Saving all connections…');
    const data = await dataService.upsert('team_content', payload, 'league,team_key');
    teams = [
      ...teams.filter((team) => team.league !== activeLeague),
      ...(data || [])
    ];
    pending.clear();
    renderAll();
    setStatus('All connections saved. Team pages will use these roster IDs immediately after refresh.','success');
  }

  function validateAll() {
    const rows = allRows().filter((row) => row.league === activeLeague);
    const results = {
      connected:rows.filter((row) => stateFor(row) === 'connected').length,
      unmatched:rows.filter((row) => stateFor(row) === 'unmatched').length,
      duplicate:rows.filter((row) => stateFor(row) === 'duplicate').length,
      missing:rows.filter((row) => stateFor(row) === 'missing').length
    };
    const type = results.unmatched || results.duplicate || results.missing ? 'error' : 'success';
    setStatus(`Validation: ${results.connected} valid, ${results.unmatched} unconnected, ${results.duplicate} duplicate, ${results.missing} unavailable.`,type);
  }

  async function refresh() {
    try {
      setStatus('Loading website teams and Sleeper rosters…');
      await Promise.all([loadSeeds(),loadTeams(),loadSleeper('nffl'),loadSleeper('gleague')]);
      const currentRows = allRows().filter((row) => row.league === activeLeague);
      if (!selectedKey && currentRows.length) selectedKey = teamId(currentRows[0]);
      renderAll();
      setStatus('Roster Sync 2.0 is ready.','success');
    } catch (error) {
      document.querySelector('#owner-api-health').textContent = 'Error';
      setStatus(error.message,'error');
    }
  }

  document.querySelectorAll('[data-owner-league]').forEach((button) => button.addEventListener('click', () => {
    activeLeague = button.dataset.ownerLeague;
    document.querySelectorAll('[data-owner-league]').forEach((item) => item.classList.toggle('active',item===button));
    const first = allRows().find((row) => row.league === activeLeague);
    selectedKey = first ? teamId(first) : null;
    renderAll();
  }));
  search?.addEventListener('input',renderAll);
  document.querySelector('#owner-auto-match').addEventListener('click',autoMatch);
  document.querySelector('#owner-validate').addEventListener('click',validateAll);
  document.querySelector('#owner-repair-records').addEventListener('click',() => repairMissing().catch((e)=>setStatus(e.message,'error')));
  document.querySelector('#owner-refresh').addEventListener('click',refresh);
  document.querySelector('#owner-save-all').addEventListener('click',() => saveAll().catch((e)=>setStatus(e.message,'error')));

  await refresh();
})();
