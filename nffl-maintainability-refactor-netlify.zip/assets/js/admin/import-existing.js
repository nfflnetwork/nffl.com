
(async function setupExistingImport() {
  const client = window.nfflSupabase;
  const status = document.querySelector('#import-status');
  const importButton = document.querySelector('#import-all-existing');
  const previewButton = document.querySelector('#preview-existing');
  const overwrite = document.querySelector('#overwrite-existing');
  const summary = document.querySelector('#import-summary');

  if (!client || !importButton || !summary) return;

  let payload = null;

  function setStatus(message, type = '') {
    status.textContent = message;
    status.className = `admin-form-status ${type}`.trim();
  }

  async function loadPayload() {
    if (payload) return payload;
    const response = await fetch('existing-content-data.json', { cache: 'no-store' });
    if (!response.ok) throw new Error('Could not load existing-content-data.json');
    payload = await response.json();
    return payload;
  }

  function showSummary(data) {
    summary.innerHTML = `
      <article class="history-stat-card"><span>Articles</span><strong>${data.articles.length}</strong><p>Existing published story pages</p></article>
      <article class="history-stat-card"><span>Teams</span><strong>${data.teams.length}</strong><p>NFFL and G-League team pages</p></article>
      <article class="history-stat-card"><span>Awards</span><strong>${data.awards.length}</strong><p>Weeks 1–17 plus yearly categories</p></article>
      <article class="history-stat-card"><span>Hot Seat</span><strong>${data.hot_seat.length}</strong><p>Current placeholder watchlist</p></article>
      <article class="history-stat-card"><span>Page Content</span><strong>${data.site_content.length}</strong><p>Homepage, intros, and constitution sections</p></article>
      <article class="history-stat-card"><span>Season Vaults</span><strong>${data.season_vaults.length}</strong><p>Existing historical entries</p></article>
      <article class="history-stat-card"><span>Managed Items</span><strong>${data.managed_items.length}</strong><p>Rankings, schedule, history, promotion, and constitution</p></article>
      <article class="history-stat-card"><span>Website Elements</span><strong>${data.site_elements.length}</strong><p>Editable text, links, buttons, navigation, and images</p></article>
    `;
  }

  async function upsertOrInsert(table, rows, onConflict) {
    if (!rows.length) return;
    const chunkSize = 300;
    for (let start = 0; start < rows.length; start += chunkSize) {
      const chunk = rows.slice(start, start + chunkSize);
      const query = overwrite.checked
        ? client.from(table).upsert(chunk, { onConflict })
        : client.from(table).insert(chunk);
      const { error } = await query;
      if (error) throw new Error(`${table}: ${error.message}`);
      setStatus(`Importing ${table}: ${Math.min(start + chunk.length, rows.length)} / ${rows.length}`);
    }
  }


  async function insertChunks(table, rows) {
    if (!rows.length) return;
    const chunkSize = 300;
    for (let start = 0; start < rows.length; start += chunkSize) {
      const chunk = rows.slice(start, start + chunkSize);
      const { error } = await client.from(table).insert(chunk);
      if (error) throw new Error(`${table}: ${error.message}`);
      setStatus(`Importing ${table}: ${Math.min(start + chunk.length, rows.length)} / ${rows.length}`);
    }
  }

  async function importAll() {
    const data = await loadPayload();
    importButton.disabled = true;
    setStatus('Importing current website content…');

    try {
      if (overwrite.checked) {
        await upsertOrInsert('articles', data.articles, 'slug');
        await upsertOrInsert('team_content', data.teams, 'league,team_key');
        await upsertOrInsert('site_content', data.site_content, 'content_key');
        await upsertOrInsert('season_vaults', data.season_vaults, 'league,season');

        for (const league of ['nffl', 'gleague']) {
          const { error: awardDeleteError } = await client
            .from('awards')
            .delete()
            .eq('league', league)
            .eq('season', 2026);
          if (awardDeleteError) throw new Error(`awards cleanup: ${awardDeleteError.message}`);
        }
        const { error: awardInsertError } = await client.from('awards').insert(data.awards);
        if (awardInsertError) throw new Error(`awards: ${awardInsertError.message}`);

        const { error: hotDeleteError } = await client.from('hot_seat').delete().eq('season', 2026);
        if (hotDeleteError) throw new Error(`hot_seat cleanup: ${hotDeleteError.message}`);
        const { error: hotInsertError } = await client.from('hot_seat').insert(data.hot_seat);
        if (hotInsertError) throw new Error(`hot_seat: ${hotInsertError.message}`);

        const { error: managedDeleteError } = await client.from('managed_items').delete().neq('id', 0);
        if (managedDeleteError) throw new Error(`managed_items cleanup: ${managedDeleteError.message}`);
        await insertChunks('managed_items', data.managed_items);

        const { error: elementDeleteError } = await client.from('site_elements').delete().neq('id', 0);
        if (elementDeleteError) throw new Error(`site_elements cleanup: ${elementDeleteError.message}`);
        await insertChunks('site_elements', data.site_elements);
      } else {
        await upsertOrInsert('articles', data.articles, 'slug');
        await upsertOrInsert('team_content', data.teams, 'league,team_key');
        await upsertOrInsert('site_content', data.site_content, 'content_key');
        await upsertOrInsert('season_vaults', data.season_vaults, 'league,season');

        // Awards/Hot Seat use safe insert only when empty.
        const { count: awardCount } = await client.from('awards').select('*', { count: 'exact', head: true });
        if (!awardCount) {
          const { error } = await client.from('awards').insert(data.awards);
          if (error) throw new Error(`awards: ${error.message}`);
        }
        const { count: hotCount } = await client.from('hot_seat').select('*', { count: 'exact', head: true });
        if (!hotCount) {
          const { error } = await client.from('hot_seat').insert(data.hot_seat);
          if (error) throw new Error(`hot_seat: ${error.message}`);
        }

        const { count: managedCount } = await client.from('managed_items').select('*', { count: 'exact', head: true });
        if (!managedCount) {
          await insertChunks('managed_items', data.managed_items);
        }

        const { count: elementCount } = await client.from('site_elements').select('*', { count: 'exact', head: true });
        if (!elementCount) {
          await insertChunks('site_elements', data.site_elements);
        }
      }

      setStatus('Import complete. Existing website content is now available in the admin editors.', 'success');
    } catch (error) {
      console.error(error);
      setStatus(error.message, 'error');
    } finally {
      importButton.disabled = false;
    }
  }

  previewButton.addEventListener('click', async () => {
    try {
      const data = await loadPayload();
      showSummary(data);
      setStatus('Preview loaded. Nothing has been written to Supabase yet.');
    } catch (error) {
      setStatus(error.message, 'error');
    }
  });

  importButton.addEventListener('click', importAll);

  try {
    showSummary(await loadPayload());
  } catch (error) {
    setStatus(error.message, 'error');
  }
})();
