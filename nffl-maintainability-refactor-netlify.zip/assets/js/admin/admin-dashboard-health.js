document.addEventListener('DOMContentLoaded',async()=>{
  const main=document.querySelector('.admin-v3-main');
  if(!main || !window.NFFLAdmin) return;
  const section=document.createElement('section');
  section.className='admin-v3-alert';
  section.innerHTML='<div><strong>Supabase admin health</strong><p id="admin-health-summary">Checking database tables and permissions…</p><div id="admin-health-details"></div></div><button type="button" id="admin-health-recheck">Recheck</button>';
  main.prepend(section);
  const summary=section.querySelector('#admin-health-summary');
  const details=section.querySelector('#admin-health-details');
  async function check(){
    summary.textContent='Checking database tables and permissions…';details.innerHTML='';
    try{
      const rows=await window.NFFLAdmin.probe();
      const bad=rows.filter(r=>!r.ok);
      summary.textContent=bad.length ? `${bad.length} admin data source${bad.length===1?' is':'s are'} unavailable.` : 'Supabase connection and core admin tables are available.';
      details.innerHTML=rows.map(r=>`<span style="display:inline-block;margin:4px 8px 0 0">${r.ok?'✓':'✕'} ${r.table}${r.ok?'':`: ${r.error}`}</span>`).join('');
    }catch(error){summary.textContent=error.message;}
  }
  section.querySelector('#admin-health-recheck').addEventListener('click',check);
  setTimeout(check,500);
});
