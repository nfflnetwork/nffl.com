
(async function setupLogin() {
  const client = window.nfflSupabase;
  const form = document.querySelector('#admin-login-form');
  const status = document.querySelector('#login-status');
  const resetButton = document.querySelector('#reset-password');

  if (!client || !form) return;

  const params = new URLSearchParams(location.search);
  if (params.get('error') === 'unauthorized') {
    status.textContent = 'This account does not have commissioner access.';
    status.className = 'admin-form-status error';
  }

  form.addEventListener('submit', async (event) => {
    event.preventDefault();
    const email = form.email.value.trim();
    const password = form.password.value;
    const submit = form.querySelector('button[type="submit"]');

    submit.disabled = true;
    status.textContent = 'Signing in…';
    status.className = 'admin-form-status';

    const { error } = await client.auth.signInWithPassword({ email, password });
    if (error) {
      status.textContent = error.message;
      status.className = 'admin-form-status error';
      submit.disabled = false;
      return;
    }

    const next = params.get('next');
    location.replace(next && next.startsWith('/') ? next : 'index.html');
  });

  resetButton?.addEventListener('click', async () => {
    const email = form.email.value.trim();
    if (!email) {
      status.textContent = 'Enter your email first.';
      status.className = 'admin-form-status error';
      return;
    }

    const { error } = await client.auth.resetPasswordForEmail(email, {
      redirectTo: 'https://nffl.netlify.app/admin/login.html'
    });

    status.textContent = error ? error.message : 'Password reset email sent.';
    status.className = `admin-form-status${error ? ' error' : ' success'}`;
  });
})();
