
(async function setupFriendlyPageEditor() {
  const client = window.nfflSupabase;
  const dataNode = document.querySelector('#friendly-block-data');
  const form = document.querySelector('#friendly-page-editor');
  const status = document.querySelector('#friendly-editor-status');
  const label = document.querySelector('#selected-block-label');
  const pageLink = document.querySelector('#selected-page-link');
  const restoreButton = document.querySelector('#restore-static');
  const cards = [...document.querySelectorAll('.content-block-card')];
  const categoryTabs = [...document.querySelectorAll('.content-category-tab')];

  if (!client || !dataNode || !form) return;

  const blocks = JSON.parse(dataNode.textContent);
  let selected = null;

  function setStatus(message, type = '') {
    status.textContent = message;
    status.className = `admin-form-status ${type}`.trim();
  }

  function selectCategory(category) {
    categoryTabs.forEach((tab) => tab.classList.toggle('active', tab.dataset.category === category));
    cards.forEach((card) => {
      card.hidden = card.dataset.blockCategory !== category;
    });
  }

  categoryTabs.forEach((tab) => {
    tab.addEventListener('click', () => selectCategory(tab.dataset.category));
  });

  async function openBlock(key) {
    selected = blocks.find((block) => block.key === key);
    if (!selected) return;

    cards.forEach((card) => card.classList.toggle('active', card.dataset.blockKey === key));
    label.textContent = selected.label;
    pageLink.href = `../${selected.path}`;
    form.content_key.value = selected.key;
    form.league.value = selected.category.includes('G-League') ? 'gleague' : 'nffl';

    setStatus('Loading saved content…');

    const { data, error } = await client
      .from('site_content')
      .select('*')
      .eq('content_key', selected.key)
      .maybeSingle();

    if (error) {
      setStatus(error.message, 'error');
      return;
    }

    if (data) {
      form.title.value = data.title || '';
      form.body.value = data.body || '';
      form.image_url.value = data.image_url || '';
      setStatus('Saved version loaded.', 'success');
    } else {
      form.title.value = selected.title || '';
      form.body.value = selected.body || '';
      form.image_url.value = '';
      setStatus('Original website text loaded.');
    }

    document.querySelector('#content-editor-panel').scrollIntoView({ behavior: 'smooth', block: 'start' });
  }

  cards.forEach((card) => {
    card.addEventListener('click', () => openBlock(card.dataset.blockKey));
  });

  form.addEventListener('submit', async (event) => {
    event.preventDefault();
    if (!selected) {
      setStatus('Choose a section first.', 'error');
      return;
    }

    const payload = {
      content_key: selected.key,
      league: form.league.value,
      title: form.title.value.trim() || null,
      body: form.body.value.trim() || null,
      image_url: form.image_url.value.trim() || null,
      updated_at: new Date().toISOString()
    };

    setStatus('Saving…');
    const { error } = await client
      .from('site_content')
      .upsert(payload, { onConflict: 'content_key' });

    if (error) {
      setStatus(error.message, 'error');
      return;
    }

    setStatus('Saved. Refresh the public page to see the update.', 'success');
  });

  restoreButton.addEventListener('click', () => {
    if (!selected) return;
    form.title.value = selected.title || '';
    form.body.value = selected.body || '';
    form.image_url.value = '';
    setStatus('Original website text restored in the form. Press Save Changes to publish it.');
  });

  const requestedCategory = new URLSearchParams(location.search).get('category');
  const availableCategories = categoryTabs.map((tab) => tab.dataset.category);
  selectCategory(
    requestedCategory && availableCategories.includes(requestedCategory)
      ? requestedCategory
      : (categoryTabs[0]?.dataset.category || 'Homepage')
  );
})();
