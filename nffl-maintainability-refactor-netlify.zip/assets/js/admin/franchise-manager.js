
(async function setupFranchiseManager() {
  const client = window.nfflSupabase;
  const dataService = window.NFFLAdminData;
  const validator = window.NFFLTeamValidation;
  const list = document.querySelector('#franchise-list');
  const form = document.querySelector('#franchise-form');
  const status = document.querySelector('#franchise-status');
  const title = document.querySelector('#franchise-editor-title');
  const search = document.querySelector('#franchise-search');
  const leagueTabs = [...document.querySelectorAll('[data-franchise-league]')];
  const panelTabs = [...document.querySelectorAll('[data-franchise-panel-tab]')];
  const panels = [...document.querySelectorAll('[data-franchise-panel]')];
  const pageLink = document.querySelector('#franchise-public-link');
  const staffList = document.querySelector('#staff-history-admin-list');
  const timelineList = document.querySelector('#timeline-admin-list');
  const savedCount = document.querySelector('#franchise-saved-count');
  const saveButton = document.querySelector('#save-franchise');

  if (!client || !dataService || !validator || !list || !form) return;

  let records = [];
  let activeLeague = new URLSearchParams(location.search).get('league') || 'nffl';
  let selected = null;
  let cleanSnapshot = null;
  let dirty = false;

  function setStatus(message, type = '') {
    status.textContent = message;
    status.className = `admin-form-status ${type}`.trim();
  }

  function displayName(team) {
    return team.team_name || team.team_key.replaceAll('-', ' ');
  }

  function publicPath(team) {
    // Two historical page slugs intentionally differ from their immutable
    // database team keys. Keep URLs stable while Supabase remains authoritative.
    const nfflPageOverrides = {
      crimsonchin1: 'team-knightmare005.html',
      kursed: 'team-djsp.html'
    };
    return team.league === 'gleague'
      ? `../g-league/team-${team.team_key}.html`
      : `../${nfflPageOverrides[team.team_key] || `team-${team.team_key}.html`}`;
  }

  function mergedTeams() {
    return records;
  }

  function renderList() {
    const query = (search.value || '').trim().toLowerCase();
    const items = mergedTeams()
      .filter((team) => team.league === activeLeague)
      .filter((team) => !query || `${team.team_name} ${team.coach_name} ${team.team_key}`.toLowerCase().includes(query))
      .sort((a, b) => displayName(a).localeCompare(displayName(b)));

    if (savedCount) {
      savedCount.textContent = records.filter((team) => team.league === activeLeague).length;
    }

    list.innerHTML = items.map((team) => `
      <button type="button" class="franchise-card${selected && selected.team_key === team.team_key && selected.league === team.league ? ' active' : ''}" data-team-key="${team.team_key}" data-team-league="${team.league}">
        <div class="franchise-card-logo">
          <span>${escapeHtml((displayName(team).match(/[A-Za-z0-9]/g) || ['N']).slice(0,2).join('').toUpperCase())}</span>
        </div>
        <div>
          <strong>${displayName(team)}</strong>
          <span>Coach: ${team.coach_name || 'TBD'}</span>
          <small>${team.division || 'Division TBD'} • Saved in Supabase</small>
        </div>
      </button>
    `).join('') || '<div class="rank-item"><h3>No teams found</h3></div>';

    list.querySelectorAll('.franchise-card').forEach((card) => {
      card.addEventListener('click', () => openTeam(card.dataset.teamLeague, card.dataset.teamKey));
    });
  }

  function setPanel(panelName) {
    panelTabs.forEach((tab) => tab.classList.toggle('active', tab.dataset.franchisePanelTab === panelName));
    panels.forEach((panel) => panel.hidden = panel.dataset.franchisePanel !== panelName);
  }


  function escapeHtml(value) {
    return String(value ?? '')
      .replaceAll('&', '&amp;')
      .replaceAll('<', '&lt;')
      .replaceAll('>', '&gt;')
      .replaceAll('"', '&quot;')
      .replaceAll("'", '&#039;');
  }

  function clearStaffForm() {
    document.querySelector('#staff-entry-id').value = '';
    document.querySelector('#staff-entry-years').value = '';
    document.querySelector('#staff-entry-title').value = '';
    document.querySelector('#staff-entry-body').value = '';
  }

  function clearTimelineForm() {
    document.querySelector('#timeline-entry-id').value = '';
    document.querySelector('#timeline-entry-rank').value = '';
    document.querySelector('#timeline-entry-year').value = '';
    document.querySelector('#timeline-entry-title').value = '';
    document.querySelector('#timeline-entry-body').value = '';
  }

  async function loadRepeatingHistory() {
    if (!selected) return;

    const { data, error } = await client
      .from('managed_items')
      .select('*')
      .eq('league', selected.league)
      .in('content_type', ['franchise_staff', 'franchise_timeline'])
      .contains('metadata', { team_key: selected.team_key })
      .order('rank', { ascending: true });

    if (error) {
      setStatus(error.message, 'error');
      return;
    }

    const staff = (data || []).filter((item) => item.content_type === 'franchise_staff');
    const timeline = (data || []).filter((item) => item.content_type === 'franchise_timeline');

    staffList.innerHTML = staff.length ? staff.map((item) => `
      <article class="admin-repeat-item" data-repeat-id="${item.id}" data-repeat-type="staff">
        <div><span>${escapeHtml(item.subtitle || '')}</span><strong>${escapeHtml(item.title || '')}</strong><p>${escapeHtml(item.body || '')}</p></div>
        <div class="admin-record-actions"><button type="button" data-edit-repeat>Edit</button><button type="button" class="danger" data-delete-repeat>Delete</button></div>
      </article>
    `).join('') : '<div class="rank-item"><p>No staff-history entries yet.</p></div>';

    timelineList.innerHTML = timeline.length ? timeline.map((item, index) => `
      <article class="admin-repeat-item timeline-order-item" data-repeat-id="${item.id}" data-repeat-type="timeline" data-rank="${item.rank || index + 1}">
        <div class="timeline-order-badge">${item.rank || index + 1}</div>
        <div><span>${escapeHtml(item.subtitle || '')}</span><strong>${escapeHtml(item.title || '')}</strong><p>${escapeHtml(item.body || '')}</p></div>
        <div class="admin-record-actions timeline-order-actions">
          <button type="button" data-move-timeline="up" ${index === 0 ? 'disabled' : ''}>Move Up</button>
          <button type="button" data-move-timeline="down" ${index === timeline.length - 1 ? 'disabled' : ''}>Move Down</button>
          <button type="button" data-edit-repeat>Edit</button>
          <button type="button" class="danger" data-delete-repeat>Delete</button>
        </div>
      </article>
    `).join('') : '<div class="rank-item"><p>No timeline entries yet.</p></div>';

    document.querySelectorAll('[data-edit-repeat]').forEach((button) => {
      button.addEventListener('click', () => {
        const card = button.closest('[data-repeat-id]');
        const id = Number(card.dataset.repeatId);
        const item = (data || []).find((row) => Number(row.id) === id);
        if (!item) return;

        if (card.dataset.repeatType === 'staff') {
          document.querySelector('#staff-entry-id').value = item.id;
          document.querySelector('#staff-entry-years').value = item.subtitle || '';
          document.querySelector('#staff-entry-title').value = item.title || '';
          document.querySelector('#staff-entry-body').value = item.body || '';
        } else {
          document.querySelector('#timeline-entry-id').value = item.id;
          document.querySelector('#timeline-entry-rank').value = item.rank || '';
          document.querySelector('#timeline-entry-year').value = item.subtitle || '';
          document.querySelector('#timeline-entry-title').value = item.title || '';
          document.querySelector('#timeline-entry-body').value = item.body || '';
        }
      });
    });


    document.querySelectorAll('[data-move-timeline]').forEach((button) => {
      button.addEventListener('click', async () => {
        const card = button.closest('[data-repeat-id]');
        const id = Number(card.dataset.repeatId);
        const direction = button.dataset.moveTimeline;
        const currentIndex = timeline.findIndex((item) => Number(item.id) === id);
        const targetIndex = direction === 'up' ? currentIndex - 1 : currentIndex + 1;
        if (currentIndex < 0 || targetIndex < 0 || targetIndex >= timeline.length) return;

        const current = timeline[currentIndex];
        const target = timeline[targetIndex];
        const currentRank = Number(current.rank || currentIndex + 1);
        const targetRank = Number(target.rank || targetIndex + 1);

        setStatus('Reordering timeline…');
        const first = await client.from('managed_items')
          .update({ rank: targetRank, updated_at: new Date().toISOString() })
          .eq('id', current.id);
        if (first.error) return setStatus(first.error.message, 'error');

        const second = await client.from('managed_items')
          .update({ rank: currentRank, updated_at: new Date().toISOString() })
          .eq('id', target.id);
        if (second.error) return setStatus(second.error.message, 'error');

        setStatus('Timeline order updated.', 'success');
        await loadRepeatingHistory();
      });
    });

    document.querySelectorAll('[data-delete-repeat]').forEach((button) => {
      button.addEventListener('click', async () => {
        const card = button.closest('[data-repeat-id]');
        if (!confirm('Delete this history entry?')) return;
        const { error } = await client.from('managed_items').delete().eq('id', Number(card.dataset.repeatId));
        if (error) setStatus(error.message, 'error');
        else {
          setStatus('History entry deleted.', 'success');
          await loadRepeatingHistory();
        }
      });
    });
  }

  async function saveRepeatEntry(type) {
    if (!selected) {
      setStatus('Select a franchise first.', 'error');
      return;
    }

    const isStaff = type === 'staff';
    const id = Number(document.querySelector(isStaff ? '#staff-entry-id' : '#timeline-entry-id').value) || null;
    const subtitle = document.querySelector(isStaff ? '#staff-entry-years' : '#timeline-entry-year').value.trim();
    const titleValue = document.querySelector(isStaff ? '#staff-entry-title' : '#timeline-entry-title').value.trim();
    const bodyValue = document.querySelector(isStaff ? '#staff-entry-body' : '#timeline-entry-body').value.trim();
    const requestedRank = isStaff ? null : Number(document.querySelector('#timeline-entry-rank').value) || null;

    if (!titleValue) {
      setStatus('Add a title or coach name first.', 'error');
      return;
    }

    const contentType = isStaff ? 'franchise_staff' : 'franchise_timeline';
    const { data: existingRows, error: loadError } = await client
      .from('managed_items')
      .select('id,rank')
      .eq('league', selected.league)
      .eq('content_type', contentType)
      .contains('metadata', { team_key: selected.team_key })
      .order('rank', { ascending: true })
      .order('id', { ascending: true });

    if (loadError) {
      setStatus(loadError.message, 'error');
      return;
    }

    const currentRow = (existingRows || []).find((row) => Number(row.id) === Number(id));
    const defaultRank = currentRow?.rank || (existingRows?.length || 0) + 1;
    const rank = requestedRank || defaultRank;

    const payload = {
      content_type: contentType,
      league: selected.league,
      rank,
      item_key: `${selected.team_key}-${isStaff ? 'staff' : 'timeline'}-${id || Date.now()}`,
      title: titleValue,
      subtitle,
      body: bodyValue,
      metadata: { team_key: selected.team_key },
      is_active: true,
      updated_at: new Date().toISOString()
    };

    let savedRow = null;
    if (id) {
      const { data, error } = await client
        .from('managed_items')
        .update(payload)
        .eq('id', id)
        .select()
        .single();
      if (error) {
        setStatus(error.message, 'error');
        return;
      }
      savedRow = data;
    } else {
      const { data, error } = await client
        .from('managed_items')
        .insert(payload)
        .select()
        .single();
      if (error) {
        setStatus(error.message, 'error');
        return;
      }
      savedRow = data;
    }

    if (!isStaff) {
      const rowsWithoutSaved = (existingRows || []).filter((row) => Number(row.id) !== Number(savedRow.id));
      const insertIndex = Math.max(0, Math.min(rowsWithoutSaved.length, rank - 1));
      rowsWithoutSaved.splice(insertIndex, 0, savedRow);

      const updates = rowsWithoutSaved.map((row, index) =>
        client.from('managed_items')
          .update({ rank: index + 1, updated_at: new Date().toISOString() })
          .eq('id', row.id)
      );
      await Promise.all(updates);
    }

    if (isStaff) clearStaffForm();
    else clearTimelineForm();

    setStatus('History entry saved.', 'success');
    await loadRepeatingHistory();
  }


  function csvEscape(value) {
    const text = value === null || value === undefined ? '' :
      typeof value === 'object' ? JSON.stringify(value) : String(value);
    return `"${text.replaceAll('"','""')}"`;
  }

  function downloadFile(filename, content, mimeType) {
    const blob = new Blob([content], { type:mimeType });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    link.remove();
    URL.revokeObjectURL(url);
  }

  function exportRows(format) {
    const rows = records
      .filter((row) => row.league === activeLeague)
      .sort((a,b) => displayName(a).localeCompare(displayName(b)));

    if (!rows.length) {
      setStatus(`No saved ${activeLeague === 'nffl' ? 'NFFL' : 'G-League'} records to export.`, 'error');
      return;
    }

    const stamp = new Date().toISOString().slice(0,10);
    if (format === 'json') {
      downloadFile(
        `${activeLeague}-team-content-${stamp}.json`,
        JSON.stringify(rows, null, 2),
        'application/json'
      );
    } else {
      const preferred = [
        'league','team_key','team_name','coach_name','division','status',
        'established_year','current_record','last_game','next_game',
        'coach_record','all_time_record','championships','runner_up_finishes',
        'division_titles','best_finish','best_record','about_coach',
        'franchise_notes','team_news','hall_of_fame_members',
        'season_vault_note','trophy_notes','sleeper_roster_id',
        'created_at','updated_at'
      ];
      const extra = [...new Set(rows.flatMap((row) => Object.keys(row)))]
        .filter((key) => !preferred.includes(key));
      const headers = [...preferred, ...extra];
      const csv = [
        headers.map(csvEscape).join(','),
        ...rows.map((row) => headers.map((key) => csvEscape(row[key])).join(','))
      ].join('\n');

      downloadFile(`${activeLeague}-team-content-${stamp}.csv`, csv, 'text/csv;charset=utf-8');
    }

    setStatus(`${rows.length} ${activeLeague === 'nffl' ? 'NFFL' : 'G-League'} franchise records exported as ${format.toUpperCase()}.`, 'success');
  }

  function collectForm() {
    const values = {};
    dataService.TEAM_EDITABLE_FIELDS.forEach((fieldName) => {
      const field = form.elements.namedItem(fieldName);
      if (field) values[fieldName] = dataService.normalizeTeamValue(fieldName, field.value);
    });
    return { ...selected, ...values };
  }

  function setDirtyState(nextDirty) {
    dirty = Boolean(nextDirty);
    if (saveButton) saveButton.disabled = !dirty || !selected;
  }

  function updateDirtyState() {
    if (!selected || !cleanSnapshot) return setDirtyState(false);
    setDirtyState(Object.keys(dataService.teamChanges(cleanSnapshot, collectForm())).length > 0);
  }

  function canLeaveCurrentTeam() {
    return !dirty || confirm('You have unsaved franchise changes. Discard them?');
  }

  function fill(team) {
    selected = team;
    title.textContent = `Edit ${displayName(team)}`;
    pageLink.href = publicPath(team);

    [...form.elements].forEach((field) => {
      if (field.name) field.value = '';
    });
    dataService.TEAM_COLUMNS.forEach((key) => {
      const field = form.elements.namedItem(key);
      if (field) field.value = team[key] ?? '';
    });

    form.league.value = team.league;
    form.team_key.value = team.team_key;
    cleanSnapshot = { ...team };
    setDirtyState(false);
    renderList();
    setPanel('general');
    loadRepeatingHistory();
    document.querySelector('#franchise-editor').scrollIntoView({ behavior: 'smooth', block: 'start' });
  }

  async function openTeam(league, key) {
    if (!canLeaveCurrentTeam()) return;
    setStatus('Loading Team...');
    try {
      const team = await dataService.loadTeam(league, key);
      fill(team);
      setStatus(`Loaded Team: ${displayName(team)}`, 'success');
    } catch (error) {
      setStatus(error.message, 'error');
    }
  }

  async function loadRecords() {
    setStatus('Loading Team...');
    try {
      records = await dataService.loadTeams();
      setStatus(`${records.length} saved franchise record${records.length === 1 ? '' : 's'} loaded.`, 'success');
    } catch (error) {
      records = [];
      setStatus(error.message, 'error');
    }
    renderList();
  }

  leagueTabs.forEach((tab) => {
    tab.addEventListener('click', () => {
      if (!canLeaveCurrentTeam()) return;
      activeLeague = tab.dataset.franchiseLeague;
      leagueTabs.forEach((item) => item.classList.toggle('active', item === tab));
      selected = null;
      cleanSnapshot = null;
      setDirtyState(false);
      title.textContent = 'Select a franchise';
      renderList();
    });
  });

  panelTabs.forEach((tab) => {
    tab.addEventListener('click', () => setPanel(tab.dataset.franchisePanelTab));
  });

  search.addEventListener('input', renderList);
  form.addEventListener('input', updateDirtyState);
  form.addEventListener('change', updateDirtyState);

  form.addEventListener('submit', async (event) => {
    event.preventDefault();
    if (!selected) {
      setStatus('Select a franchise first.', 'error');
      return;
    }

    const candidate = collectForm();
    const validation = validator.validateTeam(candidate, records);
    if (!validation.valid) {
      setStatus(`Validation failed: ${validation.errors.join(' ')}`, 'error');
      return;
    }
    setStatus('Saving Team...');
    if (saveButton) saveButton.disabled = true;
    try {
      const { row, updatedColumns } = await dataService.saveTeam(cleanSnapshot, candidate);
      const index = records.findIndex((record) => Number(record.id) === Number(row.id));
      if (index >= 0) records[index] = row;
      selected = row;
      cleanSnapshot = { ...row };
      setDirtyState(false);
      const warning = validation.warnings.length ? ` Warning: ${validation.warnings.join(' ')}` : '';
      setStatus(`Save Complete. Updated columns: ${updatedColumns.join(', ') || 'none'}.${warning}`, validation.warnings.length ? '' : 'success');
      renderList();
    } catch (error) {
      setDirtyState(true);
      setStatus(error.message, 'error');
    }
  });

  window.addEventListener('beforeunload', (event) => {
    if (!dirty) return;
    event.preventDefault();
    event.returnValue = '';
  });


  document.querySelector('#export-team-content-csv')?.addEventListener('click', () => exportRows('csv'));
  document.querySelector('#export-team-content-json')?.addEventListener('click', () => exportRows('json'));

  document.querySelector('#save-staff-entry')?.addEventListener('click', () => saveRepeatEntry('staff'));
  document.querySelector('#new-staff-entry')?.addEventListener('click', clearStaffForm);
  document.querySelector('#save-timeline-entry')?.addEventListener('click', () => saveRepeatEntry('timeline'));
  document.querySelector('#new-timeline-entry')?.addEventListener('click', clearTimelineForm);

  leagueTabs.forEach((tab) => tab.classList.toggle('active', tab.dataset.franchiseLeague === activeLeague));
  setPanel('general');
  await loadRecords();
})();
