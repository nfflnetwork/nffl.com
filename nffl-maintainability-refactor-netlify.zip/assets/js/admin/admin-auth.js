
(async function protectAdminArea() {
  const client = window.nfflSupabase;
  if (!client) {
    document.body.innerHTML = '<main class="container"><section class="page-title"><h1>Admin unavailable</h1><p>Supabase could not initialize.</p></section></main>';
    return;
  }

  const onLoginPage = location.pathname.endsWith('/admin/login.html') || location.pathname.endsWith('/admin/login');
  const { data: { session }, error: sessionError } = await client.auth.getSession();

  if (sessionError) console.error(sessionError);

  if (!session) {
    if (!onLoginPage) {
      const next = encodeURIComponent(location.pathname + location.search);
      location.replace(`login.html?next=${next}`);
    }
    return;
  }

  if (onLoginPage) {
    location.replace('index.html');
    return;
  }

  const { data: profile, error: profileError } = await client
    .from('profiles')
    .select('display_name, role')
    .eq('id', session.user.id)
    .maybeSingle();

  if (profileError) console.error(profileError);

  const allowed = profile && ['commissioner', 'admin'].includes(profile.role);
  if (!allowed) {
    await client.auth.signOut();
    location.replace('login.html?error=unauthorized');
    return;
  }

  document.documentElement.classList.add('admin-authorized');
  document.querySelectorAll('[data-admin-user]').forEach((node) => {
    node.textContent = profile.display_name || session.user.email || 'Commissioner';
  });

  document.querySelectorAll('[data-admin-role]').forEach((node) => {
    node.textContent = profile.role;
  });

  document.querySelectorAll('[data-admin-logout]').forEach((button) => {
    button.addEventListener('click', async () => {
      button.disabled = true;
      await client.auth.signOut();
      location.replace('login.html');
    });
  });

  client.auth.onAuthStateChange((event, newSession) => {
    if (event === 'SIGNED_OUT' || !newSession) location.replace('login.html');
  });
})();
