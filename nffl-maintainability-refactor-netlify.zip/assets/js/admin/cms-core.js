
window.NFFLCMS = {
  client() {
    if (!window.nfflSupabase) throw new Error('Supabase client is unavailable.');
    return window.nfflSupabase;
  },

  setStatus(message, type = '') {
    document.querySelectorAll('[data-cms-status]').forEach((node) => {
      node.textContent = message;
      node.className = `admin-form-status ${type}`.trim();
    });
  },

  escape(value) {
    return String(value ?? '')
      .replaceAll('&', '&amp;')
      .replaceAll('<', '&lt;')
      .replaceAll('>', '&gt;')
      .replaceAll('"', '&quot;')
      .replaceAll("'", '&#039;');
  },

  slugify(value) {
    return String(value || '')
      .toLowerCase()
      .trim()
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/^-+|-+$/g, '');
  },

  formToObject(form) {
    const data = new FormData(form);
    const object = {};
    for (const [key, value] of data.entries()) {
      if (value === '') {
        object[key] = null;
      } else if (['season', 'week', 'rank'].includes(key)) {
        object[key] = Number(value);
      } else if (['published', 'featured', 'is_final', 'is_active'].includes(key)) {
        object[key] = value === 'true' || value === 'on';
      } else {
        object[key] = value;
      }
    }
    form.querySelectorAll('input[type="checkbox"]').forEach((input) => {
      object[input.name] = input.checked;
    });
    return object;
  },

  fillForm(form, row) {
    Object.entries(row || {}).forEach(([key, value]) => {
      const field = form.elements.namedItem(key);
      if (!field) return;
      if (field.type === 'checkbox') field.checked = Boolean(value);
      else field.value = value ?? '';
    });
  },

  resetForm(form) {
    form.reset();
    const id = form.elements.namedItem('id');
    if (id) id.value = '';
  }
};
