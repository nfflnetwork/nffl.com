
(async function setupPromotionManager() {
  const client = window.nfflSupabase;
  if (!client) return;

  const candidateForm = document.querySelector('#candidate-form');
  const archiveForm = document.querySelector('#archive-form');
  const candidateList = document.querySelector('#candidate-list');
  const archiveList = document.querySelector('#promotion-archive-list');
  const candidateStatus = document.querySelector('#candidate-status');
  const archiveStatus = document.querySelector('#archive-status');

  let candidateRows = [];
  let archiveRows = [];
  let selectedCandidateId = null;
  let selectedArchiveId = null;

  const stars = (rating) => {
    const value = Number(rating || 0);
    const whole = Math.floor(value);
    return '★'.repeat(whole) + (value % 1 ? '½' : '');
  };

  function setStatus(node, message, type='') {
    node.textContent = message;
    node.className = `admin-form-status ${type}`.trim();
  }

  function metadata(row) {
    return row?.metadata && typeof row.metadata === 'object' ? row.metadata : {};
  }

  function renderCandidates() {
    candidateList.innerHTML = candidateRows.length ? candidateRows.map((row) => {
      const meta = metadata(row);
      return `
        <button type="button" class="promotion-record-card${selectedCandidateId === row.id ? ' active' : ''}" data-candidate-id="${row.id}">
          <span>#${row.rank || '—'}</span>
          <div>
            <strong>${row.title || 'Unnamed coach'}</strong>
            <small>${stars(meta.rating)} • ${row.is_active ? 'Visible' : 'Hidden'}</small>
          </div>
        </button>
      `;
    }).join('') : '<div class="rank-item"><h3>No candidates</h3><p>Add the first coach to Promotion Watch.</p></div>';

    candidateList.querySelectorAll('[data-candidate-id]').forEach((button) => {
      button.addEventListener('click', () => {
        const row = candidateRows.find((item) => Number(item.id) === Number(button.dataset.candidateId));
        if (row) fillCandidate(row);
      });
    });
  }

  function renderArchive() {
    archiveList.innerHTML = archiveRows.length ? archiveRows.map((row) => {
      const meta = metadata(row);
      return `
        <button type="button" class="promotion-record-card${selectedArchiveId === row.id ? ' active' : ''}" data-archive-id="${row.id}">
          <span>${row.season || '—'}</span>
          <div>
            <strong>${row.title || 'Unnamed coach'}</strong>
            <small>${meta.previous_team || 'G-League team TBD'} → ${meta.nffl_team || 'NFFL team TBD'}</small>
          </div>
        </button>
      `;
    }).join('') : '<div class="rank-item"><h3>No Promotions Yet</h3><p>The first promoted coach will appear here once you add a record.</p></div>';

    archiveList.querySelectorAll('[data-archive-id]').forEach((button) => {
      button.addEventListener('click', () => {
        const row = archiveRows.find((item) => Number(item.id) === Number(button.dataset.archiveId));
        if (row) fillArchive(row);
      });
    });
  }

  function clearCandidate() {
    selectedCandidateId = null;
    candidateForm.reset();
    candidateForm.rank.value = candidateRows.length + 1;
    candidateForm.season.value = 2026;
    candidateForm.rating.value = '4';
    candidateForm.is_active.checked = true;
    document.querySelector('#candidate-form-title').textContent = 'Add Candidate';
    renderCandidates();
  }

  function fillCandidate(row) {
    selectedCandidateId = row.id;
    const meta = metadata(row);
    candidateForm.id.value = row.id;
    candidateForm.rank.value = row.rank || '';
    candidateForm.title.value = row.title || '';
    candidateForm.rating.value = String(meta.rating ?? 4);
    candidateForm.season.value = row.season || 2026;
    candidateForm.notes.value = meta.notes || row.body?.replace(/^Promotion rating:\s*[^.]+\.\s*/i, '') || '';
    candidateForm.is_active.checked = Boolean(row.is_active);
    document.querySelector('#candidate-form-title').textContent = `Edit ${row.title}`;
    renderCandidates();
  }

  function clearArchive() {
    selectedArchiveId = null;
    archiveForm.reset();
    archiveForm.season.value = 2026;
    archiveForm.rank.value = archiveRows.length + 1;
    archiveForm.role.value = 'Head Coach';
    archiveForm.is_active.checked = true;
    document.querySelector('#archive-form-title').textContent = 'Add Promotion Record';
    renderArchive();
  }

  function fillArchive(row) {
    selectedArchiveId = row.id;
    const meta = metadata(row);
    archiveForm.id.value = row.id;
    archiveForm.coach_name.value = row.title || '';
    archiveForm.promotion_date.value = meta.promotion_date || '';
    archiveForm.season.value = row.season || 2026;
    archiveForm.rank.value = row.rank || '';
    archiveForm.previous_team.value = meta.previous_team || '';
    archiveForm.nffl_team.value = meta.nffl_team || '';
    archiveForm.role.value = meta.role || 'Head Coach';
    archiveForm.vacancy_reason.value = meta.vacancy_reason || '';
    archiveForm.summary.value = row.body || '';
    archiveForm.is_active.checked = Boolean(row.is_active);
    document.querySelector('#archive-form-title').textContent = `Edit ${row.title}`;
    renderArchive();
  }

  async function loadRows() {
    const { data, error } = await client
      .from('managed_items')
      .select('*')
      .eq('content_type', 'promotion_item')
      .eq('league', 'gleague')
      .order('rank', { ascending: true });

    if (error) {
      setStatus(candidateStatus, error.message, 'error');
      setStatus(archiveStatus, error.message, 'error');
      return;
    }

    candidateRows = (data || []).filter((row) => metadata(row).kind !== 'archive');
    archiveRows = (data || []).filter((row) => metadata(row).kind === 'archive');
    renderCandidates();
    renderArchive();
  }

  candidateForm.addEventListener('submit', async (event) => {
    event.preventDefault();
    const rating = Number(candidateForm.rating.value);
    const notes = candidateForm.notes.value.trim();
    const payload = {
      content_type: 'promotion_item',
      league: 'gleague',
      season: Number(candidateForm.season.value) || 2026,
      rank: Number(candidateForm.rank.value) || 1,
      item_key: selectedCandidateId ? candidateRows.find((row) => row.id === selectedCandidateId)?.item_key : `candidate-${Date.now()}`,
      title: candidateForm.title.value.trim(),
      subtitle: '',
      body: `Promotion rating: ${stars(rating)}.${notes ? ` ${notes}` : ''}`,
      image_url: null,
      metadata: { kind: 'candidate', rating, notes },
      is_active: candidateForm.is_active.checked,
      updated_at: new Date().toISOString()
    };

    setStatus(candidateStatus, 'Saving…');
    const query = selectedCandidateId
      ? client.from('managed_items').update(payload).eq('id', selectedCandidateId).select().single()
      : client.from('managed_items').insert(payload).select().single();

    const { data, error } = await query;
    if (error) {
      setStatus(candidateStatus, error.message, 'error');
      return;
    }

    const index = candidateRows.findIndex((row) => row.id === data.id);
    if (index >= 0) candidateRows[index] = data;
    else candidateRows.push(data);
    candidateRows.sort((a,b) => (a.rank || 999) - (b.rank || 999));
    fillCandidate(data);
    setStatus(candidateStatus, 'Candidate saved.', 'success');
  });

  archiveForm.addEventListener('submit', async (event) => {
    event.preventDefault();
    const meta = {
      kind: 'archive',
      promotion_date: archiveForm.promotion_date.value || null,
      previous_team: archiveForm.previous_team.value.trim() || null,
      nffl_team: archiveForm.nffl_team.value.trim() || null,
      role: archiveForm.role.value.trim() || 'Head Coach',
      vacancy_reason: archiveForm.vacancy_reason.value.trim() || null
    };

    const payload = {
      content_type: 'promotion_item',
      league: 'gleague',
      season: Number(archiveForm.season.value) || 2026,
      rank: Number(archiveForm.rank.value) || archiveRows.length + 1,
      item_key: selectedArchiveId ? archiveRows.find((row) => row.id === selectedArchiveId)?.item_key : `archive-${Date.now()}`,
      title: archiveForm.coach_name.value.trim(),
      subtitle: archiveForm.promotion_date.value || String(archiveForm.season.value || 2026),
      body: archiveForm.summary.value.trim() || null,
      image_url: null,
      metadata: meta,
      is_active: archiveForm.is_active.checked,
      updated_at: new Date().toISOString()
    };

    setStatus(archiveStatus, 'Saving…');
    const query = selectedArchiveId
      ? client.from('managed_items').update(payload).eq('id', selectedArchiveId).select().single()
      : client.from('managed_items').insert(payload).select().single();

    const { data, error } = await query;
    if (error) {
      setStatus(archiveStatus, error.message, 'error');
      return;
    }

    const index = archiveRows.findIndex((row) => row.id === data.id);
    if (index >= 0) archiveRows[index] = data;
    else archiveRows.push(data);
    archiveRows.sort((a,b) => (b.season || 0) - (a.season || 0) || (a.rank || 999) - (b.rank || 999));
    fillArchive(data);
    setStatus(archiveStatus, 'Promotion record saved.', 'success');
  });

  document.querySelector('#new-candidate').addEventListener('click', clearCandidate);
  document.querySelector('#new-archive-entry').addEventListener('click', clearArchive);

  document.querySelector('#delete-candidate').addEventListener('click', async () => {
    if (!selectedCandidateId || !confirm('Delete this Promotion Watch candidate?')) return;
    const { error } = await client.from('managed_items').delete().eq('id', selectedCandidateId);
    if (error) return setStatus(candidateStatus, error.message, 'error');
    candidateRows = candidateRows.filter((row) => row.id !== selectedCandidateId);
    clearCandidate();
    setStatus(candidateStatus, 'Candidate deleted.', 'success');
  });

  document.querySelector('#delete-archive-entry').addEventListener('click', async () => {
    if (!selectedArchiveId || !confirm('Delete this promotion record?')) return;
    const { error } = await client.from('managed_items').delete().eq('id', selectedArchiveId);
    if (error) return setStatus(archiveStatus, error.message, 'error');
    archiveRows = archiveRows.filter((row) => row.id !== selectedArchiveId);
    clearArchive();
    setStatus(archiveStatus, 'Promotion record deleted.', 'success');
  });

  document.querySelectorAll('[data-promotion-tab]').forEach((button) => {
    button.addEventListener('click', () => {
      const tab = button.dataset.promotionTab;
      document.querySelectorAll('[data-promotion-tab]').forEach((item) => item.classList.toggle('active', item === button));
      document.querySelectorAll('[data-promotion-panel]').forEach((panel) => panel.hidden = panel.dataset.promotionPanel !== tab);
    });
  });

  clearCandidate();
  clearArchive();
  await loadRows();
})();
