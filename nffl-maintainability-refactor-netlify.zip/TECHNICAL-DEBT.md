# Remaining technical debt

This pass deliberately favors production stability over speculative rewrites.

## Retained intentionally

- `assets/css/styles.css` is large and contains repeated-looking rules from successive site sections. Automated removal would risk changing specificity, source order, breakpoints, or dark mode. The file was moved without changing its bytes.
- `assets/js/app.js` remains a large legacy script. Splitting it would change script timing and shared global state, so it was moved intact.
- `assets/images/nffl-logo.png` and `assets/images/nffl-logo-new.png` are byte-identical. Both names remain because existing CMS data and fallback logic rely on them.
- The public theme controller and admin theme controller remain separate because their established DOM and storage behavior differs.
- Season templates, setup guides, database snapshots, and migration helpers were retained even when they are not linked publicly. They are operational reference material, not confirmed dead files.
- Sleeper league IDs remain close to the code paths that use them. Centralizing those values would require changing early script-loading order and was outside this no-behavior-change pass.

## Recommended future work

1. Add browser-level visual regression snapshots for representative public, team, G-League, and admin pages in both themes.
2. Split `assets/js/app.js` only after those browser tests exist.
3. Introduce a CSS build pipeline with coverage and visual comparison before deduplicating the stylesheet.
4. Replace legacy logo values in the database with one canonical asset URL during a separately reviewed data migration.
5. Move deployment from manual ZIP uploads to a connected Git repository so every Netlify release is traceable to a commit.
