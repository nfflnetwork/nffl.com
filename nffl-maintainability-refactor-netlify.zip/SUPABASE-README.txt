NFFL SUPABASE ADMIN SETUP

1. In Supabase, open SQL Editor -> New query.
2. Paste the contents of SUPABASE-SETUP.sql and click Run.
3. Go to Authentication -> Users and create your commissioner login.
4. Return to SQL Editor and run:
   update public.profiles
   set role = 'admin', display_name = 'Conor'
   where email = 'YOUR_REAL_EMAIL';
5. In Authentication -> URL Configuration:
   Site URL: https://nffl.netlify.app
   Redirect URLs:
   https://nffl.netlify.app/**
   http://localhost:5500/**
   http://127.0.0.1:5500/**
6. Deploy this ZIP to Netlify.
7. Visit: https://nffl.netlify.app/admin/login.html

The publishable key is included in admin/js/supabase-config.js.
No secret key or service_role key is included.
Sleeper API code was not changed.


PUBLIC CMS CONNECTIONS

The public site now reads these Supabase tables:
- articles -> News page, homepage featured coverage, article.html
- awards -> NFFL and G-League weekly/yearly Awards tabs
- hot_seat -> public Hot Seat watchlist
- team_content -> About Coach, franchise notes, and team news copy
- site_content -> homepage blocks and editable public page introductions
- season_vaults -> published Season Vault cards where a vault grid exists

Admin page:
- /admin/page-blocks.html edits existing static text without modifying Sleeper sections.
- Static HTML remains as a fallback when a Supabase row does not exist.

These additions use separate files under /js and /admin/js.
The original site.js and Sleeper API code are not modified.


FRANCHISE MANAGER UPDATE

Re-run the newest SUPABASE-SETUP.sql after deploying this version.
The script safely adds the new team_content columns with:
  alter table ... add column if not exists

The Franchise Manager now edits:
- Team name
- Coach name
- Current team
- Division
- Status
- Coach record
- Current record
- All-time record
- Championships
- Runner-up finishes
- Best finish
- Best record
- Established year
- About Coach
- Team news
- Franchise notes
- Staff history
- Franchise timeline
- Logo/banner URLs
- Team colors
- Social URL

Franchise Snapshot is no longer loaded from Sleeper.
Sleeper rosters, transactions, and draft picks are still live and unchanged.
