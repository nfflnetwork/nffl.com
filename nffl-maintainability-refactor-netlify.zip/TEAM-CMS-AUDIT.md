# Teams CMS Reliability Audit

Authoritative database snapshot: `team_content_rows (5).csv` (25 records, 39 columns).

## Architecture after refactor

`Teams Editor → admin-data-service.js → Supabase team_content → supabase-public.js → Public Team Pages`

The Franchise Manager no longer reads or writes `team_content` directly and no longer merges website seed values into database records. It reloads a selected team from Supabase, fills every contracted control, computes a patch against the clean database snapshot, and saves through `NFFLAdminData.saveTeam`.

## Field mapping

| CSV columns | Admin | Load | Save | Public use |
|---|---|---|---|---|
| `id`, `league`, `team_key`, `created_at`, `updated_at` | Protected identity/audit fields; intentionally not editable | Yes | Identity is never mutated; service owns `updated_at` | `league` + `team_key` select the page record |
| `team_name`, `current_team`, `division`, `status`, `established_year` | Overview | Yes | Yes | Team hero/metadata; directory uses name/division |
| `current_record`, `last_game`, `next_game` | Overview | Yes | Yes | Team snapshot |
| `logo_url`, `banner_url`, `primary_color`, `secondary_color`, `social_url` | Overview | Yes | Yes | Logo, hero banner, and primary accent are currently rendered; secondary/social remain stored for existing templates |
| `coach_name`, `coach_record`, `about_coach`, `team_news` | About & News | Yes | Yes | Coach/about/news blocks |
| `sleeper_roster_id`, `sleeper_owner_id`, `sleeper_owner_name`, `sleeper_owner_avatar` | About & News | Yes | Yes | Sleeper live-data association |
| `sleeper_owner_synced_at` | About & News, read-only | Yes | Preserved by Teams Editor; owned by Roster Sync | Operational metadata; intentionally not displayed |
| `all_time_record`, `championships`, `runner_up_finishes`, `division_titles`, `best_finish`, `best_record`, `franchise_notes` | Snapshot | Yes | Yes | Franchise snapshot |
| `staff_history`, `franchise_timeline` | History legacy controls | Yes | Yes | Used when no structured history entries exist |
| `hall_of_fame_members`, `season_vault_note`, `trophy_notes` | Vault & Trophies | Yes | Yes | Team history/trophy sections |

There are no editor-only fields that are absent from the CSV contract.

## Bugs found and fixed

- The form contained controls for only part of the schema, so omitted columns could not round-trip.
- The old save built a replacement upsert from form controls and converted every blank to `null`.
- Selecting a team populated only keys present in the merged object, allowing stale values from the previous team to remain.
- Supabase rows were merged with embedded website seeds, creating a second source of truth.
- “Load Original Website Values” could overwrite current database values with stale static data.
- The Teams editor bypassed `admin-data-service.js` for both load and save.
- Failures were displayed as raw database strings and development logging was incomplete.
- Save was always enabled and navigation did not protect unsaved changes.
- There was no cross-record validation for keys, Sleeper IDs, coach names, URLs, divisions, or colors.
- Legacy CSV history columns loaded and saved inconsistently and were not a reliable public fallback.
- Blank Supabase text values left stale static page text in place.

## Other team_content paths

- `admin/js/sleeper-owner-sync.js` intentionally owns bulk Sleeper association updates and its sync timestamp.
- `admin/js/import-existing.js` intentionally performs one-time administrative imports.
- `site.js` reads roster IDs and team directory metadata for Sleeper/public integration.
- `js/supabase-public.js` is the authoritative individual public-team renderer.

These are separate operational consumers, not alternate Teams Editor save/load implementations.

## Schema changes

None. The supplied CSV and existing `SUPABASE-SETUP.sql` agree on all 39 columns.
