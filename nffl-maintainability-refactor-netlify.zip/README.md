# NFFL Website

Static NFFL and NFFL G-League website with a Supabase-backed administration CMS. This cleanup keeps the existing pages, URLs, presentation, theme behavior, logo behavior, data flow, and Netlify deployment model unchanged.

## Project structure

```text
/
├── index.html                 Public site entry point
├── *.html                    Public NFFL pages
├── g-league/                 Public G-League pages and season archives
├── admin/                    Admin and CMS HTML pages
├── assets/
│   ├── css/styles.css        Existing site and admin styles
│   ├── js/
│   │   ├── app.js            Existing shared public-site behavior
│   │   ├── config.js         Shared browser configuration
│   │   ├── public/           Public Supabase and page modules
│   │   └── admin/            Admin and CMS modules
│   ├── images/               Site branding and image fallbacks
│   ├── icons/                Favicons and app icons
│   └── fonts/                Reserved for locally hosted fonts
├── database/                 Supabase schema, policies, and reference data
├── tests/                    Automated regression and CMS contract tests
└── tools/                    Maintenance utilities
```

The two NFFL logo filenames currently contain the same image. Both are intentionally retained because existing database values and public fallbacks use both names.

## Run locally

Serve the project root through a local web server; do not open pages directly from the filesystem.

```powershell
python -m http.server 8000
```

Then open `http://localhost:8000/`. Admin pages are under `http://localhost:8000/admin/`.

## Supabase

The public Supabase URL and publishable key live in `assets/js/config.js`. That file loads before both public and admin Supabase initializers. Authentication, row-level security, queries, and the Teams CMS data service remain unchanged.

The publishable browser key is not a server secret. Data protection depends on the Supabase row-level security policies in `database/`.

## Netlify deployment

This is a static site and requires no build command.

- Publish directory: project root (`.`)
- Entry point: `/index.html`
- Keep archive entry names and deployed paths using forward slashes.
- Do not rename or move HTML pages without redirects; their current paths are public URLs.

For drag-and-drop deployment, upload the production ZIP included with the deliverables. Its root contains `index.html`, so Netlify can detect the site entry point.

## Tests

With Node.js available:

```powershell
node --test tests/*.test.js
```

The suite verifies local asset references, theme wiring and persistence, database team-page coverage, CMS field contracts, safe save patches, and validation.

## Maintenance rules

- Preserve the order of stylesheet rules; the current cascade is presentation-sensitive.
- Keep shared Supabase values in `assets/js/config.js`.
- Add public modules under `assets/js/public/` and admin modules under `assets/js/admin/`.
- Use root-relative awareness when generating links from nested G-League archive pages.
- Run the complete regression suite before Netlify deployment.
