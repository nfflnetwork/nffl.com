SEASON ARCHIVE TEMPLATE

When a season ends:
1. Copy this template folder.
2. Rename the copied folder to the season year, for example: 2026.
3. Open each HTML file in that new folder.
4. Replace every instance of SEASON with the year, for example: 2026.
5. Replace champion, runner-up, best record, and article placeholders.
6. The standings.html and playoffs.html pages will try to pull archived final standings and the winners bracket from Sleeper using the data-season value.
7. Add a new Season Vault card/link on history.html.
