#!/usr/bin/env node

/**
 * NFFL Season Freeze Tool
 * 
 * This script turns a finished Sleeper season into permanent editable HTML archive pages.
 * It does NOT affect current live Sleeper pages.
 *
 * Usage:
 *   node tools/freeze-season.js nffl 2026
 *   node tools/freeze-season.js gleague 2026
 *
 * After it runs, check:
 *   history/seasons/2026/
 *   g-league/history/seasons/2026/
 */

const fs = require("fs");
const path = require("path");

const LEAGUES = {
  nffl: {
    name: "NFFL",
    leagueId: "1314378987576774656",
    outputRoot: path.join("history", "seasons")
  },
  gleague: {
    name: "NFFL G-League",
    leagueId: "1314378817090916352",
    outputRoot: path.join("g-league", "history", "seasons")
  }
};

const TEAM_OVERRIDES = {
  genrodrii: "mjd413",
  Genrodrii: "mjd413",
  GENRODRII: "MJD413"
};

function normalizeName(value) {
  return String(value || "").toLowerCase().replace(/[^a-z0-9]/g, "");
}

function applyNameOverride(value) {
  const raw = String(value || "");
  return TEAM_OVERRIDES[raw] || TEAM_OVERRIDES[normalizeName(raw)] || raw;
}

function points(primary, decimal) {
  return Number(primary || 0) + Number(decimal || 0) / 100;
}

function esc(value) {
  return String(value ?? "").replace(/[&<>'"]/g, (char) => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    "'": "&#039;",
    '"': "&quot;"
  }[char]));
}

async function sleeper(pathName) {
  const url = `https://api.sleeper.app/v1${pathName}`;
  const res = await fetch(url);
  if (!res.ok) throw new Error(`Sleeper API error ${res.status}: ${url}`);
  return res.json();
}

async function findSeasonLeague(startLeagueId, targetSeason) {
  let currentLeagueId = startLeagueId;
  const seen = new Set();

  for (let i = 0; currentLeagueId && i < 12 && !seen.has(currentLeagueId); i++) {
    seen.add(currentLeagueId);
    const league = await sleeper(`/league/${currentLeagueId}`);
    if (String(league.season) === String(targetSeason)) return league;
    currentLeagueId = league.previous_league_id;
  }

  throw new Error(`Could not find Sleeper league for season ${targetSeason}`);
}

function teamNameForRoster(roster, user) {
  return applyNameOverride(
    roster?.metadata?.team_name ||
    user?.metadata?.team_name ||
    user?.display_name ||
    user?.username ||
    `Roster ${roster?.roster_id || ""}`
  );
}

async function buildStandingsHTML(league, season) {
  const [rosters, users] = await Promise.all([
    sleeper(`/league/${league.league_id}/rosters`),
    sleeper(`/league/${league.league_id}/users`)
  ]);

  const usersById = Object.fromEntries(users.map((user) => [user.user_id, user]));

  const rows = rosters.map((roster) => {
    const user = usersById[roster.owner_id];
    const wins = Number(roster.settings?.wins || 0);
    const losses = Number(roster.settings?.losses || 0);
    const ties = Number(roster.settings?.ties || 0);
    const pf = points(roster.settings?.fpts, roster.settings?.fpts_decimal);
    const pa = points(roster.settings?.fpts_against, roster.settings?.fpts_against_decimal);

    return {
      team: teamNameForRoster(roster, user),
      coach: applyNameOverride(user?.display_name || user?.username || roster.owner_id || "TBD"),
      wins,
      losses,
      ties,
      pf,
      pa
    };
  }).sort((a, b) => {
    if (b.wins !== a.wins) return b.wins - a.wins;
    if (a.losses !== b.losses) return a.losses - b.losses;
    return b.pf - a.pf;
  });

  return rows.map((row, index) => `
            <tr>
              <td>${index + 1}</td>
              <td>${esc(row.team)}</td>
              <td>${esc(row.coach)}</td>
              <td>${row.wins}-${row.losses}${row.ties ? `-${row.ties}` : ""}</td>
              <td>${row.pf.toFixed(2)}</td>
              <td>${row.pa.toFixed(2)}</td>
              <td>${index === 0 ? "Best Regular Season" : "-"}</td>
            </tr>`).join("");
}

async function buildPlayoffHTML(league, season) {
  const winners = [];
  const bracketRounds = ["Quarterfinals", "Semifinals", "Championship"];

  // Sleeper does not expose a perfect bracket object in every league format.
  // This creates an editable scaffold using available playoff matchups when possible.
  // You can manually adjust names/scores after freezing.
  return bracketRounds.map((round, roundIndex) => `
        <section class="section playoff-round">
          <div class="section-header"><h2>${round}</h2></div>
          <div class="week-card">
            <h3>${round} Game ${roundIndex + 1}</h3>
            <div class="matchup"><span>TBD</span><span>vs</span><span>TBD</span></div>
            <p class="meta">Edit this matchup after the bracket is finalized.</p>
          </div>
        </section>`).join("");
}

function pageShell({ title, kicker, body, depth = "../../../" }) {
  return `<!doctype html>
<html lang="en">
<head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>${esc(title)}</title><link rel="stylesheet" href="${depth}assets/css/styles.css"></head>
<body>
  <header class="network-strip"><div class="network-inner"><a class="brand-lockup" href="${depth}index.html"><img src="${depth}assets/images/nffl-logo.png" alt="NFFL logo"><div><div class="brand-kicker">${esc(kicker)}</div><div class="brand-title">NFFL Network</div></div></a><div class="scoreboard"><div class="scorebox"><span>Archive</span><strong>${esc(title)}</strong></div><div class="scorebox"><span>Status</span><strong>Frozen Season</strong></div><div class="scorebox"><span>Source</span><strong>Sleeper Snapshot</strong></div></div><a class="button gold" href="${depth}history.html">History</a></div></header>
  <nav class="nav"><div class="nav-inner"><a href="${depth}index.html">Home</a><a href="${depth}news.html">News</a><a href="${depth}teams.html">Teams</a><a href="${depth}standings.html">Standings</a><a href="${depth}schedule.html">Schedule</a><a href="${depth}power-rankings.html">Power Rankings</a><a href="${depth}draft-history.html">Draft History</a><a href="${depth}transactions.html">Transactions</a><a href="${depth}g-league/index.html">G-League</a><a href="${depth}history.html" class="active">History</a><a href="${depth}rules.html">Rules</a></div></nav>
  <main class="container history-page">
${body}
  </main>
  <footer class="footer"><div class="container"><img src="${depth}assets/images/nffl-logo.png" alt=""><p><strong>NFFL Network</strong><br>NFFL is an independent fantasy football league and is not affiliated with, endorsed by, or associated with the NFL or its subsidiaries.</p></div></footer>
  <script src="${depth}assets/js/app.js"></script>
</body>
</html>`;
}

async function freezeSeason(leagueKey, season) {
  const config = LEAGUES[leagueKey];
  if (!config) throw new Error(`Unknown league "${leagueKey}". Use nffl or gleague.`);

  const league = await findSeasonLeague(config.leagueId, season);
  const outDir = path.join(process.cwd(), config.outputRoot, String(season));
  fs.mkdirSync(outDir, { recursive: true });

  const standingsRows = await buildStandingsHTML(league, season);

  const indexBody = `
    <section class="page-title"><h1>${season} ${config.name} Season Vault</h1><p>Permanent frozen archive for the ${season} season.</p></section>
    <section class="section split">
      <div class="rank-item"><h3>Season Snapshot</h3><p>Edit champion, runner-up, best record, awards, and major notes directly in this HTML file.</p></div>
      <div class="rank-item"><h3>Archive Links</h3><p><a class="button" href="standings.html">Final Standings</a> <a class="button gold" href="playoffs.html">Playoff Bracket</a></p></div>
    </section>`;

  fs.writeFileSync(path.join(outDir, "index.html"), pageShell({
    title: `${season} ${config.name} Season Vault`,
    kicker: "Season Vault",
    body: indexBody
  }));

  const standingsBody = `
    <section class="page-title"><h1>${season} Final Standings</h1><p>Frozen standings archive. This page is editable HTML and no longer updates from Sleeper.</p></section>
    <section class="section">
      <div class="section-header"><h2>Final League Snapshot</h2><a href="index.html">Back to Season Vault</a></div>
      <p class="meta">Static archive • created from Sleeper snapshot</p>
      <div class="table-card">
        <table>
          <thead><tr><th>Rank</th><th>Team</th><th>Coach</th><th>Record</th><th>PF</th><th>PA</th><th>Result</th></tr></thead>
          <tbody>${standingsRows}</tbody>
        </table>
      </div>
    </section>`;

  fs.writeFileSync(path.join(outDir, "standings.html"), pageShell({
    title: `${season} ${config.name} Final Standings`,
    kicker: "Final Standings",
    body: standingsBody
  }));

  const playoffBody = `
    <section class="page-title"><h1>${season} Playoff Bracket</h1><p>Frozen playoff archive. Keep main bracket separate from consolation games.</p></section>
    ${await buildPlayoffHTML(league, season)}`;

  fs.writeFileSync(path.join(outDir, "playoffs.html"), pageShell({
    title: `${season} ${config.name} Playoff Bracket`,
    kicker: "Playoff Archive",
    body: playoffBody
  }));

  console.log(`✅ ${config.name} ${season} archive created at ${config.outputRoot}/${season}`);
}

const [, , leagueKey, season] = process.argv;

if (!leagueKey || !season) {
  console.log("Usage: node tools/freeze-season.js nffl 2026");
  console.log("       node tools/freeze-season.js gleague 2026");
  process.exit(1);
}

freezeSeason(leagueKey, season).catch((error) => {
  console.error(error);
  process.exit(1);
});
