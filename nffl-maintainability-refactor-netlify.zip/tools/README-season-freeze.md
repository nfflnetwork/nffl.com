# NFFL Season Freeze Workflow

This lets you turn a completed Sleeper season into a permanent editable archive.

## Why use this?

Live Sleeper pages are great during the season, but past seasons should become official historical records.

When a season ends, run:

```bash
node tools/freeze-season.js nffl 2026
```

or:

```bash
node tools/freeze-season.js gleague 2026
```

The script creates:

```text
history/seasons/2026/
  index.html
  standings.html
  playoffs.html
```

or for G-League:

```text
g-league/history/seasons/2026/
  index.html
  standings.html
  playoffs.html
```

## What gets frozen?

- Final standings
- Team names
- Coach names
- Records
- Points For
- Points Against
- Playoff bracket scaffold

## What stays live?

The current season pages still update from Sleeper:
- Standings
- Rosters
- Transactions
- Draft picks
- Draft history
- Team pages

## Important

After freezing, the new archive files are normal editable HTML pages. You can manually add:
- Champion
- Runner-up
- Awards
- Playoff scores
- Bracket details
- Season notes
